package com.inkgame348.sealednotes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.VH> {

    public interface Listener {
        void onClick(Note note);
        void onLongClick(Note note);
        void onSelectionChanged();
    }

    /** Payload — обновить только чекбокс, не перерисовывать всю карточку. */
    private static final Object PAYLOAD_SELECTION_MODE = new Object();

    private final List<Note> notes;
    private final Listener listener;
    private boolean selectionMode = false;
    private final Set<String> animatedIds = new HashSet<>();

    public NoteAdapter(List<Note> notes, Listener listener) {
        this.notes = notes;
        this.listener = listener;
    }

    /** Переключение режима выбора — плавно, без моргания. */
    public void setSelectionMode(boolean enabled) {
        this.selectionMode = enabled;
        if (!enabled) for (Note n : notes) n.selected = false;
        // Плавно обновляем только видимые чекбоксы
        notifyItemRangeChanged(0, getItemCount(), PAYLOAD_SELECTION_MODE);
    }

    public boolean isSelectionMode() { return selectionMode; }
    public void resetAnimationCache() { animatedIds.clear(); }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position, @NonNull List<Object> payloads) {
        if (!payloads.isEmpty() && payloads.contains(PAYLOAD_SELECTION_MODE)) {
            // Только обновление чекбокса — без перерисовки всей карточки
            Note n = notes.get(position);
            animateCheckbox(h.check, selectionMode, n.selected);
            return;
        }
        onBindViewHolder(h, position);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context ctx = h.itemView.getContext();
        Note n = notes.get(position);

        h.title.setText(n.title.isEmpty() ? ctx.getString(R.string.untitled) : n.title);

        String preview = n.content.replace("\n", " ").trim();
        if (preview.length() > 80) preview = preview.substring(0, 80) + "…";

        if (preview.isEmpty() && !n.attachments.isEmpty()) {
            preview = ctx.getString(R.string.attachments_count, n.attachments.size());
        } else if (!n.attachments.isEmpty()) {
            preview = preview + "  ·  " + ctx.getString(R.string.attachments_count, n.attachments.size());
        }

        h.preview.setText(preview);
        h.date.setText(formatTime(ctx, n.timestamp));
        h.pinIcon.setVisibility(n.pinned ? View.VISIBLE : View.GONE);

        if (selectionMode) {
            // Мгновенно, без анимации — при скролле не мигает
            h.check.setVisibility(View.VISIBLE);
            h.check.setAlpha(1f);
            h.check.setScaleX(1f);
            h.check.setScaleY(1f);
            h.check.setChecked(n.selected);
            h.itemView.setOnClickListener(v -> {
                n.selected = !n.selected;
                h.check.setChecked(n.selected);
                pulse(h.check);
                listener.onSelectionChanged();
            });
            h.itemView.setOnLongClickListener(null);
        } else {
            h.check.setVisibility(View.GONE);
            h.check.setAlpha(1f);
            h.check.setScaleX(1f);
            h.check.setScaleY(1f);
            h.itemView.setOnClickListener(v -> listener.onClick(n));
            h.itemView.setOnLongClickListener(v -> {
                listener.onLongClick(n);
                return true;
            });
        }

        // Плавное появление карточки при первом показе
        if (!selectionMode && !animatedIds.contains(n.id)) {
            animatedIds.add(n.id);
            View item = h.itemView;
            item.setAlpha(0f);
            item.setTranslationY(40f);
            item.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(340)
                .setStartDelay(Math.min(position, 6) * 40L)
                .setInterpolator(new DecelerateInterpolator())
                .start();
        } else {
            h.itemView.setAlpha(1f);
            h.itemView.setTranslationY(0f);
        }
    }

    /** Плавно показывает/скрывает чекбокс. Вызывается только при смене режима выбора. */
    private void animateCheckbox(CheckBox check, boolean show, boolean checked) {
        if (show) {
            if (check.getVisibility() != View.VISIBLE) {
                check.setVisibility(View.VISIBLE);
                check.setAlpha(0f);
                check.setScaleX(0.7f);
                check.setScaleY(0.7f);
                check.animate()
                    .alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(180)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
            } else {
                check.setAlpha(1f);
                check.setScaleX(1f);
                check.setScaleY(1f);
            }
            check.setChecked(checked);
        } else {
            if (check.getVisibility() == View.VISIBLE) {
                check.animate()
                    .alpha(0f).scaleX(0.7f).scaleY(0.7f)
                    .setDuration(150)
                    .withEndAction(() -> {
                        check.setVisibility(View.GONE);
                        check.setAlpha(1f);
                        check.setScaleX(1f);
                        check.setScaleY(1f);
                    })
                    .start();
            }
        }
    }

    /** Короткий «пульс» при тапе на чекбокс. */
    private void pulse(View v) {
        v.animate().scaleX(1.2f).scaleY(1.2f).setDuration(100)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start())
            .start();
    }

    @Override public int getItemCount() { return notes.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, preview, date;
        ImageView pinIcon;
        CheckBox check;
        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.note_title);
            preview = v.findViewById(R.id.note_preview);
            date = v.findViewById(R.id.note_date);
            pinIcon = v.findViewById(R.id.note_pin);
            check = v.findViewById(R.id.note_check);
        }
    }

    private static String formatTime(Context ctx, long ts) {
        long diff = System.currentTimeMillis() - ts;
        if (diff < 60_000) return ctx.getString(R.string.just_now);
        if (diff < 3_600_000) return ctx.getString(R.string.min_ago, diff / 60_000);
        if (diff < 86_400_000) return ctx.getString(R.string.hour_ago, diff / 3_600_000);
        if (diff < 604_800_000) return ctx.getString(R.string.day_ago, diff / 86_400_000);
        return new SimpleDateFormat("dd.MM.yy", Locale.getDefault()).format(new Date(ts));
    }
}