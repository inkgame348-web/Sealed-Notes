package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MasterKeyManager {
    private static final String PREFS = "sealednotes_lock";
    private static final String KEY_DK_FALLBACK = "dk_fallback";
    private static final String KEY_DK_PASSWORD = "dk_password";
    private static final String KEY_DK_BIOMETRIC = "dk_biometric";
    private static final String KEY_HAS_PASSWORD = "has_password";
    private static final String KEY_HAS_BIOMETRIC = "has_biometric";
    private static final String KEY_BIOMETRIC_HEALTHY = "biometric_healthy";
    private static final String KEY_LAST_ACTIVE = "last_active";
    private static final String KEY_AUTOLOCK_MS = "autolock_ms";

    private static final int PBKDF2_ITERATIONS = 600_000;
    private static final int SALT_LEN = 16;
    private static final int GCM_TAG_BITS = 128;

    /** Значения автолока. 0 = выключен. */
    public static final long AUTOLOCK_OFF = 0;
    public static final long AUTOLOCK_DEFAULT = 5L * 60 * 1000; // 5 минут

    private static byte[] memoryKey = null;

    // ============ Status ============

    public static boolean hasPassword(Context c) {
        return prefs(c).getBoolean(KEY_HAS_PASSWORD, false);
    }

    public static boolean hasBiometric(Context c) {
        return prefs(c).getBoolean(KEY_HAS_BIOMETRIC, false);
    }

    public static boolean isBiometricHealthy(Context c) {
        return prefs(c).getBoolean(KEY_BIOMETRIC_HEALTHY, true);
    }

    public static void markBiometricBroken(Context c) {
        prefs(c).edit().putBoolean(KEY_BIOMETRIC_HEALTHY, false).apply();
    }

    public static void markBiometricHealthy(Context c) {
        prefs(c).edit().putBoolean(KEY_BIOMETRIC_HEALTHY, true).apply();
    }

    public static boolean isUnlocked() {
        return memoryKey != null;
    }

    public static boolean isLocked(Context c) {
        return !isUnlocked() && (hasPassword(c) || hasBiometric(c));
    }

    // ============ Auto-lock ============

    public static long getAutoLockMs(Context c) {
        return prefs(c).getLong(KEY_AUTOLOCK_MS, AUTOLOCK_DEFAULT);
    }

    public static void setAutoLockMs(Context c, long ms) {
        prefs(c).edit().putLong(KEY_AUTOLOCK_MS, ms).commit();
    }

    public static void markActive(Context c) {
        prefs(c).edit().putLong(KEY_LAST_ACTIVE, System.currentTimeMillis()).commit();
    }

    public static boolean isAutoLockExpired(Context c) {
        long autoLock = getAutoLockMs(c);
        if (autoLock <= 0) return false;  // выключен
        long last = prefs(c).getLong(KEY_LAST_ACTIVE, System.currentTimeMillis());
        return System.currentTimeMillis() - last > autoLock;
    }

    // ============ Init / Migration ============

    public static void initializeIfNeeded(Context c) throws Exception {
        if (prefs(c).contains(KEY_DK_FALLBACK)) return;

        byte[] dk = new byte[32];
        new SecureRandom().nextBytes(dk);

        File notesFile = new File(c.getFilesDir(), "notes.enc");
        if (notesFile.exists() && notesFile.length() > 0 && KeyStoreHelper.hasOldKey()) {
            try {
                byte[] oldData = readAll(notesFile);
                byte[] plain = KeyStoreHelper.decryptOld(oldData);
                byte[] newData = packWithHeader(dk, plain);
                writeAll(notesFile, newData);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        byte[] dkEnc = KeyStoreHelper.encryptFallback(dk);
        prefs(c).edit().putString(KEY_DK_FALLBACK,
            Base64.encodeToString(dkEnc, Base64.NO_WRAP)).commit();

        memoryKey = dk;
    }

    public static byte[] getDataKey(Context c) throws Exception {
        if (memoryKey != null) return memoryKey;
        if (!hasPassword(c) && !hasBiometric(c)) {
            String s = prefs(c).getString(KEY_DK_FALLBACK, null);
            if (s == null) throw new Exception("DK missing");
            byte[] dkEnc = Base64.decode(s, Base64.NO_WRAP);
            memoryKey = KeyStoreHelper.decryptFallback(dkEnc);
            return memoryKey;
        }
        throw new Exception("LOCKED");
    }

    // ============ Password ============

    public static void setPassword(Context c, String password) throws Exception {
        byte[] dk = getDataKey(c);
        byte[] salt = new byte[SALT_LEN];
        new SecureRandom().nextBytes(salt);
        byte[] key = deriveKey(password, salt);
        byte[] enc = aesEncrypt(key, dk);
        byte[] out = new byte[SALT_LEN + enc.length];
        System.arraycopy(salt, 0, out, 0, SALT_LEN);
        System.arraycopy(enc, 0, out, SALT_LEN, enc.length);
        prefs(c).edit()
            .putString(KEY_DK_PASSWORD, Base64.encodeToString(out, Base64.NO_WRAP))
            .putBoolean(KEY_HAS_PASSWORD, true)
            .commit();
    }

    public static void removePassword(Context c) {
        prefs(c).edit()
            .remove(KEY_DK_PASSWORD)
            .putBoolean(KEY_HAS_PASSWORD, false)
            .commit();
    }

    public static boolean unlockWithPassword(Context c, String password) {
        try {
            String s = prefs(c).getString(KEY_DK_PASSWORD, null);
            if (s == null) return false;
            byte[] data = Base64.decode(s, Base64.NO_WRAP);
            byte[] salt = new byte[SALT_LEN];
            System.arraycopy(data, 0, salt, 0, SALT_LEN);
            byte[] enc = new byte[data.length - SALT_LEN];
            System.arraycopy(data, SALT_LEN, enc, 0, enc.length);
            byte[] key = deriveKey(password, salt);
            byte[] dk = aesDecrypt(key, enc);
            memoryKey = dk;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ============ Biometric ============

    public static byte[] getDkForBiometricWrap(Context c) throws Exception {
        return getDataKey(c);
    }

    public static void saveBiometricWrapped(Context c, byte[] wrapped) {
        prefs(c).edit()
            .putString(KEY_DK_BIOMETRIC, Base64.encodeToString(wrapped, Base64.NO_WRAP))
            .putBoolean(KEY_HAS_BIOMETRIC, true)
            .putBoolean(KEY_BIOMETRIC_HEALTHY, true)
            .commit();
    }

    public static byte[] getBiometricWrapped(Context c) {
        String s = prefs(c).getString(KEY_DK_BIOMETRIC, null);
        if (s == null) return null;
        return Base64.decode(s, Base64.NO_WRAP);
    }

    public static void removeBiometric(Context c) throws Exception {
        prefs(c).edit()
            .remove(KEY_DK_BIOMETRIC)
            .putBoolean(KEY_HAS_BIOMETRIC, false)
            .putBoolean(KEY_BIOMETRIC_HEALTHY, true)
            .commit();
        KeyStoreHelper.deleteBiometricKey();
    }

    public static void setBiometricUnlocked(byte[] dk) {
        memoryKey = dk;
    }

    // ============ Lock ============

    public static void lock() {
        if (memoryKey != null) Arrays.fill(memoryKey, (byte) 0);
        memoryKey = null;
    }

    // ============ AES + Magic ============

    private static final byte[] MAGIC = {'S', 'N', 'B', 'F', '1'};
    private static final byte VERSION = 1;

    public static byte[] packWithHeader(byte[] dk, byte[] plain) throws Exception {
        byte[] enc = aesEncrypt(dk, plain);
        byte[] out = new byte[MAGIC.length + 1 + enc.length];
        System.arraycopy(MAGIC, 0, out, 0, MAGIC.length);
        out[MAGIC.length] = VERSION;
        System.arraycopy(enc, 0, out, MAGIC.length + 1, enc.length);
        return out;
    }

    public static byte[] unpackWithHeader(byte[] dk, byte[] data) throws Exception {
        if (data.length < MAGIC.length + 1) throw new Exception("File too short");
        for (int i = 0; i < MAGIC.length; i++) {
            if (data[i] != MAGIC[i]) throw new Exception("Bad magic");
        }
        byte ver = data[MAGIC.length];
        if (ver != VERSION) throw new Exception("Unknown version: " + ver);
        byte[] enc = new byte[data.length - MAGIC.length - 1];
        System.arraycopy(data, MAGIC.length + 1, enc, 0, enc.length);
        return aesDecrypt(dk, enc);
    }

    public static boolean hasMagicHeader(byte[] data) {
        if (data == null || data.length < MAGIC.length) return false;
        for (int i = 0; i < MAGIC.length; i++) {
            if (data[i] != MAGIC[i]) return false;
        }
        return true;
    }

    // ============ AES raw ============

    public static byte[] aesEncryptStatic(byte[] keyBytes, byte[] plaintext) throws Exception {
        return aesEncrypt(keyBytes, plaintext);
    }

    public static byte[] aesDecryptStatic(byte[] keyBytes, byte[] data) throws Exception {
        return aesDecrypt(keyBytes, data);
    }

    private static byte[] aesEncrypt(byte[] keyBytes, byte[] plaintext) throws Exception {
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    private static byte[] aesDecrypt(byte[] keyBytes, byte[] data) throws Exception {
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        int ivLen = data[0] & 0xFF;
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    private static byte[] deriveKey(String password, byte[] salt) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, 256);
        return f.generateSecret(spec).getEncoded();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static byte[] readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }
    private static void writeAll(File f, byte[] data) throws Exception {
        try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
    }
}