package com.inkgame348.sealednotes;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class EditNoteActivity extends AppCompatActivity {

    private static final long AUTOSAVE_DELAY_MS = 800;

    // ★ Снимок делается, когда суммарное изменение title + content
    // достигло 2 символов, ИЛИ когда длины не изменились, но содержимое
    // отличается (замена символа на такой же по длине).
    private static final int CHARS_PER_SNAPSHOT = 2;

    // ★ Стек снимков увеличен с 20 до 100.
    private static final int MAX_UNDO_STACK = 100;

    private static final String STATE_CURRENT_NOTE = "current_note";
    private static final String STATE_UNDO_STACK = "undo_stack";
    private static final String STATE_UNDO_LAST_TITLE = "undo_last_title";
    private static final String STATE_UNDO_LAST_CONTENT = "undo_last_content";

    private EditText titleField, contentField;
    private LinearLayout attachmentsList;
    private String existingId = null;
    private Note currentNote = null;

    private NoteStorage storage;

    private final Handler autoSaveHandler = new Handler(Looper.getMainLooper());
    private final Runnable autoSaveRunnable = this::saveNow;
    private boolean suppressWatcher = false;

    private final AtomicBoolean saveInFlight = new AtomicBoolean(false);
    private volatile boolean pendingSave = false;

    // ==================== Локальный Undo текста ====================

    private static class TextSnapshot implements Serializable {
        final String title;
        final String content;
        TextSnapshot(String t, String c) { title = t; content = c; }
    }

    private final Deque<TextSnapshot> undoStack = new ArrayDeque<>();
    private boolean suppressUndoTracking = false;
    private String lastSnapshotTitle = "";
    private String lastSnapshotContent = "";
    private ImageButton undoBtn;
    private boolean restoredFromState = false;

    private final ActivityResultLauncher<String> filePicker =
        registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null) return;
            final Note noteAtPick = currentNote;
            if (noteAtPick == null) return;
            final String noteId = noteAtPick.id;
            AttachmentHelper.copyToPrivateAsync(this, uri, noteId, name -> {
                if (name == null) {
                    ToastHelper.show(this, getString(R.string.toast_cannot_open));
                    return;
                }
                if (isFinishing() || isDestroyed()) return;
                final Note live = currentNote;
                if (live == null || !live.id.equals(noteId)) {
                    File orphan = AttachmentHelper.getAttachment(this, noteId, name);
                    if (orphan != null && orphan.exists()) orphan.delete();
                    return;
                }
                live.attachments.add(name);
                renderAttachments();
                saveNow();
                ToastHelper.show(this, getString(R.string.toast_file_attached));
            });
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        restoreUndoState(savedInstanceState);

        setContentView(R.layout.activity_edit_note);
        storage = new NoteStorage(this);

        titleField = findViewById(R.id.edit_title);
        contentField = findViewById(R.id.edit_content);
        attachmentsList = findViewById(R.id.attachments_list);
        undoBtn = findViewById(R.id.btn_undo);
        ImageButton attachBtn = findViewById(R.id.btn_attach);
        ImageButton shareBtn = findViewById(R.id.btn_share);
        ImageButton backBtn = findViewById(R.id.btn_back);
        ImageButton saveBtn = findViewById(R.id.btn_save);

        titleField.setFilters(new InputFilter[]{
            new InputFilter.LengthFilter(Note.MAX_TITLE_LENGTH)
        });
        contentField.setFilters(new InputFilter[]{
            new InputFilter.LengthFilter(Note.MAX_CONTENT_LENGTH)
        });

        existingId = getIntent().getStringExtra("note_id");

        Note restoredNote = null;
        if (savedInstanceState != null) {
            Serializable s = savedInstanceState.getSerializable(STATE_CURRENT_NOTE);
            if (s instanceof Note) restoredNote = (Note) s;
        }

        if (restoredNote != null) {
            currentNote = restoredNote;
            existingId = currentNote.id;
            suppressWatcher = true;
            titleField.setText(currentNote.title);
            contentField.setText(currentNote.content);
            suppressWatcher = false;
            renderAttachments();
            updateUndoButton();
        } else if (existingId != null) {
            storage.loadFullAsync(existingId, loaded -> {
                if (isFinishing() || isDestroyed()) return;
                if (loaded == null) {
                    ToastHelper.show(this, getString(R.string.error_note_open));
                    finish();
                    return;
                }
                currentNote = loaded;
                suppressWatcher = true;
                titleField.setText(currentNote.title);
                contentField.setText(currentNote.content);
                suppressWatcher = false;
                if (!restoredFromState) {
                    lastSnapshotTitle = currentNote.title;
                    lastSnapshotContent = currentNote.content;
                }
                renderAttachments();
                updateUndoButton();
            });
        } else {
            currentNote = new Note();
            currentNote.id = UUID.randomUUID().toString();
            currentNote.timestamp = System.currentTimeMillis();
            currentNote.contentLoaded = true;
            if (!restoredFromState) {
                lastSnapshotTitle = "";
                lastSnapshotContent = "";
            }
        }

        renderAttachments();

        LinearLayout root = findViewById(R.id.edit_root);
        if (root != null) {
            LayoutAnimationController lac = AnimationUtils.loadLayoutAnimation(
                this, R.anim.layout_settings);
            root.setLayoutAnimation(lac);
            root.scheduleLayoutAnimation();
        }

        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (suppressWatcher) return;
                scheduleAutoSave();
                if (!suppressUndoTracking) maybeTakeSnapshot();
            }
        };
        titleField.addTextChangedListener(watcher);
        contentField.addTextChangedListener(watcher);

        undoBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::performTextUndo, 80);
        });

        attachBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(() -> filePicker.launch("*/*"), 80);
        });
        shareBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::shareNote, 80);
        });
        backBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::attemptExit, 80);
        });
        saveBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(() -> {
                saveNow();
                finish();
            }, 80);
        });

        updateUndoButton();
    }

    // ==================== Сохранение / восстановление состояния ====================

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        if (currentNote != null) {
            String t = titleField.getText().toString();
            String c = contentField.getText().toString();
            if (t.length() <= Note.MAX_TITLE_LENGTH
                && c.length() <= Note.MAX_CONTENT_LENGTH) {
                currentNote.title = t;
                currentNote.content = c;
                outState.putSerializable(STATE_CURRENT_NOTE, currentNote);
            }
        }

        ArrayList<TextSnapshot> list = new ArrayList<>(undoStack);
        outState.putSerializable(STATE_UNDO_STACK, list);
        outState.putString(STATE_UNDO_LAST_TITLE, lastSnapshotTitle);
        outState.putString(STATE_UNDO_LAST_CONTENT, lastSnapshotContent);
    }

    @SuppressWarnings("unchecked")
    private void restoreUndoState(Bundle savedInstanceState) {
        if (savedInstanceState == null) return;
        Serializable s = savedInstanceState.getSerializable(STATE_UNDO_STACK);
        if (s instanceof ArrayList) {
            ArrayList<TextSnapshot> restored = (ArrayList<TextSnapshot>) s;
            undoStack.clear();
            for (int i = restored.size() - 1; i >= 0; i--) {
                undoStack.push(restored.get(i));
            }
            restoredFromState = true;
        }
        lastSnapshotTitle = savedInstanceState.getString(STATE_UNDO_LAST_TITLE, "");
        lastSnapshotContent = savedInstanceState.getString(STATE_UNDO_LAST_CONTENT, "");
    }

    // ==================== Undo текста ====================

    /**
     * ★ ФИКС: снимок берётся не только когда изменилась длина, но и
     * когда содержимое отличается при той же длине (замена символа).
     *
     * Логика:
     *   - totalDelta >= CHARS_PER_SNAPSHOT  → снимок безусловно.
     *   - totalDelta == 0                    → проверить содержимое;
     *                                          если отличается — снимок
     *                                          (замена без изменения длины).
     *   - totalDelta == 1                    → ждём ещё одно изменение.
     */
    private void maybeTakeSnapshot() {
        int curTitleLen = titleField.getText().length();
        int curContentLen = contentField.getText().length();
        int titleDelta = Math.abs(curTitleLen - lastSnapshotTitle.length());
        int contentDelta = Math.abs(curContentLen - lastSnapshotContent.length());
        int totalDelta = titleDelta + contentDelta;

        if (totalDelta < CHARS_PER_SNAPSHOT) {
            if (totalDelta > 0) {
                // Дельта 1 — ждём ещё одного изменения.
                return;
            }
            // Дельта 0 — длины совпадают. Могли заменить символ на такой
            // же по длине. Проверяем содержимое.
            String t0 = titleField.getText().toString();
            String c0 = contentField.getText().toString();
            if (t0.equals(lastSnapshotTitle) && c0.equals(lastSnapshotContent)) {
                return;
            }
        }

        String t = titleField.getText().toString();
        String c = contentField.getText().toString();
        if (t.equals(lastSnapshotTitle) && c.equals(lastSnapshotContent)) {
            return;
        }

        undoStack.push(new TextSnapshot(lastSnapshotTitle, lastSnapshotContent));
        while (undoStack.size() > MAX_UNDO_STACK) undoStack.pollLast();
        lastSnapshotTitle = t;
        lastSnapshotContent = c;
        updateUndoButton();
    }

    private void performTextUndo() {
        if (undoStack.isEmpty()) return;
        TextSnapshot prev = undoStack.pop();

        suppressUndoTracking = true;
        suppressWatcher = true;
        titleField.setText(prev.title);
        contentField.setText(prev.content);
        suppressWatcher = false;
        suppressUndoTracking = false;

        lastSnapshotTitle = prev.title;
        lastSnapshotContent = prev.content;

        contentField.setSelection(contentField.getText().length());
        updateUndoButton();
        scheduleAutoSave();
    }

    private void updateUndoButton() {
        if (undoBtn == null) return;
        undoBtn.setVisibility(undoStack.isEmpty() ? View.GONE : View.VISIBLE);
    }

    // ==================== Остальное ====================

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (MasterKeyManager.isUnlocked()) MasterKeyManager.markActive(this);
    }

    private void scheduleAutoSave() {
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        autoSaveHandler.postDelayed(autoSaveRunnable, AUTOSAVE_DELAY_MS);
    }

    private void flushAutoSave() {
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        saveNow();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (currentNote != null && !MasterKeyManager.isLocked(this)) {
            flushAutoSave();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void animateBtn(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(70)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start())
            .start();
    }

    private void shareNote() {
        String t = titleField.getText().toString().trim();
        String c = contentField.getText().toString().trim();
        if (t.isEmpty() && c.isEmpty()) {
            ToastHelper.show(this, getString(R.string.toast_note_empty));
            return;
        }
        String text = (t.isEmpty() ? "" : t + "\n\n") + c;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, t);
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, getString(R.string.share_chooser)));
    }

    private void renderAttachments() {
        if (currentNote == null) return;
        attachmentsList.removeAllViews();
        if (currentNote.attachments.isEmpty()) {
            attachmentsList.setVisibility(View.GONE);
            return;
        }
        attachmentsList.setVisibility(View.VISIBLE);
        LayoutInflater inf = LayoutInflater.from(this);
        int index = 0;
        for (String name : new ArrayList<>(currentNote.attachments)) {
            View row = inf.inflate(R.layout.item_attachment, attachmentsList, false);
            TextView label = row.findViewById(R.id.att_name);
            ImageView thumb = row.findViewById(R.id.att_thumb);
            label.setText(name);

            if (isImage(name)) {
                thumb.setImageResource(R.drawable.ic_image);
            } else {
                thumb.setImageResource(R.drawable.ic_file);
            }

            row.setAlpha(0f);
            row.setTranslationY(20f);
            row.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(300)
                .setStartDelay(index * 60L)
                .setInterpolator(new DecelerateInterpolator())
                .start();
            index++;

            row.setOnClickListener(v -> openAttachment(name));
            row.findViewById(R.id.att_remove).setOnClickListener(v -> {
                row.animate()
                    .alpha(0f)
                    .scaleX(0.85f)
                    .scaleY(0.85f)
                    .setDuration(180)
                    .withEndAction(() -> {
                        final Note live = currentNote;
                        if (live == null) return;
                        live.attachments.remove(name);
                        final String noteId = live.id;
                        AppExecutors.get().diskIO().execute(() -> {
                            File f2 = AttachmentHelper.getAttachment(
                                getApplicationContext(), noteId, name);
                            if (f2 != null && f2.exists()) f2.delete();
                        });
                        renderAttachments();
                        saveNow();
                        ToastHelper.show(this, getString(R.string.toast_file_deleted));
                    })
                    .start();
            });
            attachmentsList.addView(row);
        }
    }

    private boolean isImage(String name) {
        if (name == null) return false;
        String n = name.toLowerCase();
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")
            || n.endsWith(".gif") || n.endsWith(".webp") || n.endsWith(".bmp");
    }

    private void openAttachment(String name) {
        if (currentNote == null) return;
        try {
            File f = AttachmentHelper.getAttachment(this, currentNote.id, name);
            if (f == null || !f.exists()) return;
            Uri uri = FileProvider.getUriForFile(this,
                "com.inkgame348.sealednotes.fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, null));
        } catch (Exception e) {
            ToastHelper.show(this, getString(R.string.toast_cannot_open));
        }
    }

    /**
     * ★ ФИКС: убран ранний выход по LOAD_FAILED. Раньше флаг, залипший
     * от прошлой ошибки, молча блокировал автосохранение и кнопку Save.
     * Теперь saveOne сам решает — при реальной ошибке поставит флаг,
     * при успехе сбросит.
     */
    private void saveNow() {
        if (currentNote == null) return;
        if (MasterKeyManager.isLocked(this)) return;

        final String t = Note.truncate(
            titleField.getText().toString().trim(), Note.MAX_TITLE_LENGTH);
        final String c = Note.truncate(
            contentField.getText().toString().trim(), Note.MAX_CONTENT_LENGTH);

        if (t.isEmpty() && c.isEmpty() && currentNote.attachments.isEmpty()) {
            if (existingId != null) {
                final String idToRemove = existingId;
                storage.loadAsync(all -> {
                    if (all == null) return;
                    all.removeIf(n -> n != null && n.id.equals(idToRemove));
                    storage.saveAsync(all, null);
                });
            }
            return;
        }

        if (!saveInFlight.compareAndSet(false, true)) {
            pendingSave = true;
            return;
        }

        currentNote.title = t;
        currentNote.content = c;
        currentNote.timestamp = System.currentTimeMillis();
        currentNote.contentLoaded = true;

        final Note snapshot = NoteStorage.copyOf(currentNote);

        storage.saveOneAsync(snapshot, () -> {
            if (isFinishing() || isDestroyed()) {
                saveInFlight.set(false);
                return;
            }
            saveInFlight.set(false);
            existingId = snapshot.id;
            if (pendingSave) {
                pendingSave = false;
                saveNow();
            }
        });
    }

    private void attemptExit() {
        flushAutoSave();
        finish();
    }

    @Override
    public void onBackPressed() { attemptExit(); }
}