package com.inkgame348.sealednotes;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.os.LocaleListCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

import javax.crypto.AEADBadTagException;
import javax.crypto.BadPaddingException;

public class SettingsActivity extends AppCompatActivity {

    private static final int CREATE_FILE_REQUEST_CODE = 1001;

    private String exportJsonContent = "";
    private String pendingExportPassword = null;

    private TextView masterPasswordValue;
    private TextView biometricValue;
    private TextView autolockValue;

    private final ActivityResultLauncher<String[]> importFilePicker =
        registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null) return;
            AppExecutors.get().diskIO().execute(() -> {
                try {
                    byte[] bytes = readAllBytes(uri);
                    AppExecutors.get().runOnMain(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        handleImport(bytes);
                    });
                } catch (Exception e) {
                    AppExecutors.get().runOnMain(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        showDialog(getString(R.string.import_error, safeMsg(e)));
                    });
                }
            });
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_settings);

        LinearLayout root = findViewById(R.id.settings_root);
        if (root != null) {
            LayoutAnimationController lac = AnimationUtils.loadLayoutAnimation(
                this, R.anim.layout_settings);
            root.setLayoutAnimation(lac);
            root.scheduleLayoutAnimation();
        }

        ImageButton backBtn = findViewById(R.id.btn_back);
        RadioGroup themeGroup = findViewById(R.id.theme_group);
        LinearLayout languageRow = findViewById(R.id.row_language);
        LinearLayout masterPasswordRow = findViewById(R.id.row_master_password);
        LinearLayout biometricRow = findViewById(R.id.row_biometric);
        LinearLayout autolockRow = findViewById(R.id.row_autolock);
        LinearLayout importRow = findViewById(R.id.row_import);
        LinearLayout backupCloudRow = findViewById(R.id.row_backup_cloud);
        LinearLayout exportRow = findViewById(R.id.row_export);
        TextView languageValue = findViewById(R.id.language_value);
        masterPasswordValue = findViewById(R.id.master_password_value);
        biometricValue = findViewById(R.id.biometric_value);
        autolockValue = findViewById(R.id.autolock_value);

        int theme = SettingsStorage.getTheme(this);
        themeGroup.check(theme == SettingsStorage.THEME_LIGHT ? R.id.theme_light
                     : theme == SettingsStorage.THEME_DARK ? R.id.theme_dark
                     : R.id.theme_system);

        themeGroup.setOnCheckedChangeListener((g, id) -> {
            int newTheme;
            if (id == R.id.theme_light) newTheme = SettingsStorage.THEME_LIGHT;
            else if (id == R.id.theme_dark) newTheme = SettingsStorage.THEME_DARK;
            else newTheme = SettingsStorage.THEME_SYSTEM;
            SettingsStorage.setTheme(this, newTheme);
            AppCompatDelegate.setDefaultNightMode(
                newTheme == SettingsStorage.THEME_LIGHT ? AppCompatDelegate.MODE_NIGHT_NO
                : newTheme == SettingsStorage.THEME_DARK ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        });

        updateLanguageLabel(languageValue);
        updateLockLabels();

        masterPasswordRow.setOnClickListener(v -> { animateRow(v); showMasterPasswordDialog(); });
        biometricRow.setOnClickListener(v -> { animateRow(v); showBiometricDialog(); });
        autolockRow.setOnClickListener(v -> { animateRow(v); showAutolockDialog(); });
        importRow.setOnClickListener(v -> { animateRow(v); pickImportFile(); });
        languageRow.setOnClickListener(v -> { animateRow(v); showLanguageDialog(); });
        backupCloudRow.setOnClickListener(v -> { animateRow(v); backupToCloud(); });
        exportRow.setOnClickListener(v -> { animateRow(v); exportToFile(); });
        backBtn.setOnClickListener(v -> { animateRow(v); finish(); });
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (MasterKeyManager.isUnlocked()) MasterKeyManager.markActive(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void animateRow(View v) {
        v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start())
            .start();
    }

    private static String safeMsg(Throwable t) {
        if (t == null) return "unknown";
        String m = t.getMessage();
        if (m == null || m.isEmpty()) return t.getClass().getSimpleName();
        return m;
    }

    private void updateLockLabels() {
        masterPasswordValue.setText(MasterKeyManager.hasPassword(this)
            ? R.string.master_password_set : R.string.master_password_none);

        if (!MasterKeyManager.hasBiometric(this)) {
            biometricValue.setText(R.string.biometric_off);
        } else if (!MasterKeyManager.isBiometricHealthy(this)) {
            biometricValue.setText(R.string.biometric_broken);
        } else {
            biometricValue.setText(R.string.biometric_on);
        }

        updateAutolockLabel();
    }

    private void updateAutolockLabel() {
        long ms = MasterKeyManager.getAutoLockMs(this);
        if (ms <= 0) {
            autolockValue.setText(R.string.autolock_off);
        } else {
            long min = ms / 60_000;
            if (min == 1) autolockValue.setText(R.string.autolock_1min);
            else autolockValue.setText(getString(R.string.autolock_min, (int)min));
        }
    }

    private void showAutolockDialog() {
        final long[] values = { 0, 60_000, 5 * 60_000, 15 * 60_000, 30 * 60_000, 60 * 60_000 };
        final String[] items = {
            getString(R.string.autolock_off),
            getString(R.string.autolock_1min),
            getString(R.string.autolock_min, 5),
            getString(R.string.autolock_min, 15),
            getString(R.string.autolock_min, 30),
            getString(R.string.autolock_min, 60)
        };

        long current = MasterKeyManager.getAutoLockMs(this);
        int checked = 2;
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) { checked = i; break; }
        }

        new AnimDialog(this)
            .setTitle(R.string.autolock_title)
            .setSingleChoiceItems(items, checked, (d, which) -> {
                MasterKeyManager.setAutoLockMs(this, values[which]);
                updateAutolockLabel();
                d.dismiss();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    // ==================== Мастер-пароль (опциональный) ====================

    private void showMasterPasswordDialog() {
        // Пароль требует биометрии. Если её нет — сообщение.
        if (!MasterKeyManager.hasBiometric(this)) {
            new AnimDialog(this)
                .setTitle(R.string.master_password)
                .setMessage(R.string.master_password_requires_biometric)
                .setPositiveButton(android.R.string.ok, null)
                .show();
            return;
        }

        boolean hasPwd = MasterKeyManager.hasPassword(this);

        if (!hasPwd) {
            // Добавить пароль
            showAddPasswordDialog();
        } else {
            // Меню: сменить / снять
            new AnimDialog(this)
                .setTitle(R.string.master_password)
                .setItems(new CharSequence[]{
                    getString(R.string.master_password_change),
                    getString(R.string.master_password_remove)
                }, (d, which) -> {
                    if (which == 0) showChangePasswordDialog();
                    else showRemovePasswordDialog();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        }
    }

    private void showAddPasswordDialog() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad / 2, pad, 0);

        EditText newInput = new EditText(this);
        newInput.setInputType(InputType.TYPE_CLASS_TEXT
            | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        newInput.setHint(R.string.master_password_hint);
        container.addView(newInput);

        AnimDialog builder = new AnimDialog(this);
        builder.setTitle(R.string.master_password_add_title);
        builder.setMessage(R.string.master_password_add_msg);
        builder.setView(container);
        builder.setPositiveButton(R.string.master_password_save, null);
        builder.setNegativeButton(R.string.cancel, null);

        AlertDialog dialog = builder.show();

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            final String pwd = newInput.getText().toString();
            if (pwd.length() < 4) {
                ToastHelper.show(this, getString(R.string.master_password_too_short));
                return;
            }
            final Button positiveBtn = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
            positiveBtn.setEnabled(false);

            AppExecutors.get().crypto().execute(() -> {
                Exception err = null;
                try {
                    MasterKeyManager.setPassword(SettingsActivity.this, pwd);
                } catch (Exception e) { err = e; }
                final Exception fErr = err;
                AppExecutors.get().runOnMain(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    positiveBtn.setEnabled(true);
                    if (fErr != null) {
                        ToastHelper.show(this, getString(R.string.toast_error, safeMsg(fErr)));
                        return;
                    }
                    ToastHelper.show(this, getString(R.string.master_password_saved));
                    updateLockLabels();
                    dialog.dismiss();
                });
            });
        });
    }

    private void showChangePasswordDialog() {
        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad / 2, pad, 0);

        EditText currentInput = new EditText(this);
        currentInput.setInputType(InputType.TYPE_CLASS_TEXT
            | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        currentInput.setHint(R.string.current_password_hint);
        container.addView(currentInput);

        EditText newInput = new EditText(this);
        newInput.setInputType(InputType.TYPE_CLASS_TEXT
            | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        newInput.setHint(R.string.master_password_hint);
        container.addView(newInput);

        AnimDialog builder = new AnimDialog(this);
        builder.setTitle(R.string.master_password_title);
        builder.setMessage(R.string.master_password_change_hint);
        builder.setView(container);
        builder.setPositiveButton(R.string.master_password_save, null);
        builder.setNegativeButton(R.string.cancel, null);

        AlertDialog dialog = builder.show();

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            final String oldPwd = currentInput.getText().toString();
            final String newPwd = newInput.getText().toString();
            if (newPwd.length() < 4) {
                ToastHelper.show(this, getString(R.string.master_password_too_short));
                return;
            }
            final Button positiveBtn = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
            positiveBtn.setEnabled(false);

            AppExecutors.get().crypto().execute(() -> {
                boolean ok = false;
                Exception err = null;
                try {
                    ok = MasterKeyManager.changePassword(
                        SettingsActivity.this, oldPwd, newPwd);
                } catch (Exception e) { err = e; }
                final boolean fOk = ok;
                final Exception fErr = err;
                AppExecutors.get().runOnMain(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    positiveBtn.setEnabled(true);
                    if (fErr != null) {
                        ToastHelper.show(this, getString(R.string.toast_error, safeMsg(fErr)));
                        return;
                    }
                    if (!fOk) {
                        ToastHelper.show(this, getString(R.string.unlock_wrong_password));
                        return;
                    }
                    ToastHelper.show(this, getString(R.string.master_password_saved));
                    updateLockLabels();
                    dialog.dismiss();
                });
            });
        });
    }

    private void showRemovePasswordDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.current_password_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        AnimDialog builder = new AnimDialog(this);
        builder.setTitle(R.string.master_password_remove);
        builder.setMessage(R.string.auth_required_msg);
        builder.setView(input);
        builder.setPositiveButton(R.string.ok, null);
        builder.setNegativeButton(R.string.cancel, null);

        AlertDialog dialog = builder.show();

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            final String pwd = input.getText().toString();
            final Button positiveBtn = dialog.getButton(DialogInterface.BUTTON_POSITIVE);
            positiveBtn.setEnabled(false);

            AppExecutors.get().crypto().execute(() -> {
                final boolean ok = MasterKeyManager.removePasswordWithAuth(
                    SettingsActivity.this, pwd);
                AppExecutors.get().runOnMain(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    positiveBtn.setEnabled(true);
                    if (ok) {
                        ToastHelper.show(this, getString(R.string.master_password_removed));
                        updateLockLabels();
                        dialog.dismiss();
                    } else {
                        ToastHelper.show(this, getString(R.string.unlock_wrong_password));
                    }
                });
            });
        });
    }

    // ==================== Биометрия ====================

    private void showBiometricDialog() {
        boolean hasBio = MasterKeyManager.hasBiometric(this);

        if (!hasBio) {
            startEnableBiometricFlow();
            return;
        }

        // Биометрия уже включена. Меню.
        new AnimDialog(this)
            .setTitle(R.string.biometric_menu_title)
            .setItems(new CharSequence[]{
                getString(R.string.biometric_refresh),
                getString(R.string.biometric_disable)
            }, (d, which) -> {
                if (which == 0) refreshBiometric();
                else confirmDisableBiometric();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void startEnableBiometricFlow() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            new AnimDialog(this)
                .setTitle(R.string.biometric)
                .setMessage(R.string.biometric_requires_android11)
                .setPositiveButton(android.R.string.ok, null)
                .show();
            return;
        }

        BiometricManager bm = BiometricManager.from(this);
        int can = bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
            | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            ToastHelper.show(this, getString(R.string.error_biometric_unavailable));
            return;
        }

        if (!KeyStoreHelper.canUseBiometricOrDevice()) {
            new AnimDialog(this)
                .setTitle(R.string.error_keystore)
                .setMessage(R.string.error_biometric_unavailable)
                .setPositiveButton(android.R.string.ok, null)
                .show();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                    // ★ encryptDevice сразу на UI-потоке — auth-токен свежий
                    byte[] wrappedDk;
                    try {
                        byte[] dk = MasterKeyManager.getDataKey(SettingsActivity.this);
                        wrappedDk = KeyStoreHelper.encryptDevice(dk);
                    } catch (Exception e) {
                        ToastHelper.show(SettingsActivity.this,
                            getString(R.string.toast_error, safeMsg(e)));
                        return;
                    }
                    final byte[] fWrapped = wrappedDk;
                    AppExecutors.get().crypto().execute(() -> {
                        Exception err = null;
                        try {
                            MasterKeyManager.enableBiometric(
                                SettingsActivity.this, fWrapped);
                        } catch (Exception e) { err = e; }
                        final Exception fErr = err;
                        AppExecutors.get().runOnMain(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            if (fErr != null) {
                                ToastHelper.show(SettingsActivity.this,
                                    getString(R.string.toast_error, safeMsg(fErr)));
                                return;
                            }
                            ToastHelper.show(SettingsActivity.this,
                                getString(R.string.biometric_enabled));
                            updateLockLabels();
                        });
                    });
                }
                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    ToastHelper.show(SettingsActivity.this, getString(R.string.toast_cancelled));
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_enable_title))
            .setSubtitle(getString(R.string.biometric_enable_subtitle))
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);

        prompt.authenticate(b.build());
    }

    private void refreshBiometric() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        byte[] dk = MasterKeyManager.getDataKey(SettingsActivity.this);
                        byte[] enc = KeyStoreHelper.encryptDevice(dk);
                        MasterKeyManager.refreshBiometricWrapped(SettingsActivity.this, enc);
                        ToastHelper.show(SettingsActivity.this,
                            getString(R.string.biometric_rebound));
                        updateLockLabels();
                    } catch (Exception e) {
                        ToastHelper.show(SettingsActivity.this,
                            getString(R.string.toast_error, safeMsg(e)));
                    }
                }
                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    ToastHelper.show(SettingsActivity.this, getString(R.string.toast_cancelled));
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_enable_title))
            .setSubtitle(getString(R.string.biometric_enable_subtitle))
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);

        prompt.authenticate(b.build());
    }

    /**
     * ★ Отключение биометрии: требует свежей верификации биометрией.
     * Но сначала проверяем, что пароль снят — если нет, отказываем.
     */
    private void confirmDisableBiometric() {
        if (MasterKeyManager.hasPassword(this)) {
            new AnimDialog(this)
                .setTitle(R.string.biometric_off_title)
                .setMessage(R.string.biometric_disable_requires_no_password)
                .setPositiveButton(android.R.string.ok, null)
                .show();
            return;
        }

        // ★ Свежая верификация биометрией для безопасности
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                    AppExecutors.get().crypto().execute(() -> {
                        Exception err = null;
                        try {
                            MasterKeyManager.disableBiometric(SettingsActivity.this);
                        } catch (Exception e) { err = e; }
                        final Exception fErr = err;
                        AppExecutors.get().runOnMain(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            if (fErr != null) {
                                ToastHelper.show(SettingsActivity.this,
                                    getString(R.string.toast_error, safeMsg(fErr)));
                                return;
                            }
                            ToastHelper.show(SettingsActivity.this,
                                getString(R.string.biometric_disabled));
                            updateLockLabels();
                        });
                    });
                }
                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    ToastHelper.show(SettingsActivity.this, getString(R.string.toast_cancelled));
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_disable_prompt_title))
            .setSubtitle(getString(R.string.biometric_disable_prompt_subtitle))
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);

        prompt.authenticate(b.build());
    }

    // ==================== Язык ====================

    private void updateLanguageLabel(TextView tv) {
        String tag = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        String display;
        if (tag == null || tag.isEmpty()) display = getString(R.string.lang_system);
        else if (tag.startsWith("ru")) display = getString(R.string.lang_russian);
        else if (tag.startsWith("en")) display = getString(R.string.lang_english);
        else display = getString(R.string.lang_system);
        tv.setText(display);
    }

    private void showLanguageDialog() {
        String[] items = {
            getString(R.string.lang_system),
            getString(R.string.lang_russian),
            getString(R.string.lang_english)
        };
        String currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        int checked = 0;
        if (currentTag != null && currentTag.startsWith("ru")) checked = 1;
        else if (currentTag != null && currentTag.startsWith("en")) checked = 2;

        new AnimDialog(this)
            .setTitle(R.string.choose_language)
            .setSingleChoiceItems(items, checked, (dialog, which) -> {
                LocaleListCompat locales;
                if (which == 1) locales = LocaleListCompat.forLanguageTags("ru");
                else if (which == 2) locales = LocaleListCompat.forLanguageTags("en");
                else locales = LocaleListCompat.getEmptyLocaleList();
                AppCompatDelegate.setApplicationLocales(locales);
                dialog.dismiss();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    // ==================== Импорт ====================

    private void pickImportFile() {
        importFilePicker.launch(new String[]{"*/*"});
    }

    private void handleImport(byte[] data) {
        if (data == null || data.length == 0) {
            showDialog(getString(R.string.import_error, "empty file"));
            return;
        }
        if (BackupHelper.looksEncrypted(data)) {
            askPasswordAndImport(data);
        } else {
            doImport(data, null);
        }
    }

    private void askPasswordAndImport(byte[] data) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.backup_password_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        AnimDialog builder = new AnimDialog(this);
        builder.setTitle(R.string.restore_enter_password);
        builder.setView(input);
        builder.setPositiveButton(R.string.ok, null);
        builder.setNegativeButton(R.string.cancel, null);

        AlertDialog dialog = builder.show();

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String pwd = input.getText().toString();
            if (pwd.isEmpty()) {
                ToastHelper.show(this, getString(R.string.backup_password_hint));
                return;
            }
            doImportWithPasswordCheck(data, pwd, dialog, input);
        });
    }

    private void doImportWithPasswordCheck(byte[] data, String password,
                                            AlertDialog dialog, EditText input) {
        BackupHelper.importFromBytesAsync(this, data, password, true, (result, error) -> {
            if (isFinishing() || isDestroyed()) return;

            if (error != null) {
                boolean wrongPassword =
                    (error instanceof AEADBadTagException)
                    || (error instanceof BadPaddingException);

                if (!wrongPassword) {
                    String msg = error.getMessage();
                    if (msg != null && (msg.contains("Tag mismatch")
                        || msg.contains("AEADBadTag")
                        || msg.contains("pad block")
                        || msg.contains("BAD_DECRYPT"))) {
                        wrongPassword = true;
                    }
                }

                if (wrongPassword) {
                    ToastHelper.show(this, getString(R.string.unlock_wrong_password));
                    input.setText("");
                    return;
                }
                showDialog(getString(R.string.import_error, safeMsg(error)));
                dialog.dismiss();
                return;
            }

            StringBuilder sb = new StringBuilder();
            sb.append(getString(R.string.import_result_total, result.total));
            if (result.added > 0) sb.append(", ").append(getString(R.string.import_result_new, result.added));
            if (result.updated > 0) sb.append(", ").append(getString(R.string.import_result_updated, result.updated));
            ToastHelper.show(this, sb.toString());
            dialog.dismiss();
        });
    }

    private void doImport(byte[] data, String password) {
        BackupHelper.importFromBytesAsync(this, data, password, true, (result, error) -> {
            if (isFinishing() || isDestroyed()) return;
            if (error != null) {
                showDialog(getString(R.string.import_error, safeMsg(error)));
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append(getString(R.string.import_result_total, result.total));
            if (result.added > 0) sb.append(", ").append(getString(R.string.import_result_new, result.added));
            if (result.updated > 0) sb.append(", ").append(getString(R.string.import_result_updated, result.updated));
            ToastHelper.show(this, sb.toString());
        });
    }

    private byte[] readAllBytes(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Cannot open file");
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }

    // ==================== Экспорт ====================

    private void askExportPassword(Runnable onProceed) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.export_password_optional_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        new AnimDialog(this)
            .setTitle(R.string.export_password_title)
            .setMessage(R.string.export_password_msg)
            .setView(input)
            .setPositiveButton(R.string.export_password_encrypt, (d, w) -> {
                String pwd = input.getText().toString();
                if (pwd.length() < 4) {
                    ToastHelper.show(this, getString(R.string.export_password_too_short));
                    return;
                }
                pendingExportPassword = pwd;
                onProceed.run();
            })
            .setNeutralButton(R.string.export_password_plain, (d, w) -> {
                pendingExportPassword = null;
                new AnimDialog(this)
                    .setTitle(R.string.export_plain_warn_title)
                    .setMessage(R.string.export_plain_warn_msg)
                    .setPositiveButton(R.string.export_plain_confirm, (d2, w2) -> onProceed.run())
                    .setNegativeButton(R.string.cancel, null)
                    .show();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void backupToCloud() {
        askExportPassword(this::doBackupToCloud);
    }

    private void doBackupToCloud() {
        final String pwd = pendingExportPassword;
        BackupHelper.buildJsonAsync(this, json -> {
            if (isFinishing() || isDestroyed()) return;

            if (json == null) {
                pendingExportPassword = null;
                showDialog(getString(R.string.error_decrypt_failed));
                return;
            }
            if (json.equals("[]") || json.isEmpty()) {
                pendingExportPassword = null;
                showDialog(getString(R.string.no_notes_export));
                return;
            }

            final String jsonFinal = json;
            AppExecutors.get().diskIO().execute(() -> {
                File outFile;
                try {
                    File cacheDir = new File(getCacheDir(), "backup");
                    if (!cacheDir.exists()) cacheDir.mkdirs();
                    if (pwd != null && !pwd.isEmpty()) {
                        byte[] enc = BackupHelper.encryptWithPassword(
                            jsonFinal.getBytes(StandardCharsets.UTF_8), pwd);
                        outFile = new File(cacheDir, "sealednotes_backup.enc");
                        try (FileOutputStream fos = new FileOutputStream(outFile)) { fos.write(enc); }
                    } else {
                        outFile = new File(cacheDir, "sealednotes_backup.json");
                        try (FileOutputStream fos = new FileOutputStream(outFile)) {
                            fos.write(jsonFinal.getBytes(StandardCharsets.UTF_8));
                        }
                    }
                } catch (Exception e) {
                    AppExecutors.get().runOnMain(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        showDialog(getString(R.string.toast_error, safeMsg(e)));
                    });
                    return;
                }
                final File fileForShare = outFile;
                AppExecutors.get().runOnMain(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    pendingExportPassword = null;
                    try {
                        Uri uri = FileProvider.getUriForFile(this,
                            "com.inkgame348.sealednotes.fileprovider", fileForShare);
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType("application/octet-stream");
                        share.putExtra(Intent.EXTRA_STREAM, uri);
                        share.putExtra(Intent.EXTRA_SUBJECT, "Sealed Notes backup");
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(share,
                            getString(R.string.backup_cloud_chooser)));
                        ToastHelper.show(this, getString(R.string.toast_backup_created));
                    } catch (Exception e) {
                        showDialog(getString(R.string.toast_error, safeMsg(e)));
                    }
                });
            });
        });
    }

    private void exportToFile() {
        askExportPassword(this::doExportToFile);
    }

    private void doExportToFile() {
        final String pwd = pendingExportPassword;
        BackupHelper.buildJsonAsync(this, json -> {
            if (isFinishing() || isDestroyed()) return;

            if (json == null) {
                pendingExportPassword = null;
                showDialog(getString(R.string.error_decrypt_failed));
                return;
            }
            if (json.equals("[]") || json.isEmpty()) {
                pendingExportPassword = null;
                showDialog(getString(R.string.no_notes_export));
                return;
            }

            exportJsonContent = json;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            if (pwd != null && !pwd.isEmpty()) {
                intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, "sealednotes_backup.enc");
            } else {
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "sealednotes_backup.json");
            }
            startActivityForResult(intent, CREATE_FILE_REQUEST_CODE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CREATE_FILE_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                final Uri uri = data.getData();
                final String pwd = pendingExportPassword;
                final String content = exportJsonContent;
                pendingExportPassword = null;
                exportJsonContent = "";

                AppExecutors.get().diskIO().execute(() -> {
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) throw new Exception("Cannot open output stream");
                        if (pwd != null && !pwd.isEmpty()) {
                            byte[] enc = BackupHelper.encryptWithPassword(
                                content.getBytes(StandardCharsets.UTF_8), pwd);
                            os.write(enc);
                        } else {
                            os.write(content.getBytes(StandardCharsets.UTF_8));
                        }
                        AppExecutors.get().runOnMain(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            ToastHelper.show(this, getString(R.string.export_success));
                        });
                    } catch (Exception e) {
                        AppExecutors.get().runOnMain(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            showDialog(getString(R.string.toast_error, safeMsg(e)));
                        });
                    }
                });
            } else {
                pendingExportPassword = null;
                exportJsonContent = "";
            }
        }
    }

    private void showDialog(String message) {
        if (isFinishing() || isDestroyed()) return;
        new AnimDialog(this)
            .setMessage(message)
            .setPositiveButton(R.string.ok, null)
            .show();
    }
}