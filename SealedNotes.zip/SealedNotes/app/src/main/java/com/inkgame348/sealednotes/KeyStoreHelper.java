package com.inkgame348.sealednotes;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class KeyStoreHelper {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String FALLBACK_ALIAS = "SealedNotesFallbackKey";
    private static final String BIOMETRIC_ALIAS = "SealedNotesBiometricKey";
    private static final String OLD_ALIAS = "SealedNotesMasterKey";
    private static final int GCM_TAG_BITS = 128;

    // ============ FALLBACK ============

    private static SecretKey getOrCreateFallbackKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(FALLBACK_ALIAS)) {
            return (SecretKey) ks.getKey(FALLBACK_ALIAS, null);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
            FALLBACK_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build();
        kg.init(spec);
        return kg.generateKey();
    }

    public static byte[] encryptFallback(byte[] plaintext) throws Exception {
        SecretKey key = getOrCreateFallbackKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    public static byte[] decryptFallback(byte[] data) throws Exception {
        SecretKey key = getOrCreateFallbackKey();
        int ivLen = data[0] & 0xFF;
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    // ============ MIGRATION ============

    public static boolean hasOldKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        return ks.containsAlias(OLD_ALIAS);
    }

    public static byte[] decryptOld(byte[] data) throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (!ks.containsAlias(OLD_ALIAS)) throw new Exception("Old key missing");
        SecretKey key = (SecretKey) ks.getKey(OLD_ALIAS, null);
        int ivLen = data[0] & 0xFF;
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    // ============ BIOMETRIC ============

    public static void deleteBiometricKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(BIOMETRIC_ALIAS)) ks.deleteEntry(BIOMETRIC_ALIAS);
    }

    private static SecretKey getOrCreateBiometricKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(BIOMETRIC_ALIAS)) {
            return (SecretKey) ks.getKey(BIOMETRIC_ALIAS, null);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        // ★ ФИКС: только базовые флаги, без setUserAuthenticationParameters ★
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(
            BIOMETRIC_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            b.setInvalidatedByBiometricEnrollment(true);
        }
        kg.init(b.build());
        return kg.generateKey();
    }

    public static Cipher getBiometricEncryptCipher() throws Exception {
        SecretKey key = getOrCreateBiometricKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        return c;
    }

    public static Cipher getBiometricDecryptCipher(byte[] iv) throws Exception {
        SecretKey key = getOrCreateBiometricKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c;
    }
}