package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class NoteStorage {

    public static volatile boolean LOAD_FAILED = false;

    private static final String PREFS = "sealednotes_internal";
    private static final String KEY_SCHEMA_VERSION = "schema_version";
    private static final int SCHEMA_VERSION = 2;

    private static final long ORPHAN_TMP_AGE_MS = 60L * 60 * 1000;

    private static volatile List<Note> cachedIndex = null;
    private static final Object cacheLock = new Object();

    private static final Object migrationLock = new Object();

    private final Context context;
    private final File notesDir;
    private final File indexPath;
    private final File oldSingleFile;

    public NoteStorage(Context context) {
        this.context = context.getApplicationContext();
        this.notesDir = new File(context.getFilesDir(), "notes");
        this.indexPath = new File(context.getFilesDir(), "index.enc");
        this.oldSingleFile = new File(context.getFilesDir(), "notes.enc");
        if (!notesDir.exists()) notesDir.mkdirs();
    }

    public static void invalidateCache() {
        synchronized (cacheLock) { cachedIndex = null; }
    }

    public static Note copyOf(Note src) {
        if (src == null) return null;
        Note n = new Note();
        n.id = src.id;
        n.title = src.title;
        n.content = src.content;
        n.timestamp = src.timestamp;
        n.pinned = src.pinned;
        n.deleted = src.deleted;
        n.deletedAt = src.deletedAt;
        n.contentLoaded = src.contentLoaded;
        n.attachments = src.attachments != null
            ? new ArrayList<>(src.attachments)
            : new ArrayList<>();
        return n;
    }

    // ============ Journal (отложенные hard-delete) ============

    public static File getJournalDir(Context ctx) {
        File dir = new File(ctx.getFilesDir(), "journal");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    public static File getJournalFile(Context ctx, String id) {
        if (id == null) return null;
        return new File(getJournalDir(ctx), id + ".enc");
    }

    /**
     * Переносит notes/<id>.enc в journal/<id>.enc.
     * Используется при hard-delete вместо физического удаления.
     */
    public static boolean moveToJournal(Context ctx, String id) {
        if (id == null) return false;
        File src = new File(ctx.getFilesDir(), "notes/" + id + ".enc");
        File dst = getJournalFile(ctx, id);
        if (!src.exists()) return false;
        if (dst.exists()) dst.delete();
        return src.renameTo(dst);
    }

    /**
     * Возвращает journal/<id>.enc обратно в notes/<id>.enc.
     * Используется при отмене hard-delete.
     */
    public static boolean restoreFromJournal(Context ctx, String id) {
        if (id == null) return false;
        File src = getJournalFile(ctx, id);
        File dst = new File(ctx.getFilesDir(), "notes/" + id + ".enc");
        if (!src.exists()) return false;
        if (dst.exists()) dst.delete();
        return src.renameTo(dst);
    }

    /** Окончательно удаляет journal/<id>.enc. */
    public static void deleteJournalFile(Context ctx, String id) {
        if (id == null) return;
        File f = getJournalFile(ctx, id);
        if (f != null && f.exists()) f.delete();
    }

    /** Удаляет все файлы в journal/. */
    public static void clearJournalDir(Context ctx) {
        File dir = getJournalDir(ctx);
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) f.delete();
    }

    // ============ Async API ============

    public interface ListCallback { void onResult(List<Note> notes); }
    public interface NoteCallback { void onResult(Note note); }
    public interface VoidCallback { void onDone(); }

    public void loadAsync(ListCallback cb) {
        if (cb == null) return;
        AppExecutors.get().crypto().execute(() -> {
            final List<Note> result = load();
            AppExecutors.get().runOnMain(() -> cb.onResult(result));
        });
    }

    public void loadFullAsync(String id, NoteCallback cb) {
        if (cb == null) return;
        if (id == null) {
            AppExecutors.get().runOnMain(() -> cb.onResult(null));
            return;
        }
        AppExecutors.get().crypto().execute(() -> {
            final Note result = loadFull(id);
            AppExecutors.get().runOnMain(() -> cb.onResult(result));
        });
    }

    public void saveOneAsync(Note n, VoidCallback cb) {
        if (n == null) {
            if (cb != null) AppExecutors.get().runOnMain(cb::onDone);
            return;
        }
        final Note copy = copyOf(n);
        AppExecutors.get().crypto().execute(() -> {
            saveOne(copy);
            if (cb != null) AppExecutors.get().runOnMain(cb::onDone);
        });
    }

    public void saveAsync(List<Note> notes, VoidCallback cb) {
        if (notes == null) {
            if (cb != null) AppExecutors.get().runOnMain(cb::onDone);
            return;
        }
        final List<Note> copies = new ArrayList<>(notes.size());
        for (Note n : notes) {
            Note c = copyOf(n);
            if (c != null) copies.add(c);
        }
        AppExecutors.get().crypto().execute(() -> {
            save(copies);
            if (cb != null) AppExecutors.get().runOnMain(cb::onDone);
        });
    }

    // ============ Migration ============

    public void migrateIfNeeded() {
        synchronized (migrationLock) {
            try {
                int schema = prefs().getInt(KEY_SCHEMA_VERSION, 1);
                if (schema >= SCHEMA_VERSION) return;

                invalidateCache();

                if (oldSingleFile.exists() && oldSingleFile.length() > 0) {
                    byte[] data = readAll(oldSingleFile);
                    byte[] dk = MasterKeyManager.getDataKey(context);
                    byte[] plain;
                    if (MasterKeyManager.hasMagicHeader(data)) {
                        plain = MasterKeyManager.unpackWithHeader(dk, data);
                    } else {
                        plain = MasterKeyManager.aesDecryptStatic(dk, data);
                    }
                    JSONArray arr = new JSONArray(new String(plain, StandardCharsets.UTF_8));
                    List<Note> notes = new ArrayList<>();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        Note n = new Note();
                        n.id = o.optString("id", "");
                        n.title = o.optString("title", "");
                        n.content = o.optString("content", "");
                        n.timestamp = o.optLong("timestamp", 0);
                        n.pinned = o.optBoolean("pinned", false);
                        n.deleted = o.optBoolean("deleted", false);
                        n.deletedAt = o.optLong("deletedAt", 0);
                        JSONArray atts = o.optJSONArray("attachments");
                        if (atts != null) for (int j = 0; j < atts.length(); j++)
                            n.attachments.add(atts.getString(j));
                        n.contentLoaded = true;
                        notes.add(n);
                    }
                    for (Note n : notes) writeNoteFile(n);
                    writeIndex(notes);
                    oldSingleFile.delete();
                } else if (!indexPath.exists()) {
                    writeIndex(new ArrayList<>());
                }

                prefs().edit().putInt(KEY_SCHEMA_VERSION, SCHEMA_VERSION).commit();
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
                LOAD_FAILED = true;
            }
        }
    }

    // ============ Load ============

    public List<Note> load() {
        synchronized (cacheLock) {
            if (cachedIndex != null) {
                LOAD_FAILED = false;
                List<Note> result = new ArrayList<>(cachedIndex.size());
                for (Note n : cachedIndex) result.add(copyOf(n));
                sortPinnedFirst(result);
                return result;
            }
        }

        try {
            migrateIfNeeded();
            if (LOAD_FAILED) return null;

            if (!indexPath.exists() || indexPath.length() == 0) {
                LOAD_FAILED = false;
                synchronized (cacheLock) {
                    if (cachedIndex == null) cachedIndex = new ArrayList<>();
                    List<Note> result = new ArrayList<>(cachedIndex.size());
                    for (Note n : cachedIndex) result.add(copyOf(n));
                    sortPinnedFirst(result);
                    return result;
                }
            }

            List<Note> notes = loadIndexFromDisk();
            if (notes == null) return null;
            sortPinnedFirst(notes);
            LOAD_FAILED = false;

            synchronized (cacheLock) {
                if (cachedIndex == null) {
                    cachedIndex = new ArrayList<>(notes);
                }
                List<Note> result = new ArrayList<>(cachedIndex.size());
                for (Note n : cachedIndex) result.add(copyOf(n));
                sortPinnedFirst(result);
                return result;
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            LOAD_FAILED = true;
            return null;
        }
    }

    private List<Note> loadIndexFromDisk() throws Exception {
        byte[] data = readAll(indexPath);
        byte[] dk = MasterKeyManager.getDataKey(context);
        byte[] plain;
        if (MasterKeyManager.hasMagicHeader(data)) {
            plain = MasterKeyManager.unpackWithHeader(dk, data);
        } else {
            plain = MasterKeyManager.aesDecryptStatic(dk, data);
        }
        JSONArray arr = new JSONArray(new String(plain, StandardCharsets.UTF_8));
        List<Note> notes = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Note n = new Note();
            n.id = o.optString("id", "");
            n.title = o.optString("title", "");
            n.content = o.optString("preview", "");
            n.timestamp = o.optLong("timestamp", 0);
            n.pinned = o.optBoolean("pinned", false);
            n.deleted = o.optBoolean("deleted", false);
            n.deletedAt = o.optLong("deletedAt", 0);
            n.contentLoaded = false;
            notes.add(n);
        }
        return notes;
    }

    public Note loadFull(String id) {
        if (id == null) return null;
        try {
            File f = new File(notesDir, id + ".enc");
            if (!f.exists()) return null;
            byte[] data = readAll(f);
            byte[] dk = MasterKeyManager.getDataKey(context);
            byte[] plain;
            if (MasterKeyManager.hasMagicHeader(data)) {
                plain = MasterKeyManager.unpackWithHeader(dk, data);
            } else {
                plain = MasterKeyManager.aesDecryptStatic(dk, data);
            }
            JSONObject o = new JSONObject(new String(plain, StandardCharsets.UTF_8));
            Note n = new Note();
            n.id = o.optString("id", "");
            n.title = o.optString("title", "");
            n.content = o.optString("content", "");
            n.timestamp = o.optLong("timestamp", 0);
            n.pinned = o.optBoolean("pinned", false);
            n.deleted = o.optBoolean("deleted", false);
            n.deletedAt = o.optLong("deletedAt", 0);
            JSONArray atts = o.optJSONArray("attachments");
            if (atts != null) for (int j = 0; j < atts.length(); j++)
                n.attachments.add(atts.getString(j));
            n.contentLoaded = true;
            return n;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return null;
        }
    }

    // ============ Save ============

    public void save(List<Note> notes) {
        if (notes == null) return;
        if (LOAD_FAILED) return;
        try {
            List<Note> sorted = new ArrayList<>(notes);
            sortPinnedFirst(sorted);

            java.util.Set<String> aliveIds = new java.util.HashSet<>();
            for (Note n : sorted) {
                if (n != null && n.id != null) aliveIds.add(n.id);
            }
            File[] existing = notesDir.listFiles();
            if (existing != null) {
                for (File f : existing) {
                    String name = f.getName();
                    if (name.startsWith(".")) continue;
                    if (!name.endsWith(".enc")) continue;
                    String id = name.substring(0, name.length() - 4);
                    if (!aliveIds.contains(id)) {
                        // ★ ВАЖНО: здесь НЕ удаляем файл, если это hard-delete.
                        // При hard-delete файл уже перенесён в journal/ — здесь
                        // его просто нет в notes/. Удалять нечего.
                        //
                        // Файл, которого нет в индексе и нет в journal/ —
                        // это осиротевший файл. Удаляем его.
                        File journalCopy = getJournalFile(context, id);
                        if (journalCopy == null || !journalCopy.exists()) {
                            f.delete();
                            File tmp = new File(notesDir, "." + id + ".tmp");
                            if (tmp.exists()) tmp.delete();
                        }
                    }
                }
            }

            for (Note n : sorted) {
                if (n != null && n.contentLoaded) writeNoteFile(n);
            }

            synchronized (cacheLock) {
                writeIndex(sorted);
            }
            LOAD_FAILED = false;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            LOAD_FAILED = true;
        }
    }

    public void saveOne(Note n) {
        if (n == null) return;
        if (LOAD_FAILED) return;
        try {
            writeNoteFile(n);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            LOAD_FAILED = true;
            return;
        }

        synchronized (cacheLock) {
            try {
                List<Note> notes;
                if (cachedIndex != null) {
                    notes = new ArrayList<>(cachedIndex.size());
                    for (Note c : cachedIndex) notes.add(copyOf(c));
                } else {
                    notes = loadIndexFromDisk();
                    if (notes == null) notes = new ArrayList<>();
                }

                boolean found = false;
                for (int i = 0; i < notes.size(); i++) {
                    Note existing = notes.get(i);
                    if (existing != null && existing.id != null && existing.id.equals(n.id)) {
                        notes.set(i, copyOf(n));
                        found = true;
                        break;
                    }
                }
                if (!found) notes.add(copyOf(n));

                writeIndex(notes);
                LOAD_FAILED = false;
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
                LOAD_FAILED = true;
            }
        }
    }

    private void writeNoteFile(Note n) throws Exception {
        if (n == null || n.id == null) return;
        JSONObject o = new JSONObject();
        o.put("id", n.id);
        o.put("title", n.title);
        o.put("content", n.content);
        o.put("timestamp", n.timestamp);
        o.put("pinned", n.pinned);
        o.put("deleted", n.deleted);
        o.put("deletedAt", n.deletedAt);
        JSONArray atts = new JSONArray();
        if (n.attachments != null) {
            for (String s : n.attachments) atts.put(s);
        }
        o.put("attachments", atts);

        byte[] dk = MasterKeyManager.getDataKey(context);
        byte[] enc = MasterKeyManager.packWithHeader(dk,
            o.toString().getBytes(StandardCharsets.UTF_8));

        File dest = new File(notesDir, n.id + ".enc");
        File tmp = new File(notesDir, "." + n.id + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(enc);
            out.getFD().sync();
        }
        if (!tmp.renameTo(dest)) {
            tmp.delete();
            throw new IOException("rename failed for " + n.id);
        }
    }

    private void writeIndex(List<Note> notes) throws Exception {
        JSONArray arr = new JSONArray();
        if (notes != null) {
            for (Note n : notes) {
                if (n == null || n.id == null) continue;
                JSONObject o = new JSONObject();
                o.put("id", n.id);
                o.put("title", n.title);
                String preview = n.content != null ? n.content.replace("\n", " ").trim() : "";
                if (preview.length() > 120) preview = preview.substring(0, 120) + "…";
                o.put("preview", preview);
                o.put("timestamp", n.timestamp);
                o.put("pinned", n.pinned);
                o.put("deleted", n.deleted);
                o.put("deletedAt", n.deletedAt);
                arr.put(o);
            }
        }
        byte[] dk = MasterKeyManager.getDataKey(context);
        byte[] enc = MasterKeyManager.packWithHeader(dk,
            arr.toString().getBytes(StandardCharsets.UTF_8));

        File parent = indexPath.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        File tmp = new File(parent, ".index.tmp");

        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(enc);
            out.getFD().sync();
        }
        if (!tmp.renameTo(indexPath)) {
            tmp.delete();
            throw new IOException("index rename failed");
        }

        synchronized (cacheLock) {
            cachedIndex = new ArrayList<>();
            if (notes != null) {
                for (Note src : notes) {
                    Note c = copyOf(src);
                    if (c != null) cachedIndex.add(c);
                }
            }
        }
    }

    // ============ Sort ============

    public static void sortPinnedFirst(List<Note> notes) {
        if (notes == null) return;
        notes.sort(new Comparator<Note>() {
            public int compare(Note a, Note b) {
                if (a == null && b == null) return 0;
                if (a == null) return 1;
                if (b == null) return -1;
                if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
                return Long.compare(b.timestamp, a.timestamp);
            }
        });
    }

    // ============ Orphan cleanup ============

    public static void cleanupOrphanTmp(Context ctx) {
        if (ctx == null) return;
        try {
            long now = System.currentTimeMillis();

            File filesDir = ctx.getFilesDir();
            File indexTmp = new File(filesDir, ".index.tmp");
            if (indexTmp.exists() && now - indexTmp.lastModified() > ORPHAN_TMP_AGE_MS) {
                indexTmp.delete();
            }
            File journalTmp = new File(filesDir, ".journal.tmp");
            if (journalTmp.exists() && now - journalTmp.lastModified() > ORPHAN_TMP_AGE_MS) {
                journalTmp.delete();
            }

            File notesDir = new File(filesDir, "notes");
            if (notesDir.exists()) {
                File[] files = notesDir.listFiles();
                if (files != null) {
                    for (File f : files) {
                        String name = f.getName();
                        if (name.startsWith(".") && name.endsWith(".tmp")) {
                            if (now - f.lastModified() > ORPHAN_TMP_AGE_MS) {
                                f.delete();
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    // ============ Helpers ============

    private SharedPreferences prefs() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static byte[] readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }
}