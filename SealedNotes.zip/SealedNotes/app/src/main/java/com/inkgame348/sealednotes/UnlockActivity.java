package com.inkgame348.sealednotes;

import android.content.Intent;
import android.os.Bundle;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.concurrent.Executor;

import javax.crypto.Cipher;

public class UnlockActivity extends AppCompatActivity {

    private EditText passwordField;
    private Button unlockBtn;
    private Button biometricBtn;
    private TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        if (!MasterKeyManager.isLocked(this)) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_unlock);
        passwordField = findViewById(R.id.unlock_password);
        unlockBtn = findViewById(R.id.unlock_button);
        biometricBtn = findViewById(R.id.unlock_biometric);
        hint = findViewById(R.id.unlock_hint);

        boolean hasPwd = MasterKeyManager.hasPassword(this);
        boolean hasBio = MasterKeyManager.hasBiometric(this);

        if (hasPwd) {
            hint.setText(R.string.unlock_hint_password);
            passwordField.setVisibility(View.VISIBLE);
            unlockBtn.setVisibility(View.VISIBLE);
        } else {
            hint.setText(R.string.unlock_hint_biometric);
            passwordField.setVisibility(View.GONE);
            unlockBtn.setVisibility(View.GONE);
        }

        if (hasBio) {
            biometricBtn.setVisibility(View.VISIBLE);
        } else {
            biometricBtn.setVisibility(View.GONE);
        }

        unlockBtn.setOnClickListener(v -> {
            String pwd = passwordField.getText().toString();
            if (pwd.isEmpty()) return;
            if (MasterKeyManager.unlockWithPassword(this, pwd)) {
                if (MasterKeyManager.hasBiometric(this)
                    && !MasterKeyManager.isBiometricHealthy(this)) {
                    promptRebindBiometric();
                } else {
                    goToMain();
                }
            } else {
                ToastHelper.show(this, getString(R.string.unlock_wrong_password));
                passwordField.setText("");
            }
        });

        biometricBtn.setOnClickListener(v -> promptBiometric());

        if (hasBio && !hasPwd) {
            promptBiometric();
        }
    }

    private boolean isBiometricAvailable() {
        BiometricManager bm = BiometricManager.from(this);
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            == BiometricManager.BIOMETRIC_SUCCESS;
    }

    /**
     * ★ ФИКС: безопасный разбор wrapped (проверка границ IV).
     * ★ ФИКС: обработка отмены биометрии — не оставляем пустой экран.
     */
    private void promptBiometric() {
        byte[] wrapped = MasterKeyManager.getBiometricWrapped(this);
        if (wrapped == null || wrapped.length < 2) {
            autoRebindBiometric();
            return;
        }
        int ivLen = wrapped[0] & 0xFF;
        // ★ КРИТИЧНО: проверка границ ★
        if (ivLen < 1 || ivLen > wrapped.length - 1) {
            ToastHelper.show(this, getString(R.string.error_keystore));
            autoRebindBiometric();
            return;
        }
        byte[] iv = new byte[ivLen];
        System.arraycopy(wrapped, 1, iv, 0, ivLen);
        byte[] ct = new byte[wrapped.length - 1 - ivLen];
        System.arraycopy(wrapped, 1 + ivLen, ct, 0, ct.length);

        Cipher cipher;
        try {
            cipher = KeyStoreHelper.getBiometricDecryptCipher(iv);
        } catch (KeyPermanentlyInvalidatedException e) {
            handleInvalidatedKey();
            return;
        } catch (Exception e) {
            new AnimDialog(this)
                .setTitle(R.string.error_biometric)
                .setMessage(e.getClass().getSimpleName() + ": " + e.getMessage())
                .setPositiveButton(android.R.string.ok, (d, w) -> {
                    if (MasterKeyManager.hasPassword(UnlockActivity.this)) {
                        passwordField.setVisibility(View.VISIBLE);
                        unlockBtn.setVisibility(View.VISIBLE);
                        biometricBtn.setVisibility(View.GONE);
                        hint.setText(R.string.unlock_hint_password);
                    }
                })
                .show();
            return;
        }

        if (!isBiometricAvailable()) {
            if (MasterKeyManager.hasPassword(this)) {
                passwordField.setVisibility(View.VISIBLE);
                unlockBtn.setVisibility(View.VISIBLE);
                biometricBtn.setVisibility(View.GONE);
                hint.setText(R.string.unlock_hint_password);
            }
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        Cipher c = result.getCryptoObject().getCipher();
                        byte[] dk = c.doFinal(ct);
                        MasterKeyManager.setBiometricUnlocked(dk);
                        MasterKeyManager.markBiometricHealthy(UnlockActivity.this);
                        goToMain();
                    } catch (Exception e) {
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.toast_error, e.getMessage()));
                    }
                }

                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    // ★ ФИКС: при отмене показываем пароль, если есть ★
                    if (MasterKeyManager.hasPassword(UnlockActivity.this)) {
                        passwordField.setVisibility(View.VISIBLE);
                        unlockBtn.setVisibility(View.VISIBLE);
                        biometricBtn.setVisibility(View.GONE);
                        hint.setText(R.string.unlock_hint_password);
                    }
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_biometric_title))
            .setSubtitle(getString(R.string.unlock_biometric_subtitle))
            .setNegativeButtonText(getString(R.string.cancel))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG);

        prompt.authenticate(b.build(), new BiometricPrompt.CryptoObject(cipher));
    }

    private void handleInvalidatedKey() {
        MasterKeyManager.markBiometricBroken(this);

        if (!MasterKeyManager.hasPassword(this)) {
            autoRebindBiometric();
            return;
        }

        new AnimDialog(this)
            .setTitle(R.string.biometric_invalidated_title)
            .setMessage(R.string.biometric_invalidated_msg)
            .setPositiveButton(R.string.biometric_enter_password, (d, w) -> {
                passwordField.setVisibility(View.VISIBLE);
                unlockBtn.setVisibility(View.VISIBLE);
                biometricBtn.setVisibility(View.GONE);
                hint.setText(R.string.biometric_enter_password_hint);
                passwordField.requestFocus();
            })
            .setNegativeButton(android.R.string.cancel, null)
            .setCancelable(false)
            .show();
    }

    private void autoRebindBiometric() {
        if (!isBiometricAvailable()) {
            try {
                MasterKeyManager.getDataKey(UnlockActivity.this);
                goToMain();
            } catch (Exception e) {
                ToastHelper.show(this, getString(R.string.toast_error, e.getMessage()));
            }
            return;
        }

        try {
            MasterKeyManager.removeBiometric(this);
        } catch (Exception ignored) {}

        Cipher cipher;
        try {
            cipher = KeyStoreHelper.getBiometricEncryptCipher();
        } catch (Exception e) {
            try {
                MasterKeyManager.getDataKey(UnlockActivity.this);
                goToMain();
            } catch (Exception ex) {
                ToastHelper.show(this, getString(R.string.toast_error, ex.getMessage()));
            }
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        Cipher c = result.getCryptoObject().getCipher();
                        byte[] dk = MasterKeyManager.getDkForBiometricWrap(UnlockActivity.this);
                        byte[] ct = c.doFinal(dk);
                        byte[] iv = c.getIV();
                        byte[] out = new byte[1 + iv.length + ct.length];
                        out[0] = (byte) iv.length;
                        System.arraycopy(iv, 0, out, 1, iv.length);
                        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
                        MasterKeyManager.saveBiometricWrapped(UnlockActivity.this, out);
                        MasterKeyManager.markBiometricHealthy(UnlockActivity.this);
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.biometric_rebind_done));
                    } catch (Exception e) {
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.toast_error, e.getMessage()));
                    }
                    goToMain();
                }

                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    try {
                        MasterKeyManager.getDataKey(UnlockActivity.this);
                        goToMain();
                    } catch (Exception e) {
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.toast_error, e.getMessage()));
                    }
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_rebind_title))
            .setSubtitle(getString(R.string.biometric_enable_subtitle))
            .setNegativeButtonText(getString(R.string.cancel))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG);

        prompt.authenticate(b.build(), new BiometricPrompt.CryptoObject(cipher));
    }

    private void promptRebindBiometric() {
        new AnimDialog(this)
            .setTitle(R.string.biometric_rebind_title)
            .setMessage(R.string.biometric_rebind_msg)
            .setPositiveButton(R.string.biometric_rebind_confirm, (d, w) -> {
                try {
                    MasterKeyManager.removeBiometric(this);
                    rebindBiometric();
                } catch (Exception e) {
                    ToastHelper.show(this, getString(R.string.toast_error, e.getMessage()));
                    goToMain();
                }
            })
            .setNegativeButton(R.string.cancel, (d, w) -> goToMain())
            .setCancelable(false)
            .show();
    }

    private void rebindBiometric() {
        Cipher cipher;
        try {
            cipher = KeyStoreHelper.getBiometricEncryptCipher();
        } catch (Exception e) {
            ToastHelper.show(this, getString(R.string.error_keystore) + ": " + e.getMessage());
            goToMain();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        Cipher c = result.getCryptoObject().getCipher();
                        byte[] dk = MasterKeyManager.getDkForBiometricWrap(UnlockActivity.this);
                        byte[] ct = c.doFinal(dk);
                        byte[] iv = c.getIV();
                        byte[] out = new byte[1 + iv.length + ct.length];
                        out[0] = (byte) iv.length;
                        System.arraycopy(iv, 0, out, 1, iv.length);
                        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
                        MasterKeyManager.saveBiometricWrapped(UnlockActivity.this, out);
                        MasterKeyManager.markBiometricHealthy(UnlockActivity.this);
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.biometric_rebind_done));
                    } catch (Exception e) {
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.toast_error, e.getMessage()));
                    }
                    goToMain();
                }

                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    goToMain();
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_rebind_title))
            .setSubtitle(getString(R.string.biometric_enable_subtitle))
            .setNegativeButtonText(getString(R.string.cancel))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG);

        prompt.authenticate(b.build(), new BiometricPrompt.CryptoObject(cipher));
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}