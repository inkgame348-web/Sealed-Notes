package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class MasterKeyManager {

    private static final String PREFS = "sealednotes_lock";
    private static final String KEY_LAST_ACTIVE = "last_active";

    private static final String KEY_DK_FALLBACK = "dk_fallback";
    private static final String KEY_DK_PASSWORD = "dk_password";
    private static final String KEY_DK_BIOMETRIC = "dk_biometric";

    private static final String KEY_HAS_PASSWORD = "has_password";
    private static final String KEY_HAS_BIOMETRIC = "has_biometric";

    private static final String KEY_DK_PIN = "dk_pin";
    private static final String KEY_HAS_PIN = "has_pin";

    private static final String KEY_BIOMETRIC_HEALTHY = "biometric_healthy";
    private static final String KEY_AUTOLOCK_MS = "autolock_ms";

    private static final int PBKDF2_ITERATIONS = 600_000;
    private static final int SALT_LEN = 16;
    private static final int GCM_TAG_BITS = 128;

    public static final long AUTOLOCK_OFF = 0;
    public static final long AUTOLOCK_DEFAULT = 5L * 60 * 1000;

    private static final long MARK_ACTIVE_INTERVAL_MS = 5_000;
    private static final AtomicLong lastMarkActive = new AtomicLong(0);

    private static final Object keyLock = new Object();
    private static volatile byte[] memoryKey = null;
    /**
     * ★ true, если memoryKey установлен фоновым Worker'ом (не пользователем).
     * isUnlocked() такой ключ за разблокировку не считает.
     */
    private static volatile boolean memoryKeyIsEphemeral = false;
    /**
     * ★ Счётчик активных Worker'ов, держащих эфемерный ключ.
     * Ключ освобождается, когда счётчик падает до нуля.
     */
    private static final AtomicInteger ephemeralRefs = new AtomicInteger(0);

    private static final String LEGACY_BIOMETRIC_ALIAS_V2 = "SealedNotesBiometricKey_v2";
    private static final String LEGACY_BIOMETRIC_ALIAS_V1 = "SealedNotesBiometricKey";

    // ============ Status ============

    public static boolean hasPassword(Context c) {
        return prefs(c).getBoolean(KEY_HAS_PASSWORD, false);
    }

    public static boolean hasBiometric(Context c) {
        return prefs(c).getBoolean(KEY_HAS_BIOMETRIC, false);
    }

    public static boolean isProtectionEnabled(Context c) {
        return hasBiometric(c);
    }

    public static boolean isBiometricHealthy(Context c) {
        return prefs(c).getBoolean(KEY_BIOMETRIC_HEALTHY, true);
    }

    public static void markBiometricHealthy(Context c) {
        prefs(c).edit().putBoolean(KEY_BIOMETRIC_HEALTHY, true).apply();
    }

    /** Возвращает true только если разблокировано пользователем (не Worker'ом). */
    public static boolean isUnlocked() {
        synchronized (keyLock) {
            return memoryKey != null && !memoryKeyIsEphemeral;
        }
    }

    /** Внутренний: есть ли ключ в памяти вообще (включая эфемерный). */
    public static boolean hasMemoryKey() {
        synchronized (keyLock) { return memoryKey != null; }
    }

    public static boolean isLocked(Context c) {
        return !isUnlocked() && isProtectionEnabled(c);
    }

    // ============ Auto-lock ============

    public static long getAutoLockMs(Context c) {
        return prefs(c).getLong(KEY_AUTOLOCK_MS, AUTOLOCK_DEFAULT);
    }

    public static void setAutoLockMs(Context c, long ms) {
        prefs(c).edit().putLong(KEY_AUTOLOCK_MS, ms).commit();
    }

    public static void markActive(Context c) {
        long now = System.currentTimeMillis();
        long prev = lastMarkActive.get();
        if (now - prev < MARK_ACTIVE_INTERVAL_MS) return;
        prefs(c).edit().putLong(KEY_LAST_ACTIVE, now).apply();
        lastMarkActive.set(now);
    }

    public static boolean isAutoLockExpired(Context c) {
        long autoLock = getAutoLockMs(c);
        if (autoLock <= 0) return false;
        long last = prefs(c).getLong(KEY_LAST_ACTIVE, System.currentTimeMillis());
        return System.currentTimeMillis() - last > autoLock;
    }

    // ============ Init / Migration ============

    public static void initializeIfNeeded(Context c) throws Exception {
        synchronized (keyLock) {
            migrateLegacyKeys(c);

            if (prefs(c).contains(KEY_DK_FALLBACK)) {
                if (memoryKey == null && !isProtectionEnabled(c)) {
                    String s = prefs(c).getString(KEY_DK_FALLBACK, null);
                    if (s != null) {
                        try {
                            byte[] dkEnc = Base64.decode(s, Base64.NO_WRAP);
                            memoryKey = KeyStoreHelper.decryptFallback(dkEnc);
                            memoryKeyIsEphemeral = false;
                        } catch (Exception e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }
                    }
                }
                return;
            }

            byte[] dk = new byte[32];
            new SecureRandom().nextBytes(dk);

            File notesFile = new File(c.getFilesDir(), "notes.enc");
            if (notesFile.exists() && notesFile.length() > 0 && KeyStoreHelper.hasOldKey()) {
                try {
                    byte[] oldData = readAll(notesFile);
                    byte[] plain = KeyStoreHelper.decryptOld(oldData);
                    byte[] newData = packWithHeader(dk, plain);
                    writeAll(notesFile, newData);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) e.printStackTrace();
                }
            }

            byte[] dkEnc = KeyStoreHelper.encryptFallback(dk);
            prefs(c).edit().putString(KEY_DK_FALLBACK,
                Base64.encodeToString(dkEnc, Base64.NO_WRAP)).commit();

            memoryKey = dk;
            memoryKeyIsEphemeral = false;
        }
    }

    private static void migrateLegacyKeys(Context c) {
        boolean needReset = false;
        boolean needPrefsCommit = false;

        SharedPreferences.Editor editor = prefs(c).edit();

        if (prefs(c).contains(KEY_HAS_PIN) || prefs(c).contains(KEY_DK_PIN)) {
            editor.remove(KEY_HAS_PIN).remove(KEY_DK_PIN);
            needPrefsCommit = true;
        }

        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            boolean hasLegacy = ks.containsAlias(LEGACY_BIOMETRIC_ALIAS_V1)
                || ks.containsAlias(LEGACY_BIOMETRIC_ALIAS_V2);

            if (hasLegacy) {
                needReset = true;
                if (ks.containsAlias(LEGACY_BIOMETRIC_ALIAS_V1)) {
                    ks.deleteEntry(LEGACY_BIOMETRIC_ALIAS_V1);
                }
                if (ks.containsAlias(LEGACY_BIOMETRIC_ALIAS_V2)) {
                    ks.deleteEntry(LEGACY_BIOMETRIC_ALIAS_V2);
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        boolean hasPwd = prefs(c).getBoolean(KEY_HAS_PASSWORD, false);
        boolean hasBio = prefs(c).getBoolean(KEY_HAS_BIOMETRIC, false);
        if (hasPwd && !hasBio) {
            needReset = true;
        }

        if (needReset) {
            editor.remove(KEY_DK_BIOMETRIC)
                .remove(KEY_DK_PASSWORD)
                .putBoolean(KEY_HAS_BIOMETRIC, false)
                .putBoolean(KEY_HAS_PASSWORD, false)
                .putBoolean(KEY_BIOMETRIC_HEALTHY, true);
            needPrefsCommit = true;
        }

        if (needPrefsCommit) {
            editor.commit();
        }
    }

    public static byte[] getDataKey(Context c) throws Exception {
        synchronized (keyLock) {
            if (memoryKey != null) return Arrays.copyOf(memoryKey, memoryKey.length);

            if (!isProtectionEnabled(c)) {
                String s = prefs(c).getString(KEY_DK_FALLBACK, null);
                if (s == null) throw new Exception("DK missing");
                byte[] dkEnc = Base64.decode(s, Base64.NO_WRAP);
                byte[] dk = KeyStoreHelper.decryptFallback(dkEnc);
                if (memoryKey == null) {
                    memoryKey = dk;
                    memoryKeyIsEphemeral = false;
                }
                return Arrays.copyOf(memoryKey, memoryKey.length);
            }
            throw new Exception("LOCKED");
        }
    }

    /**
     * Возвращает DK через fallback-ключ Keystore БЕЗ установки memoryKey.
     * Используется BackupConfig для расшифровки пароля бэкапа в фоне.
     */
    public static byte[] getDataKeyUnprotected(Context c) throws Exception {
        String s = prefs(c).getString(KEY_DK_FALLBACK, null);
        if (s == null) throw new Exception("DK missing");
        byte[] dkEnc = Base64.decode(s, Base64.NO_WRAP);
        return KeyStoreHelper.decryptFallback(dkEnc);
    }

    // ============ Biometric ============

    public static void enableBiometric(Context c, byte[] wrappedDk) throws Exception {
        if (hasBiometric(c)) {
            throw new IllegalStateException("Biometric already enabled");
        }
        if (wrappedDk == null || wrappedDk.length == 0) {
            throw new IllegalArgumentException("wrappedDk is empty");
        }
        prefs(c).edit()
            .putString(KEY_DK_BIOMETRIC,
                Base64.encodeToString(wrappedDk, Base64.NO_WRAP))
            .putBoolean(KEY_HAS_BIOMETRIC, true)
            .putBoolean(KEY_BIOMETRIC_HEALTHY, true)
            .commit();
    }

    public static void refreshBiometricWrapped(Context c, byte[] wrapped) {
        prefs(c).edit()
            .putString(KEY_DK_BIOMETRIC,
                Base64.encodeToString(wrapped, Base64.NO_WRAP))
            .putBoolean(KEY_BIOMETRIC_HEALTHY, true)
            .commit();
    }

    public static void disableBiometric(Context c) throws Exception {
        if (hasPassword(c)) {
            throw new IllegalStateException("Remove password first");
        }
        prefs(c).edit()
            .remove(KEY_DK_BIOMETRIC)
            .putBoolean(KEY_HAS_BIOMETRIC, false)
            .putBoolean(KEY_BIOMETRIC_HEALTHY, true)
            .commit();
        try {
            KeyStoreHelper.deleteBiometricKey();
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    // ============ Password ============

    public static void setPassword(Context c, String password) throws Exception {
        if (!hasBiometric(c)) {
            throw new IllegalStateException("Biometric must be enabled");
        }
        if (hasPassword(c)) {
            throw new IllegalStateException("Password already set");
        }

        byte[] dk = getDataKey(c);
        byte[] salt = new byte[SALT_LEN];
        new SecureRandom().nextBytes(salt);
        byte[] key = deriveKey(password, salt);
        byte[] enc = aesEncrypt(key, dk);
        byte[] pwdBlob = new byte[SALT_LEN + enc.length];
        System.arraycopy(salt, 0, pwdBlob, 0, SALT_LEN);
        System.arraycopy(enc, 0, pwdBlob, SALT_LEN, enc.length);

        prefs(c).edit()
            .putString(KEY_DK_PASSWORD,
                Base64.encodeToString(pwdBlob, Base64.NO_WRAP))
            .putBoolean(KEY_HAS_PASSWORD, true)
            .commit();
    }

    public static boolean changePassword(Context c, String oldPwd, String newPwd)
            throws Exception {
        if (!hasPassword(c)) return false;
        if (!verifyPassword(c, oldPwd)) return false;

        byte[] dk = getDataKey(c);
        byte[] salt = new byte[SALT_LEN];
        new SecureRandom().nextBytes(salt);
        byte[] key = deriveKey(newPwd, salt);
        byte[] enc = aesEncrypt(key, dk);
        byte[] pwdBlob = new byte[SALT_LEN + enc.length];
        System.arraycopy(salt, 0, pwdBlob, 0, SALT_LEN);
        System.arraycopy(enc, 0, pwdBlob, SALT_LEN, enc.length);

        prefs(c).edit()
            .putString(KEY_DK_PASSWORD,
                Base64.encodeToString(pwdBlob, Base64.NO_WRAP))
            .commit();
        return true;
    }

    public static boolean removePasswordWithAuth(Context c, String pwd) {
        if (!hasPassword(c)) return false;
        if (!verifyPassword(c, pwd)) return false;

        prefs(c).edit()
            .remove(KEY_DK_PASSWORD)
            .putBoolean(KEY_HAS_PASSWORD, false)
            .commit();
        return true;
    }

    // ============ Unlock ============

    public static boolean verifyPassword(Context c, String password) {
        return verifyWrapped(c, KEY_DK_PASSWORD, password);
    }

    public static boolean unlockWithPassword(Context c, String password) {
        return unlockWithWrapped(c, KEY_DK_PASSWORD, password);
    }

    public static byte[] getBiometricWrapped(Context c) {
        String s = prefs(c).getString(KEY_DK_BIOMETRIC, null);
        if (s == null) return null;
        return Base64.decode(s, Base64.NO_WRAP);
    }

    /** Устанавливает ключ как результат аутентификации пользователя. */
    public static void setBiometricUnlocked(byte[] dk) {
        synchronized (keyLock) {
            memoryKey = Arrays.copyOf(dk, dk.length);
            memoryKeyIsEphemeral = false;
            ephemeralRefs.set(0);
        }
    }

    /**
     * ★ Устанавливает эфемерный ключ (для фоновых Worker'ов).
     * isUnlocked() такой ключ за разблокировку не считает.
     * Увеличивает счётчик активных держателей.
     */
    public static void setEphemeralUnlocked(byte[] dk) {
        synchronized (keyLock) {
            memoryKey = Arrays.copyOf(dk, dk.length);
            memoryKeyIsEphemeral = true;
            ephemeralRefs.incrementAndGet();
        }
    }

    /**
     * ★ Уменьшает счётчик. Зануляет memoryKey только когда счётчик
     * дошёл до нуля. Защищает от гонки: Worker A не занулит ключ,
     * пока Worker B ещё работает.
     */
    public static void releaseEphemeralKey() {
        synchronized (keyLock) {
            int refs = ephemeralRefs.decrementAndGet();
            if (refs <= 0) {
                ephemeralRefs.set(0);
                if (memoryKeyIsEphemeral) {
                    if (memoryKey != null) Arrays.fill(memoryKey, (byte) 0);
                    memoryKey = null;
                    memoryKeyIsEphemeral = false;
                }
            }
        }
    }

    public static void lock() {
        synchronized (keyLock) {
            if (memoryKey != null) Arrays.fill(memoryKey, (byte) 0);
            memoryKey = null;
            memoryKeyIsEphemeral = false;
            ephemeralRefs.set(0);
        }
    }

    // ============ Emergency reset ============

    public static void clearAll(Context c) {
        prefs(c).edit()
            .remove(KEY_DK_PASSWORD)
            .remove(KEY_DK_BIOMETRIC)
            .putBoolean(KEY_HAS_PASSWORD, false)
            .putBoolean(KEY_HAS_BIOMETRIC, false)
            .putBoolean(KEY_BIOMETRIC_HEALTHY, true)
            .commit();
        try {
            KeyStoreHelper.deleteBiometricKey();
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    // ============ Helpers ============

    private static boolean verifyWrapped(Context c, String key, String secret) {
        try {
            String s = prefs(c).getString(key, null);
            if (s == null) return false;
            byte[] data = Base64.decode(s, Base64.NO_WRAP);
            if (data.length < SALT_LEN + 1) return false;
            byte[] salt = new byte[SALT_LEN];
            System.arraycopy(data, 0, salt, 0, SALT_LEN);
            byte[] enc = new byte[data.length - SALT_LEN];
            System.arraycopy(data, SALT_LEN, enc, 0, enc.length);
            byte[] derivedKey = deriveKey(secret, salt);
            aesDecrypt(derivedKey, enc);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean unlockWithWrapped(Context c, String key, String secret) {
        try {
            String s = prefs(c).getString(key, null);
            if (s == null) return false;
            byte[] data = Base64.decode(s, Base64.NO_WRAP);
            if (data.length < SALT_LEN + 1) return false;
            byte[] salt = new byte[SALT_LEN];
            System.arraycopy(data, 0, salt, 0, SALT_LEN);
            byte[] enc = new byte[data.length - SALT_LEN];
            System.arraycopy(data, SALT_LEN, enc, 0, enc.length);
            byte[] derivedKey = deriveKey(secret, salt);
            byte[] dk = aesDecrypt(derivedKey, enc);
            synchronized (keyLock) {
                memoryKey = dk;
                memoryKeyIsEphemeral = false;
                ephemeralRefs.set(0);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static final byte[] MAGIC = {'S', 'N', 'B', 'F', '1'};
    private static final byte VERSION = 1;

    public static byte[] packWithHeader(byte[] dk, byte[] plain) throws Exception {
        byte[] enc = aesEncrypt(dk, plain);
        byte[] out = new byte[MAGIC.length + 1 + enc.length];
        System.arraycopy(MAGIC, 0, out, 0, MAGIC.length);
        out[MAGIC.length] = VERSION;
        System.arraycopy(enc, 0, out, MAGIC.length + 1, enc.length);
        return out;
    }

    public static byte[] unpackWithHeader(byte[] dk, byte[] data) throws Exception {
        if (data.length < MAGIC.length + 1) throw new Exception("File too short");
        for (int i = 0; i < MAGIC.length; i++) {
            if (data[i] != MAGIC[i]) throw new Exception("Bad magic");
        }
        byte ver = data[MAGIC.length];
        if (ver != VERSION) throw new Exception("Unknown version: " + ver);
        byte[] enc = new byte[data.length - MAGIC.length - 1];
        System.arraycopy(data, MAGIC.length + 1, enc, 0, enc.length);
        return aesDecrypt(dk, enc);
    }

    public static boolean hasMagicHeader(byte[] data) {
        if (data == null || data.length < MAGIC.length) return false;
        for (int i = 0; i < MAGIC.length; i++) {
            if (data[i] != MAGIC[i]) return false;
        }
        return true;
    }

    public static byte[] aesEncryptStatic(byte[] keyBytes, byte[] plaintext) throws Exception {
        return aesEncrypt(keyBytes, plaintext);
    }

    public static byte[] aesDecryptStatic(byte[] keyBytes, byte[] data) throws Exception {
        return aesDecrypt(keyBytes, data);
    }

    private static byte[] aesEncrypt(byte[] keyBytes, byte[] plaintext) throws Exception {
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    private static byte[] aesDecrypt(byte[] keyBytes, byte[] data) throws Exception {
        if (data.length < 2) throw new Exception("Too short");
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        int ivLen = data[0] & 0xFF;
        if (ivLen < 1 || ivLen > data.length - 2) throw new Exception("Bad IV len");
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    private static byte[] deriveKey(String password, byte[] salt) throws Exception {
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, 256);
        return f.generateSecret(spec).getEncoded();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static byte[] readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }

    private static void writeAll(File f, byte[] data) throws Exception {
        try (FileOutputStream out = new FileOutputStream(f)) { out.write(data); }
    }
}