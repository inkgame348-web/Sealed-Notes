package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsStorage {
    private static final String PREFS = "sealednotes_settings";

    private static final String KEY_THEME = "theme";
    private static final String KEY_TRASH_CLEANUP_ENABLED = "trash_cleanup_enabled";
    private static final String KEY_TRASH_RETENTION_DAYS = "trash_retention_days";

    // Тема
    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    // Корзина — дефолты
    public static final boolean TRASH_CLEANUP_DEFAULT_ENABLED = true;
    public static final int TRASH_RETENTION_DEFAULT_DAYS = 30;

    // ============ Тема ============

    public static int getTheme(Context ctx) {
        return prefs(ctx).getInt(KEY_THEME, THEME_SYSTEM);
    }

    public static void setTheme(Context ctx, int theme) {
        prefs(ctx).edit().putInt(KEY_THEME, theme).apply();
    }

    // ============ Автоочистка корзины ============

    public static boolean isTrashCleanupEnabled(Context ctx) {
        return prefs(ctx).getBoolean(KEY_TRASH_CLEANUP_ENABLED, TRASH_CLEANUP_DEFAULT_ENABLED);
    }

    public static void setTrashCleanupEnabled(Context ctx, boolean enabled) {
        prefs(ctx).edit().putBoolean(KEY_TRASH_CLEANUP_ENABLED, enabled).apply();
    }

    public static int getTrashRetentionDays(Context ctx) {
        return prefs(ctx).getInt(KEY_TRASH_RETENTION_DAYS, TRASH_RETENTION_DEFAULT_DAYS);
    }

    public static void setTrashRetentionDays(Context ctx, int days) {
        prefs(ctx).edit().putInt(KEY_TRASH_RETENTION_DAYS, days).apply();
    }

    /**
     * ★ ФИКС 2: готовая метка срока хранения корзины.
     * Используется везде, где раньше был хардкод "30 дней":
     * - в настройках (updateTrashCleanupLabel)
     * - в диалоге удаления заметки (MainActivity.confirmDelete)
     * - в любом другом месте, где надо показать срок
     */
    public static String getTrashRetentionLabel(Context ctx) {
        if (!isTrashCleanupEnabled(ctx)) {
            return ctx.getString(R.string.trash_cleanup_off);
        }
        int days = getTrashRetentionDays(ctx);
        if (days == 1) return ctx.getString(R.string.trash_cleanup_1day);
        if (days == 365) return ctx.getString(R.string.trash_cleanup_1year);
        if (days % 30 == 0 && days >= 60) {
            return ctx.getString(R.string.trash_cleanup_months, days / 30);
        }
        return ctx.getString(R.string.trash_cleanup_days, days);
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}