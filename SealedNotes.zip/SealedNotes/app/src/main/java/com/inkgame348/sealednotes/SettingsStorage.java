package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsStorage {
    private static final String PREFS = "sealednotes_settings";

    private static final String KEY_THEME = "theme";

    // Тема
    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    // ============ Тема ============

    public static int getTheme(Context ctx) {
        return prefs(ctx).getInt(KEY_THEME, THEME_SYSTEM);
    }

    public static void setTheme(Context ctx, int theme) {
        prefs(ctx).edit().putInt(KEY_THEME, theme).apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}