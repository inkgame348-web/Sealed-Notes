package com.inkgame348.sealednotes;

import org.json.JSONObject;

/**
 * Одна запись в журнале отмены. Описывает действие и что нужно,
 * чтобы его откатить.
 */
public class UndoEntry {

    public static final String TYPE_DELETE_NOTE = "DELETE_NOTE";
    public static final String TYPE_RESTORE_NOTE = "RESTORE_NOTE";
    public static final String TYPE_TOGGLE_PIN = "TOGGLE_PIN";
    public static final String TYPE_HARD_DELETE = "HARD_DELETE";

    public String type;
    public long timestamp;
    public String noteId;
    public String noteTitle;

    // Состояние до изменения
    public boolean previousPinned;
    public long previousDeletedAt;

    public JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("type", type);
        o.put("timestamp", timestamp);
        o.put("noteId", noteId);
        o.put("noteTitle", noteTitle);
        o.put("previousPinned", previousPinned);
        o.put("previousDeletedAt", previousDeletedAt);
        return o;
    }

    public static UndoEntry fromJson(JSONObject o) {
        UndoEntry e = new UndoEntry();
        e.type = o.optString("type", "");
        e.timestamp = o.optLong("timestamp", 0);
        e.noteId = o.optString("noteId", "");
        e.noteTitle = o.optString("noteTitle", "");
        e.previousPinned = o.optBoolean("previousPinned", false);
        e.previousDeletedAt = o.optLong("previousDeletedAt", 0);
        return e;
    }
}