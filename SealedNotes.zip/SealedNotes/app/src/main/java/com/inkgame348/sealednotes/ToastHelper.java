package com.inkgame348.sealednotes;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class ToastHelper {

    private static final long DURATION_MS = 900;

    public static void show(Context ctx, String message) {
        if (ctx == null || message == null) return;
        final Toast toast = Toast.makeText(ctx.getApplicationContext(),
            message, Toast.LENGTH_SHORT);
        toast.show();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                try { toast.cancel(); } catch (Exception ignored) {}
            }
        }, DURATION_MS);
    }
}