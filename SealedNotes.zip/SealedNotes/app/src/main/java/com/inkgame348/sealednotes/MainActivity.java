package com.inkgame348.sealednotes;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final long BACKUP_STALE_MS = 7L * 24 * 60 * 60 * 1000;

    private RecyclerView recycler;
    private TextView emptyText;
    private NoteAdapter adapter;
    private final List<Note> notes = new ArrayList<>();
    private NoteStorage storage;
    private FloatingActionButton fab;
    private ImageButton undoBtn;
    private LinearLayout backupBanner;
    private TextView backupBannerText;
    private volatile boolean undoInFlight = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }

        applySavedTheme();
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_main);
        storage = new NoteStorage(this);

        AppExecutors.get().diskIO().execute(() ->
            NoteStorage.cleanupOrphanTmp(getApplicationContext()));

        recycler = findViewById(R.id.recycler);
        emptyText = findViewById(R.id.empty_text);
        fab = findViewById(R.id.fab);
        undoBtn = findViewById(R.id.btn_undo);
        backupBanner = findViewById(R.id.backup_banner);
        backupBannerText = findViewById(R.id.backup_banner_text);
        ImageButton settingsBtn = findViewById(R.id.btn_settings);
        FrameLayout trashBtn = findViewById(R.id.btn_trash);
        ImageView trashLid = findViewById(R.id.trash_lid);

        backupBanner.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
        });

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(notes, new NoteAdapter.Listener() {
            @Override public void onClick(Note note) { openEditor(note); }
            @Override public void onLongClick(Note note) { showNoteDialog(note); }
        });
        recycler.setAdapter(adapter);

        ItemTouchHelper.SimpleCallback swipe =
            new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override public boolean onMove(@NonNull RecyclerView rv,
                                            @NonNull RecyclerView.ViewHolder vh,
                                            @NonNull RecyclerView.ViewHolder t) { return false; }
            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int dir) {
                int pos = vh.getAdapterPosition();
                if (pos >= 0 && pos < notes.size()) {
                    Note note = notes.get(pos);
                    adapter.notifyItemChanged(pos);
                    recycler.postDelayed(() -> showNoteDialog(note), 50);
                }
            }
        };
        new ItemTouchHelper(swipe).attachToRecyclerView(recycler);

        fab.setScaleX(0f);
        fab.setScaleY(0f);
        fab.animate().scaleX(1f).scaleY(1f)
            .setDuration(400)
            .setInterpolator(new OvershootInterpolator())
            .start();

        fab.setOnClickListener(v -> {
            animateFabClick(v);
            v.postDelayed(() -> openEditor(null), 80);
        });

        undoBtn.setOnClickListener(v -> {
            animateFabClick(v);
            v.postDelayed(this::performUndo, 80);
        });

        trashBtn.setOnClickListener(v -> {
            trashLid.setPivotX(4f);
            trashLid.setPivotY(6f);
            trashLid.animate()
                .rotation(-32f)
                .translationY(-3f)
                .setDuration(220)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> trashLid.animate()
                    .rotation(0f)
                    .translationY(0f)
                    .setDuration(340)
                    .setInterpolator(new OvershootInterpolator())
                    .withEndAction(() -> {
                        trashLid.setRotation(0f);
                        trashLid.setTranslationY(0f);
                        startActivity(new Intent(MainActivity.this, TrashActivity.class));
                        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
                    })
                    .start())
                .start();
        });

        settingsBtn.setOnClickListener(v -> {
            v.animate()
                .rotationBy(360f)
                .setDuration(400)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    v.setRotation(0f);
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
                })
                .start();
        });

        updateEmptyState();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (MasterKeyManager.isUnlocked()) MasterKeyManager.markActive(this);
    }

    private void animateFabClick(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                .setDuration(180)
                .setInterpolator(new OvershootInterpolator())
                .start())
            .start();
    }

    private void applySavedTheme() {
        int theme = SettingsStorage.getTheme(this);
        if (theme == SettingsStorage.THEME_LIGHT)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        else if (theme == SettingsStorage.THEME_DARK)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        else
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
    }

    // ==================== Backup banner ====================

    private void updateBackupBanner() {
        if (backupBanner == null) return;

        if (!BackupConfig.isEnabled(this)) {
            backupBanner.setVisibility(View.GONE);
            return;
        }
        long last = BackupConfig.getLastTime(this);
        long now = System.currentTimeMillis();
        String status = BackupConfig.getLastStatus(this);

        boolean neverRan = (last == 0);
        boolean stale = !neverRan && (now - last > BACKUP_STALE_MS);

        boolean failed = (status != null
            && !status.isEmpty()
            && !status.equals("ok"));

        if (stale) {
            backupBannerText.setText(R.string.backup_banner_stale);
            backupBanner.setVisibility(View.VISIBLE);
        } else if (failed) {
            backupBannerText.setText(R.string.backup_banner_failed);
            backupBanner.setVisibility(View.VISIBLE);
        } else {
            backupBanner.setVisibility(View.GONE);
        }
    }

    // ==================== Undo ====================

    private void updateUndoButton() {
        if (undoBtn == null) return;
        AppExecutors.get().crypto().execute(() -> {
            final boolean can = new UndoJournal(MainActivity.this).canUndo();
            AppExecutors.get().runOnMain(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (undoBtn == null) return;
                undoBtn.setVisibility(can ? View.VISIBLE : View.GONE);
            });
        });
    }

    private void performUndo() {
        if (undoInFlight) return;
        undoInFlight = true;
        if (undoBtn != null) undoBtn.setEnabled(false);

        AppExecutors.get().crypto().execute(() -> {
            final UndoJournal journal = new UndoJournal(MainActivity.this);
            final UndoEntry entry = journal.pop();
            if (entry == null) {
                AppExecutors.get().runOnMain(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    undoInFlight = false;
                    if (undoBtn != null) undoBtn.setEnabled(true);
                    ToastHelper.show(MainActivity.this, getString(R.string.undo_nothing));
                    updateUndoButton();
                });
                return;
            }

            boolean ok;
            switch (entry.type) {
                case UndoEntry.TYPE_DELETE_NOTE:
                    ok = applyUndoDelete(entry); break;
                case UndoEntry.TYPE_RESTORE_NOTE:
                    ok = applyUndoRestore(entry); break;
                case UndoEntry.TYPE_TOGGLE_PIN:
                    ok = applyUndoTogglePin(entry); break;
                case UndoEntry.TYPE_HARD_DELETE:
                    ok = applyUndoHardDelete(entry); break;
                default:
                    ok = false;
            }

            if (!ok) {
                if (BuildConfig.DEBUG) Log.w(TAG, "undo failed for type=" + entry.type + " id=" + entry.noteId);
                journal.push(entry);
                AppExecutors.get().runOnMain(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    undoInFlight = false;
                    if (undoBtn != null) undoBtn.setEnabled(true);
                    ToastHelper.show(MainActivity.this, getString(R.string.undo_failed));
                    updateUndoButton();
                });
                return;
            }

            AppExecutors.get().runOnMain(() -> {
                if (isFinishing() || isDestroyed()) return;
                undoInFlight = false;
                if (undoBtn != null) undoBtn.setEnabled(true);
                ToastHelper.show(MainActivity.this, describeEntry(entry));
                loadNotes();
                updateUndoButton();
            });
        });
    }

    private String describeEntry(UndoEntry entry) {
        if (entry == null) return "";
        switch (entry.type) {
            case UndoEntry.TYPE_DELETE_NOTE:
            case UndoEntry.TYPE_HARD_DELETE:
                return getString(R.string.undo_deleted_note);
            case UndoEntry.TYPE_RESTORE_NOTE:
                return getString(R.string.undo_restored_to_trash);
            case UndoEntry.TYPE_TOGGLE_PIN:
                return getString(R.string.undo_toggled_pin);
            default:
                return getString(R.string.undo);
        }
    }

    private boolean applyUndoDelete(UndoEntry entry) {
        try {
            Note full = storage.loadFull(entry.noteId);
            if (full == null) return false;
            full.deleted = false;
            full.deletedAt = 0;
            full.pinned = entry.previousPinned;
            full.contentLoaded = true;
            storage.saveOne(full);
            return true;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return false;
        }
    }

    private boolean applyUndoRestore(UndoEntry entry) {
        try {
            Note full = storage.loadFull(entry.noteId);
            if (full == null) return false;
            full.deleted = true;
            full.deletedAt = entry.previousDeletedAt > 0
                ? entry.previousDeletedAt
                : System.currentTimeMillis();
            full.contentLoaded = true;
            storage.saveOne(full);
            return true;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return false;
        }
    }

    private boolean applyUndoTogglePin(UndoEntry entry) {
        try {
            Note full = storage.loadFull(entry.noteId);
            if (full == null) return false;
            full.pinned = entry.previousPinned;
            full.contentLoaded = true;
            storage.saveOne(full);
            return true;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return false;
        }
    }

    /**
     * ★ ФИКС: три уровня проверки.
     *
     * 1. restoreFromJournal возвращает файл из journal/ в notes/.
     *    Внутри улучшено: проверяет, что файл реально переехал,
     *    даже если renameTo вернул false.
     *
     * 2. loadFull читает восстановленный файл. Если null — откат.
     *
     * 3. Перед saveOne сбрасываем LOAD_FAILED, потому что файл
     *    заведомо валиден (мы только что его восстановили и прочитали).
     *    Без этого saveOne молча выходил, если флаг остался от
     *    предыдущей ошибки, и заметка не восстанавливалась.
     */
    private boolean applyUndoHardDelete(UndoEntry entry) {
        try {
            if (entry.noteId == null) return false;

            // Шаг 1: вернуть файл из journal/ в notes/
            if (!NoteStorage.restoreFromJournal(this, entry.noteId)) {
                if (BuildConfig.DEBUG) Log.w(TAG, "restoreFromJournal failed for " + entry.noteId);
                return false;
            }

            // Шаг 2: прочитать восстановленный файл
            Note full = storage.loadFull(entry.noteId);
            if (full == null) {
                if (BuildConfig.DEBUG) Log.w(TAG, "loadFull returned null for " + entry.noteId);
                NoteStorage.moveToJournal(this, entry.noteId);
                return false;
            }

            // Шаг 3: сбросить флаги удаления
            full.deleted = false;
            full.deletedAt = 0;
            full.contentLoaded = true;

            // Шаг 4: файл валиден — сбрасываем LOAD_FAILED перед saveOne
            NoteStorage.LOAD_FAILED = false;

            // Шаг 5: сохранить (пишет notes/<id>.enc + обновляет индекс)
            storage.saveOne(full);
            return true;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return false;
        }
    }

    // ==================== Note actions ====================

    private void showNoteDialog(Note note) {
        if (note == null || isFinishing() || isDestroyed()) return;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_note_actions);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.85f),
                LinearLayout.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogTheme;
        }

        TextView title = dialog.findViewById(R.id.dialog_title);
        title.setText(note.title.isEmpty() ? getString(R.string.untitled) : note.title);

        TextView pinLabel = dialog.findViewById(R.id.btn_pin_label);
        pinLabel.setText(note.pinned ? R.string.dialog_unpin : R.string.dialog_pin);

        LinearLayout pinBtn = dialog.findViewById(R.id.btn_pin);
        swapPinIcon(pinBtn, note.pinned);

        pinBtn.setOnClickListener(v -> {
            dialog.dismiss();
            togglePin(note);
        });
        dialog.findViewById(R.id.btn_delete).setOnClickListener(v -> {
            dialog.dismiss();
            confirmDelete(note);
        });

        dialog.show();
    }

    private void swapPinIcon(LinearLayout container, boolean pinned) {
        if (container == null) return;
        int resId = pinned ? R.drawable.ic_pin_off : R.drawable.ic_pin;
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof ImageView) {
                ((ImageView) child).setImageResource(resId);
                ((ImageView) child).setAlpha(pinned ? 0.85f : 1.0f);
            }
        }
    }

    private void confirmDelete(Note note) {
        if (note == null || note.id == null) return;
        final String noteId = note.id;

        new AnimDialog(this)
            .setTitle(R.string.delete_one_title)
            .setMessage(R.string.delete_one_msg)
            .setPositiveButton(R.string.delete, (d, w) -> {
                AppExecutors.get().crypto().execute(() -> {
                    Note full = storage.loadFull(noteId);
                    if (full == null) return;

                    UndoEntry entry = new UndoEntry();
                    entry.type = UndoEntry.TYPE_DELETE_NOTE;
                    entry.timestamp = System.currentTimeMillis();
                    entry.noteId = full.id;
                    entry.noteTitle = full.title;
                    entry.previousPinned = full.pinned;
                    new UndoJournal(MainActivity.this).push(entry);

                    full.deleted = true;
                    full.deletedAt = System.currentTimeMillis();
                    full.pinned = false;
                    full.contentLoaded = true;
                    storage.saveOne(full);

                    AppExecutors.get().runOnMain(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        loadNotes();
                        updateUndoButton();
                        ToastHelper.show(MainActivity.this,
                            getString(R.string.toast_moved_to_trash));
                    });
                });
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void togglePin(Note note) {
        if (note == null || note.id == null) return;
        final String noteId = note.id;
        final boolean wasPinned = note.pinned;

        AppExecutors.get().crypto().execute(() -> {
            Note full = storage.loadFull(noteId);
            if (full == null) return;

            UndoEntry entry = new UndoEntry();
            entry.type = UndoEntry.TYPE_TOGGLE_PIN;
            entry.timestamp = System.currentTimeMillis();
            entry.noteId = full.id;
            entry.noteTitle = full.title;
            entry.previousPinned = wasPinned;
            new UndoJournal(MainActivity.this).push(entry);

            full.pinned = !wasPinned;
            full.contentLoaded = true;
            storage.saveOne(full);

            final boolean nowPinned = full.pinned;
            AppExecutors.get().runOnMain(() -> {
                if (isFinishing() || isDestroyed()) return;
                loadNotes();
                updateUndoButton();
                ToastHelper.show(this, nowPinned
                    ? getString(R.string.toast_pinned)
                    : getString(R.string.toast_unpinned));
            });
        });
    }

    private void loadNotes() {
        storage.loadAsync(loaded -> {
            if (isFinishing() || isDestroyed()) return;

            notes.clear();
            if (loaded == null) {
                emptyText.setText(R.string.error_decrypt_failed);
                emptyText.setVisibility(View.VISIBLE);
                fab.setEnabled(false);
                adapter.notifyDataSetChanged();
                return;
            }
            emptyText.setText(R.string.no_notes);
            fab.setEnabled(true);
            for (Note n : loaded) {
                if (n != null && !n.deleted) notes.add(n);
            }
            adapter.notifyDataSetChanged();
            updateEmptyState();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        loadNotes();
        updateUndoButton();
        updateBackupBanner();
    }

    private void openEditor(Note note) {
        Intent i = new Intent(this, EditNoteActivity.class);
        if (note != null) i.putExtra("note_id", note.id);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
    }

    private void updateEmptyState() {
        emptyText.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}