package com.inkgame348.sealednotes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Note implements Serializable {

    private static final long serialVersionUID = 1L;

    /** Максимальная длина заголовка. */
    public static final int MAX_TITLE_LENGTH = 100;
    /** Максимальная длина текста заметки. */
    public static final int MAX_CONTENT_LENGTH = 10_000;

    public String id;
    public String title;
    public String content;
    public long timestamp;
    public boolean pinned = false;
    public boolean deleted = false;
    public long deletedAt = 0;
    public List<String> attachments = new ArrayList<>();

    /** true, если content загружен с диска. В индексе — false. */
    public boolean contentLoaded = false;

    /** Обрезает строку до max символов. null → "". */
    public static String truncate(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, max);
    }
}