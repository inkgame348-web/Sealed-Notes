package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Конфигурация автобэкапа.
 * Пароль бэкапа шифруется через DK и хранится в base64.
 * Worker при запуске расшифровывает его через fallback-DK.
 */
public class BackupConfig {

    private static final String PREFS = "sealednotes_backup";

    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_FOLDER_URI = "folder_uri";
    private static final String KEY_PASSWORD_ENC = "password_enc";
    private static final String KEY_LAST_TIME = "last_time";
    private static final String KEY_LAST_STATUS = "last_status";

    private static final int GCM_TAG_BITS = 128;

    // ============ Accessors ============

    public static boolean isEnabled(Context ctx) {
        return prefs(ctx).getBoolean(KEY_ENABLED, false);
    }

    public static String getFolderUri(Context ctx) {
        return prefs(ctx).getString(KEY_FOLDER_URI, null);
    }

    public static long getLastTime(Context ctx) {
        return prefs(ctx).getLong(KEY_LAST_TIME, 0);
    }

    public static String getLastStatus(Context ctx) {
        return prefs(ctx).getString(KEY_LAST_STATUS, "");
    }

    public static void setLastTime(Context ctx, long time) {
        prefs(ctx).edit().putLong(KEY_LAST_TIME, time).apply();
    }

    public static void setLastStatus(Context ctx, String status) {
        prefs(ctx).edit().putString(KEY_LAST_STATUS, status).apply();
    }

    // ============ Enable / disable ============

    public static void enable(Context ctx, String folderUri, String password)
            throws Exception {
        if (folderUri == null || folderUri.isEmpty()) {
            throw new IllegalArgumentException("folderUri is empty");
        }
        if (password == null || password.length() < 4) {
            throw new IllegalArgumentException("password too short");
        }

        byte[] dk = MasterKeyManager.getDataKey(ctx);
        byte[] enc = aesEncrypt(password.getBytes("UTF-8"), dk);
        String encB64 = Base64.encodeToString(enc, Base64.NO_WRAP);

        prefs(ctx).edit()
            .putBoolean(KEY_ENABLED, true)
            .putString(KEY_FOLDER_URI, folderUri)
            .putString(KEY_PASSWORD_ENC, encB64)
            .putString(KEY_LAST_STATUS, "")
            .apply();
    }

    public static void disable(Context ctx) {
        prefs(ctx).edit()
            .putBoolean(KEY_ENABLED, false)
            .remove(KEY_PASSWORD_ENC)
            .remove(KEY_FOLDER_URI)
            .putString(KEY_LAST_STATUS, "")
            .apply();
    }

    public static void changePassword(Context ctx, String newPassword) throws Exception {
        if (getFolderUri(ctx) == null) {
            throw new IllegalStateException("autobackup not configured");
        }
        if (newPassword == null || newPassword.length() < 4) {
            throw new IllegalArgumentException("password too short");
        }
        byte[] dk = MasterKeyManager.getDataKey(ctx);
        byte[] enc = aesEncrypt(newPassword.getBytes("UTF-8"), dk);
        String encB64 = Base64.encodeToString(enc, Base64.NO_WRAP);
        prefs(ctx).edit().putString(KEY_PASSWORD_ENC, encB64).apply();
    }

    public static void changeFolder(Context ctx, String folderUri) {
        if (folderUri == null || folderUri.isEmpty()) return;
        prefs(ctx).edit().putString(KEY_FOLDER_URI, folderUri).apply();
    }

    // ============ For worker ============

    public static String getPasswordForWorker(Context ctx) throws Exception {
        String encB64 = prefs(ctx).getString(KEY_PASSWORD_ENC, null);
        if (encB64 == null) throw new Exception("password not set");

        byte[] dk = MasterKeyManager.getDataKeyUnprotected(ctx);
        byte[] enc = Base64.decode(encB64, Base64.NO_WRAP);
        byte[] plain = aesDecrypt(enc, dk);
        return new String(plain, "UTF-8");
    }

    // ============ AES ============

    private static byte[] aesEncrypt(byte[] plaintext, byte[] keyBytes) throws Exception {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    private static byte[] aesDecrypt(byte[] data, byte[] keyBytes) throws Exception {
        if (data.length < 2) throw new Exception("Too short");
        SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");
        int ivLen = data[0] & 0xFF;
        if (ivLen < 1 || ivLen > data.length - 2) throw new Exception("Bad IV");
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}