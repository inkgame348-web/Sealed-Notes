-keep class com.inkgame348.sealednotes.Note { *; }
-keep class com.inkgame348.sealednotes.NoteStorage { *; }
-keep class com.inkgame348.sealednotes.KeyStoreHelper { *; }
-keep class com.inkgame348.sealednotes.MasterKeyManager { *; }
-keep class com.inkgame348.sealednotes.NoteAdapter { *; }
-keep class com.inkgame348.sealednotes.NoteAdapter$* { *; }
-keep class com.inkgame348.sealednotes.AttachmentHelper { *; }
-keep class com.inkgame348.sealednotes.SettingsStorage { *; }
-keep class com.inkgame348.sealednotes.MainActivity { *; }
-keep class com.inkgame348.sealednotes.EditNoteActivity { *; }
-keep class com.inkgame348.sealednotes.SettingsActivity { *; }
-keep class com.inkgame348.sealednotes.TrashActivity { *; }
-keep class com.inkgame348.sealednotes.UnlockActivity { *; }
-keep class com.inkgame348.sealednotes.BackupHelper { *; }

-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

-keep class androidx.appcompat.app.AppCompatDelegate { *; }
-keep class androidx.core.os.LocaleListCompat { *; }
-dontwarn androidx.appcompat.**

-keep class androidx.biometric.** { *; }
-dontwarn androidx.biometric.**