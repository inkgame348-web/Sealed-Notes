package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;

public class SettingsStorage {
    private static final String PREFS = "sealednotes_settings";
    private static final String KEY_THEME = "theme";
    private static final String KEY_SORT = "sort_mode";
    private static final String KEY_SEARCH_CONTENT = "search_in_content";

    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    public static int getTheme(Context ctx) {
        return prefs(ctx).getInt(KEY_THEME, THEME_SYSTEM);
    }

    public static void setTheme(Context ctx, int theme) {
        prefs(ctx).edit().putInt(KEY_THEME, theme).apply();
    }

    // ★ ФИКС: сортировка ★
    public static int getSortMode(Context ctx) {
        return prefs(ctx).getInt(KEY_SORT, 0);
    }

    public static void setSortMode(Context ctx, int mode) {
        prefs(ctx).edit().putInt(KEY_SORT, mode).apply();
    }

    // ★ ФИКС: поиск в тексте ★
    public static boolean isSearchInContent(Context ctx) {
        return prefs(ctx).getBoolean(KEY_SEARCH_CONTENT, true);
    }

    public static void setSearchInContent(Context ctx, boolean v) {
        prefs(ctx).edit().putBoolean(KEY_SEARCH_CONTENT, v).apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}