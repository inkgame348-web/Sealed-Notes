package com.inkgame348.sealednotes;

import android.content.Context;
import androidx.appcompat.app.AlertDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

/**
 * MaterialAlertDialogBuilder с гарантированной анимацией появления/исчезновения.
 */
public class AnimDialog extends MaterialAlertDialogBuilder {

    public AnimDialog(Context ctx) {
        super(ctx, R.style.Theme_SealedNotes_Dialog);
    }

    @Override
    public AlertDialog show() {
        AlertDialog dialog = create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setWindowAnimations(R.style.CustomDialogTheme);
        }
        dialog.show();
        return dialog;
    }
}