package com.inkgame348.sealednotes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.VH> {

    public interface Listener {
        void onClick(Note note);
        void onLongClick(Note note);
    }

    private final List<Note> notes;
    private final Listener listener;
    private final Set<String> animatedIds = new HashSet<>();

    public NoteAdapter(List<Note> notes, Listener listener) {
        this.notes = notes;
        this.listener = listener;
    }

    public void resetAnimationCache() { animatedIds.clear(); }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Context ctx = h.itemView.getContext();
        Note n = notes.get(position);

        h.title.setText(n.title.isEmpty() ? ctx.getString(R.string.untitled) : n.title);

        String preview = n.content.replace("\n", " ").trim();
        if (preview.length() > 80) preview = preview.substring(0, 80) + "…";

        if (preview.isEmpty() && !n.attachments.isEmpty()) {
            preview = ctx.getString(R.string.attachments_count, n.attachments.size());
        } else if (!n.attachments.isEmpty()) {
            preview = preview + "  ·  " + ctx.getString(R.string.attachments_count, n.attachments.size());
        }

        h.preview.setText(preview);
        h.date.setText(formatTime(ctx, n.timestamp));
        h.pinIcon.setVisibility(n.pinned ? View.VISIBLE : View.GONE);

        h.itemView.setOnClickListener(v -> listener.onClick(n));
        h.itemView.setOnLongClickListener(v -> {
            listener.onLongClick(n);
            return true;
        });

        if (!animatedIds.contains(n.id)) {
            animatedIds.add(n.id);
            View item = h.itemView;
            item.setAlpha(0f);
            item.setTranslationY(40f);
            item.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(340)
                .setStartDelay(Math.min(position, 6) * 40L)
                .setInterpolator(new DecelerateInterpolator())
                .start();
        } else {
            h.itemView.setAlpha(1f);
            h.itemView.setTranslationY(0f);
        }
    }

    @Override public int getItemCount() { return notes.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, preview, date;
        ImageView pinIcon;
        CheckBox check;
        VH(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.note_title);
            preview = v.findViewById(R.id.note_preview);
            date = v.findViewById(R.id.note_date);
            pinIcon = v.findViewById(R.id.note_pin);
            check = v.findViewById(R.id.note_check);
        }
    }

    private static String formatTime(Context ctx, long ts) {
        long diff = System.currentTimeMillis() - ts;
        if (diff < 60_000) return ctx.getString(R.string.just_now);
        if (diff < 3_600_000) return ctx.getString(R.string.min_ago, diff / 60_000);
        if (diff < 86_400_000) return ctx.getString(R.string.hour_ago, diff / 3_600_000);
        if (diff < 604_800_000) return ctx.getString(R.string.day_ago, diff / 86_400_000);
        return new SimpleDateFormat("dd.MM.yy", Locale.getDefault()).format(new Date(ts));
    }
}