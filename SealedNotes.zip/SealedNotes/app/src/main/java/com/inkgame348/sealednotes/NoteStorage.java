package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class NoteStorage {

    public static boolean LOAD_FAILED = false;

    private static final String PREFS = "sealednotes_internal";
    private static final String KEY_LAST_CLEANUP = "last_trash_cleanup";
    private static final String KEY_SCHEMA_VERSION = "schema_version";
    private static final int SCHEMA_VERSION = 2;

    /** ★ Раз в 30 дней вместо 24 часов ★ */
    private static final long CLEANUP_INTERVAL_MS = 30L * 24 * 60 * 60 * 1000;

    /** Порог автоудаления из корзины — 30 дней. */
    private static final long TRASH_RETENTION_MS = 30L * 24 * 60 * 60 * 1000;

    private final Context context;
    private final File notesDir;
    private final File indexPath;
    private final File oldSingleFile;

    public NoteStorage(Context context) {
        this.context = context.getApplicationContext();
        this.notesDir = new File(context.getFilesDir(), "notes");
        this.indexPath = new File(context.getFilesDir(), "index.enc");
        this.oldSingleFile = new File(context.getFilesDir(), "notes.enc");
        if (!notesDir.exists()) notesDir.mkdirs();
    }

    // ============ Migration ============

    public void migrateIfNeeded() {
        try {
            int schema = prefs().getInt(KEY_SCHEMA_VERSION, 1);
            if (schema >= SCHEMA_VERSION) return;

            if (oldSingleFile.exists() && oldSingleFile.length() > 0) {
                byte[] data = readAll(oldSingleFile);
                byte[] dk = MasterKeyManager.getDataKey(context);
                byte[] plain;
                if (MasterKeyManager.hasMagicHeader(data)) {
                    plain = MasterKeyManager.unpackWithHeader(dk, data);
                } else {
                    plain = MasterKeyManager.aesDecryptStatic(dk, data);
                }
                JSONArray arr = new JSONArray(new String(plain, StandardCharsets.UTF_8));
                List<Note> notes = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    Note n = new Note();
                    n.id = o.optString("id", "");
                    n.title = o.optString("title", "");
                    n.content = o.optString("content", "");
                    n.timestamp = o.optLong("timestamp", 0);
                    n.pinned = o.optBoolean("pinned", false);
                    n.deleted = o.optBoolean("deleted", false);
                    n.deletedAt = o.optLong("deletedAt", 0);
                    JSONArray atts = o.optJSONArray("attachments");
                    if (atts != null) for (int j = 0; j < atts.length(); j++)
                        n.attachments.add(atts.getString(j));
                    n.contentLoaded = true;
                    notes.add(n);
                }
                for (Note n : notes) writeNoteFile(n);
                writeIndex(notes);
                oldSingleFile.delete();
            } else if (!indexPath.exists()) {
                writeIndex(new ArrayList<>());
            }

            prefs().edit().putInt(KEY_SCHEMA_VERSION, SCHEMA_VERSION).commit();
        } catch (Exception e) {
            e.printStackTrace();
            LOAD_FAILED = true;
        }
    }

    // ============ Load ============

    public List<Note> load() {
        List<Note> notes = new ArrayList<>();
        try {
            migrateIfNeeded();
            if (LOAD_FAILED) return null;

            if (!indexPath.exists() || indexPath.length() == 0) {
                LOAD_FAILED = false;
                return notes;
            }

            byte[] data = readAll(indexPath);
            byte[] dk = MasterKeyManager.getDataKey(context);
            byte[] plain;
            if (MasterKeyManager.hasMagicHeader(data)) {
                plain = MasterKeyManager.unpackWithHeader(dk, data);
            } else {
                plain = MasterKeyManager.aesDecryptStatic(dk, data);
            }
            JSONArray arr = new JSONArray(new String(plain, StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Note n = new Note();
                n.id = o.optString("id", "");
                n.title = o.optString("title", "");
                n.content = o.optString("preview", "");
                n.timestamp = o.optLong("timestamp", 0);
                n.pinned = o.optBoolean("pinned", false);
                n.deleted = o.optBoolean("deleted", false);
                n.deletedAt = o.optLong("deletedAt", 0);
                n.contentLoaded = false;
                notes.add(n);
            }
            sortPinnedFirst(notes);
            LOAD_FAILED = false;
            return notes;
        } catch (Exception e) {
            e.printStackTrace();
            LOAD_FAILED = true;
            return null;
        }
    }

    public Note loadFull(String id) {
        try {
            File f = new File(notesDir, id + ".enc");
            if (!f.exists()) return null;
            byte[] data = readAll(f);
            byte[] dk = MasterKeyManager.getDataKey(context);
            byte[] plain;
            if (MasterKeyManager.hasMagicHeader(data)) {
                plain = MasterKeyManager.unpackWithHeader(dk, data);
            } else {
                plain = MasterKeyManager.aesDecryptStatic(dk, data);
            }
            JSONObject o = new JSONObject(new String(plain, StandardCharsets.UTF_8));
            Note n = new Note();
            n.id = o.optString("id", "");
            n.title = o.optString("title", "");
            n.content = o.optString("content", "");
            n.timestamp = o.optLong("timestamp", 0);
            n.pinned = o.optBoolean("pinned", false);
            n.deleted = o.optBoolean("deleted", false);
            n.deletedAt = o.optLong("deletedAt", 0);
            JSONArray atts = o.optJSONArray("attachments");
            if (atts != null) for (int j = 0; j < atts.length(); j++)
                n.attachments.add(atts.getString(j));
            n.contentLoaded = true;
            return n;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // ============ Save ============

    public void save(List<Note> notes) {
        if (LOAD_FAILED) return;
        try {
            sortPinnedFirst(notes);

            java.util.Set<String> aliveIds = new java.util.HashSet<>();
            for (Note n : notes) aliveIds.add(n.id);
            File[] existing = notesDir.listFiles();
            if (existing != null) {
                for (File f : existing) {
                    String name = f.getName();
                    if (!name.endsWith(".enc")) continue;
                    String id = name.substring(0, name.length() - 4);
                    if (!aliveIds.contains(id)) f.delete();
                }
            }

            for (Note n : notes) {
                if (n.contentLoaded) writeNoteFile(n);
            }
            writeIndex(notes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveOne(Note n) {
        if (LOAD_FAILED) return;
        try {
            writeNoteFile(n);
            List<Note> notes = load();
            if (notes == null) return;
            boolean found = false;
            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).id.equals(n.id)) {
                    notes.set(i, n);
                    found = true;
                    break;
                }
            }
            if (!found) notes.add(n);
            writeIndex(notes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void writeNoteFile(Note n) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", n.id);
        o.put("title", n.title);
        o.put("content", n.content);
        o.put("timestamp", n.timestamp);
        o.put("pinned", n.pinned);
        o.put("deleted", n.deleted);
        o.put("deletedAt", n.deletedAt);
        JSONArray atts = new JSONArray();
        for (String s : n.attachments) atts.put(s);
        o.put("attachments", atts);

        byte[] dk = MasterKeyManager.getDataKey(context);
        byte[] enc = MasterKeyManager.packWithHeader(dk,
            o.toString().getBytes(StandardCharsets.UTF_8));
        File f = new File(notesDir, n.id + ".enc");
        try (FileOutputStream out = new FileOutputStream(f)) { out.write(enc); }
    }

    private void writeIndex(List<Note> notes) throws Exception {
        JSONArray arr = new JSONArray();
        for (Note n : notes) {
            JSONObject o = new JSONObject();
            o.put("id", n.id);
            o.put("title", n.title);
            String preview = n.content.replace("\n", " ").trim();
            if (preview.length() > 120) preview = preview.substring(0, 120) + "…";
            o.put("preview", preview);
            o.put("timestamp", n.timestamp);
            o.put("pinned", n.pinned);
            o.put("deleted", n.deleted);
            o.put("deletedAt", n.deletedAt);
            arr.put(o);
        }
        byte[] dk = MasterKeyManager.getDataKey(context);
        byte[] enc = MasterKeyManager.packWithHeader(dk,
            arr.toString().getBytes(StandardCharsets.UTF_8));
        try (FileOutputStream out = new FileOutputStream(indexPath)) { out.write(enc); }
    }

    // ============ Sort ============

    public static void sortPinnedFirst(List<Note> notes) {
        notes.sort(new Comparator<Note>() {
            public int compare(Note a, Note b) {
                if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
                return Long.compare(b.timestamp, a.timestamp);
            }
        });
    }

    // ============ Cleanup ============

    public static void cleanupOldTrash(Context ctx) {
        try {
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            long last = prefs.getLong(KEY_LAST_CLEANUP, 0);
            long now = System.currentTimeMillis();
            if (now - last < CLEANUP_INTERVAL_MS) return;

            NoteStorage storage = new NoteStorage(ctx);
            List<Note> all = storage.load();
            if (all == null) return;

            long threshold = now - TRASH_RETENTION_MS;
            List<Note> toRemove = new ArrayList<>();
            for (Note n : all) {
                if (n.deleted && n.deletedAt > 0 && n.deletedAt < threshold) {
                    toRemove.add(n);
                }
            }
            if (!toRemove.isEmpty()) {
                for (Note n : toRemove) {
                    AttachmentHelper.deleteAllForNote(ctx, n.id);
                    File f = new File(new File(ctx.getFilesDir(), "notes"), n.id + ".enc");
                    if (f.exists()) f.delete();
                }
                all.removeAll(toRemove);
                storage.save(all);
            }
            prefs.edit().putLong(KEY_LAST_CLEANUP, now).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ============ Helpers ============

    private SharedPreferences prefs() {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static byte[] readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }
}