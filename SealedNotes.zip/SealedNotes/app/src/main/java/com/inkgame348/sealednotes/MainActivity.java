package com.inkgame348.sealednotes;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private TextView emptyText;
    private NoteAdapter adapter;
    private final List<Note> notes = new ArrayList<>();
    private NoteStorage storage;
    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }

        applySavedTheme();
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_main);
        storage = new NoteStorage(this);

        AppExecutors.get().diskIO().execute(() ->
            NoteStorage.cleanupOldTrash(getApplicationContext()));

        recycler = findViewById(R.id.recycler);
        emptyText = findViewById(R.id.empty_text);
        fab = findViewById(R.id.fab);
        ImageButton settingsBtn = findViewById(R.id.btn_settings);
        FrameLayout trashBtn = findViewById(R.id.btn_trash);
        ImageView trashLid = findViewById(R.id.trash_lid);

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(notes, new NoteAdapter.Listener() {
            @Override public void onClick(Note note) { openEditor(note); }
            @Override public void onLongClick(Note note) { showNoteDialog(note); }
        });
        recycler.setAdapter(adapter);

        ItemTouchHelper.SimpleCallback swipe =
            new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override public boolean onMove(@NonNull RecyclerView rv,
                                            @NonNull RecyclerView.ViewHolder vh,
                                            @NonNull RecyclerView.ViewHolder t) { return false; }
            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int dir) {
                int pos = vh.getAdapterPosition();
                if (pos >= 0 && pos < notes.size()) {
                    Note note = notes.get(pos);
                    adapter.notifyItemChanged(pos);
                    recycler.postDelayed(() -> showNoteDialog(note), 50);
                }
            }
        };
        new ItemTouchHelper(swipe).attachToRecyclerView(recycler);

        fab.setScaleX(0f);
        fab.setScaleY(0f);
        fab.animate().scaleX(1f).scaleY(1f)
            .setDuration(400)
            .setInterpolator(new OvershootInterpolator())
            .start();

        fab.setOnClickListener(v -> {
            animateFabClick(v);
            v.postDelayed(() -> openEditor(null), 80);
        });

        trashBtn.setOnClickListener(v -> {
            trashLid.setPivotX(4f);
            trashLid.setPivotY(6f);
            trashLid.animate()
                .rotation(-32f)
                .translationY(-3f)
                .setDuration(220)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> trashLid.animate()
                    .rotation(0f)
                    .translationY(0f)
                    .setDuration(340)
                    .setInterpolator(new OvershootInterpolator())
                    .withEndAction(() -> {
                        trashLid.setRotation(0f);
                        trashLid.setTranslationY(0f);
                        startActivity(new Intent(MainActivity.this, TrashActivity.class));
                        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
                    })
                    .start())
                .start();
        });

        settingsBtn.setOnClickListener(v -> {
            v.animate()
                .rotationBy(360f)
                .setDuration(400)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    v.setRotation(0f);
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
                })
                .start();
        });

        updateEmptyState();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (MasterKeyManager.isUnlocked()) MasterKeyManager.markActive(this);
    }

    private void animateFabClick(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                .setDuration(180)
                .setInterpolator(new OvershootInterpolator())
                .start())
            .start();
    }

    private void applySavedTheme() {
        int theme = SettingsStorage.getTheme(this);
        if (theme == SettingsStorage.THEME_LIGHT)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        else if (theme == SettingsStorage.THEME_DARK)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        else
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
    }

    private void showNoteDialog(Note note) {
        if (note == null || isFinishing() || isDestroyed()) return;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_note_actions);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.85f),
                LinearLayout.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogTheme;
        }

        TextView title = dialog.findViewById(R.id.dialog_title);
        title.setText(note.title.isEmpty() ? getString(R.string.untitled) : note.title);

        TextView pinLabel = dialog.findViewById(R.id.btn_pin_label);
        pinLabel.setText(note.pinned ? R.string.dialog_unpin : R.string.dialog_pin);

        LinearLayout pinBtn = dialog.findViewById(R.id.btn_pin);
        swapPinIcon(pinBtn, note.pinned);

        pinBtn.setOnClickListener(v -> {
            dialog.dismiss();
            togglePin(note);
        });
        dialog.findViewById(R.id.btn_delete).setOnClickListener(v -> {
            dialog.dismiss();
            confirmDelete(note);
        });

        dialog.show();
    }

    private void swapPinIcon(LinearLayout container, boolean pinned) {
        if (container == null) return;
        int resId = pinned ? R.drawable.ic_pin_off : R.drawable.ic_pin;
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof ImageView) {
                ((ImageView) child).setImageResource(resId);
                ((ImageView) child).setAlpha(pinned ? 0.85f : 1.0f);
            }
        }
    }

    private void confirmDelete(Note note) {
        if (note == null) return;
        new AnimDialog(this)
            .setTitle(R.string.delete_one_title)
            .setMessage(R.string.delete_one_msg)
            .setPositiveButton(R.string.delete, (d, w) -> {
                storage.loadFullAsync(note.id, full -> {
                    if (full == null) return;
                    if (isFinishing() || isDestroyed()) return;
                    full.deleted = true;
                    full.deletedAt = System.currentTimeMillis();
                    full.pinned = false;
                    full.contentLoaded = true;
                    storage.saveOneAsync(full, () -> {
                        if (isFinishing() || isDestroyed()) return;
                        loadNotes();
                        ToastHelper.show(MainActivity.this,
                            getString(R.string.toast_moved_to_trash));
                    });
                });
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void togglePin(Note note) {
        if (note == null) return;
        final boolean wasPinned = note.pinned;
        storage.loadFullAsync(note.id, full -> {
            if (full == null) return;
            if (isFinishing() || isDestroyed()) return;
            full.pinned = !wasPinned;
            full.contentLoaded = true;
            storage.saveOneAsync(full, () -> {
                if (isFinishing() || isDestroyed()) return;
                loadNotes();
                ToastHelper.show(this, full.pinned
                    ? getString(R.string.toast_pinned)
                    : getString(R.string.toast_unpinned));
            });
        });
    }

    private void loadNotes() {
        // ★ УБРАН resetAnimationCache — он ломал UX (все заметки заново анимировались).
        // NoteAdapter сам чистит устаревшие id. ★
        storage.loadAsync(loaded -> {
            if (isFinishing() || isDestroyed()) return;

            notes.clear();
            if (loaded == null) {
                emptyText.setText(R.string.error_decrypt_failed);
                emptyText.setVisibility(View.VISIBLE);
                fab.setEnabled(false);
                adapter.notifyDataSetChanged();
                return;
            }
            emptyText.setText(R.string.no_notes);
            fab.setEnabled(true);
            for (Note n : loaded) {
                if (n != null && !n.deleted) notes.add(n);
            }
            adapter.notifyDataSetChanged();
            updateEmptyState();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        loadNotes();
    }

    private void openEditor(Note note) {
        Intent i = new Intent(this, EditNoteActivity.class);
        if (note != null) i.putExtra("note_id", note.id);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
    }

    private void updateEmptyState() {
        emptyText.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}