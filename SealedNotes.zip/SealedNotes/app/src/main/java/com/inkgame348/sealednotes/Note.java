package com.inkgame348.sealednotes;

import java.util.ArrayList;
import java.util.List;

public class Note {
    public String id;
    public String title;
    public String content;
    public long timestamp;
    public boolean pinned = false;
    public boolean deleted = false;
    public long deletedAt = 0;
    public List<String> attachments = new ArrayList<>();

    /** true, если content загружен с диска. В индексе — false. */
    public boolean contentLoaded = false;
}