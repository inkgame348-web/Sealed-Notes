package com.inkgame348.sealednotes;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Base64;
import androidx.documentfile.provider.DocumentFile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class BackupHelper {

    private static final String PREFS = "sealednotes_backup";
    private static final String KEY_FOLDER_URI = "folder_uri";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_PASSWORD_ENC = "password_enc";

    private static final String FILE_NAME_JSON = "sealednotes_autobackup.json";
    private static final String FILE_NAME_ENC = "sealednotes_autobackup.enc";

    private static final int PBKDF2_ITERATIONS = 20000;
    private static final int SALT_LEN = 16;
    private static final int IV_LEN = 12;
    private static final int GCM_TAG_BITS = 128;

    // ==================== Preferences ====================

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isEnabled(Context ctx) {
        return prefs(ctx).getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context ctx, boolean enabled) {
        prefs(ctx).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public static String getFolderUri(Context ctx) {
        return prefs(ctx).getString(KEY_FOLDER_URI, null);
    }

    public static void setFolderUri(Context ctx, String uri) {
        prefs(ctx).edit().putString(KEY_FOLDER_URI, uri).apply();
    }

    public static boolean isPasswordSet(Context ctx) {
        return prefs(ctx).getString(KEY_PASSWORD_ENC, null) != null;
    }

    public static void setPassword(Context ctx, String password) throws Exception {
        byte[] enc = KeyStoreHelper.encrypt(password.getBytes(StandardCharsets.UTF_8));
        prefs(ctx).edit().putString(KEY_PASSWORD_ENC,
            Base64.encodeToString(enc, Base64.NO_WRAP)).apply();
    }

    public static void clearPassword(Context ctx) {
        prefs(ctx).edit().remove(KEY_PASSWORD_ENC).apply();
    }

    /** Возвращает пароль в открытом виде или null. */
    public static String getPassword(Context ctx) {
        String encStr = prefs(ctx).getString(KEY_PASSWORD_ENC, null);
        if (encStr == null) return null;
        try {
            byte[] enc = Base64.decode(encStr, Base64.NO_WRAP);
            byte[] plain = KeyStoreHelper.decrypt(enc);
            return new String(plain, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    // ==================== Auto-backup ====================

    public static void autoBackup(Context ctx) {
        if (!isEnabled(ctx)) return;
        String uriStr = getFolderUri(ctx);
        if (uriStr == null) return;
        try {
            Uri folderUri = Uri.parse(uriStr);
            DocumentFile dir = DocumentFile.fromTreeUri(ctx, folderUri);
            if (dir == null || !dir.canWrite()) return;

            String json = buildJson(ctx);
            String password = getPassword(ctx);

            if (password != null && !password.isEmpty()) {
                byte[] enc = encryptWithPassword(json.getBytes(StandardCharsets.UTF_8), password);
                writeFile(ctx, dir, FILE_NAME_ENC, enc);
                DocumentFile oldJson = dir.findFile(FILE_NAME_JSON);
                if (oldJson != null) oldJson.delete();
            } else {
                writeFile(ctx, dir, FILE_NAME_JSON, json.getBytes(StandardCharsets.UTF_8));
                DocumentFile oldEnc = dir.findFile(FILE_NAME_ENC);
                if (oldEnc != null) oldEnc.delete();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void writeFile(Context ctx, DocumentFile dir, String name, byte[] data) {
        try {
            DocumentFile file = dir.findFile(name);
            if (file == null) file = dir.createFile("application/octet-stream", name);
            if (file == null) return;
            try (OutputStream os = ctx.getContentResolver().openOutputStream(file.getUri(), "wt")) {
                if (os == null) return;
                os.write(data);
                os.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ==================== Build JSON ====================

    public static String buildJson(Context ctx) throws Exception {
        NoteStorage storage = new NoteStorage(ctx);
        List<Note> notes = storage.load();
        JSONArray arr = new JSONArray();
        for (Note n : notes) {
            JSONObject o = new JSONObject();
            o.put("id", n.id);
            o.put("title", n.title);
            o.put("content", n.content);
            o.put("timestamp", n.timestamp);
            o.put("pinned", n.pinned);
            JSONArray atts = new JSONArray();
            for (String s : n.attachments) atts.put(s);
            o.put("attachments", atts);
            arr.put(o);
        }
        return arr.toString(2);
    }

    // ==================== Import ====================

    /**
     * Импорт. Если файл зашифрован — нужен пароль.
     * Возвращает количество заметок.
     */
    public static int importFromBytes(Context ctx, byte[] data, String password) throws Exception {
        String json;
        String asText = new String(data, StandardCharsets.UTF_8);

        if (asText.trim().startsWith("[")) {
            // Plaintext JSON
            json = asText;
        } else {
            // Зашифрованный файл
            if (password == null || password.isEmpty())
                throw new Exception("Файл зашифрован. Введите пароль.");
            byte[] plain = decryptWithPassword(data, password);
            json = new String(plain, StandardCharsets.UTF_8);
        }

        JSONArray arr = new JSONArray(json);
        List<Note> notes = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Note n = new Note();
            n.id = o.optString("id", "");
            n.title = o.optString("title", "");
            n.content = o.optString("content", "");
            n.timestamp = o.optLong("timestamp", 0);
            n.pinned = o.optBoolean("pinned", false);
            JSONArray atts = o.optJSONArray("attachments");
            if (atts != null) for (int j = 0; j < atts.length(); j++)
                n.attachments.add(atts.getString(j));
            notes.add(n);
        }

        NoteStorage storage = new NoteStorage(ctx);
        storage.save(notes);
        return notes.size();
    }

    /** Определяет, зашифрован ли файл (по содержимому). */
    public static boolean looksEncrypted(byte[] data) {
        if (data == null || data.length < 4) return false;
        String head = new String(data, 0, Math.min(200, data.length), StandardCharsets.UTF_8);
        return !head.trim().startsWith("[");
    }

    // ==================== Crypto ====================

    public static byte[] encryptWithPassword(byte[] plaintext, String password) throws Exception {
        byte[] salt = new byte[SALT_LEN];
        byte[] iv = new byte[IV_LEN];
        new SecureRandom().nextBytes(salt);
        new SecureRandom().nextBytes(iv);

        SecretKey key = deriveKey(password, salt);

        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        byte[] ct = c.doFinal(plaintext);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(salt);
        out.write(iv);
        out.write(ct);
        return out.toByteArray();
    }

    public static byte[] decryptWithPassword(byte[] data, String password) throws Exception {
        if (data.length < SALT_LEN + IV_LEN + 16) throw new Exception("Файл слишком короткий");

        byte[] salt = new byte[SALT_LEN];
        byte[] iv = new byte[IV_LEN];
        byte[] ct = new byte[data.length - SALT_LEN - IV_LEN];

        System.arraycopy(data, 0, salt, 0, SALT_LEN);
        System.arraycopy(data, SALT_LEN, iv, 0, IV_LEN);
        System.arraycopy(data, SALT_LEN + IV_LEN, ct, 0, ct.length);

        SecretKey key = deriveKey(password, salt);

        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    private static SecretKey deriveKey(String password, byte[] salt) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, 256);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }
}