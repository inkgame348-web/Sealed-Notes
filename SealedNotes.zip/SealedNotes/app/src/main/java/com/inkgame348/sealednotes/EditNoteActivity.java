package com.inkgame348.sealednotes;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class EditNoteActivity extends AppCompatActivity {

    private static final long AUTOSAVE_DELAY_MS = 800;

    private EditText titleField, contentField;
    private LinearLayout attachmentsList;
    private String existingId = null;
    private Note currentNote = null;
    private String originalTitle = "";
    private String originalContent = "";

    private NoteStorage storage;

    private final Handler autoSaveHandler = new Handler(Looper.getMainLooper());
    private final Runnable autoSaveRunnable = this::saveNow;
    private boolean suppressWatcher = false;

    private final AtomicBoolean saveInFlight = new AtomicBoolean(false);
    private volatile boolean pendingSave = false;

    private final ActivityResultLauncher<String> filePicker =
        registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null) return;
            // ★ ФИКС: локально снимаем currentNote в final-переменную,
            // чтобы не было NPE между проверкой и использованием.
            final Note noteAtPick = currentNote;
            if (noteAtPick == null) return;
            final String noteId = noteAtPick.id;
            AttachmentHelper.copyToPrivateAsync(this, uri, noteId, name -> {
                if (name == null) {
                    ToastHelper.show(this, getString(R.string.toast_cannot_open));
                    return;
                }
                if (isFinishing() || isDestroyed()) return;
                // ★ ФИКС: повторно читаем currentNote, а не используем старую ссылку.
                final Note live = currentNote;
                if (live == null || !live.id.equals(noteId)) {
                    File orphan = AttachmentHelper.getAttachment(this, noteId, name);
                    if (orphan != null && orphan.exists()) orphan.delete();
                    return;
                }
                live.attachments.add(name);
                renderAttachments();
                saveNow();
                ToastHelper.show(this, getString(R.string.toast_file_attached));
            });
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_edit_note);
        storage = new NoteStorage(this);

        titleField = findViewById(R.id.edit_title);
        contentField = findViewById(R.id.edit_content);
        attachmentsList = findViewById(R.id.attachments_list);
        ImageButton attachBtn = findViewById(R.id.btn_attach);
        ImageButton shareBtn = findViewById(R.id.btn_share);
        ImageButton backBtn = findViewById(R.id.btn_back);
        ImageButton saveBtn = findViewById(R.id.btn_save);

        existingId = getIntent().getStringExtra("note_id");

        if (existingId != null) {
            storage.loadFullAsync(existingId, loaded -> {
                if (isFinishing() || isDestroyed()) return;
                if (loaded == null) {
                    ToastHelper.show(this, getString(R.string.error_note_open));
                    finish();
                    return;
                }
                currentNote = loaded;
                suppressWatcher = true;
                titleField.setText(currentNote.title);
                contentField.setText(currentNote.content);
                suppressWatcher = false;
                originalTitle = currentNote.title;
                originalContent = currentNote.content;
                renderAttachments();
            });
        } else {
            currentNote = new Note();
            currentNote.id = UUID.randomUUID().toString();
            currentNote.timestamp = System.currentTimeMillis();
            currentNote.contentLoaded = true;
        }

        renderAttachments();

        LinearLayout root = findViewById(R.id.edit_root);
        if (root != null) {
            LayoutAnimationController lac = AnimationUtils.loadLayoutAnimation(
                this, R.anim.layout_settings);
            root.setLayoutAnimation(lac);
            root.scheduleLayoutAnimation();
        }

        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                if (suppressWatcher) return;
                scheduleAutoSave();
            }
        };
        titleField.addTextChangedListener(watcher);
        contentField.addTextChangedListener(watcher);

        attachBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(() -> filePicker.launch("*/*"), 80);
        });
        shareBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::shareNote, 80);
        });
        backBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::attemptExit, 80);
        });
        saveBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(() -> {
                saveNow();
                finish();
            }, 80);
        });
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (MasterKeyManager.isUnlocked()) MasterKeyManager.markActive(this);
    }

    private void scheduleAutoSave() {
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        autoSaveHandler.postDelayed(autoSaveRunnable, AUTOSAVE_DELAY_MS);
    }

    private void flushAutoSave() {
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        saveNow();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (currentNote != null && !MasterKeyManager.isLocked(this)) {
            flushAutoSave();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void animateBtn(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(70)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start())
            .start();
    }

    private void shareNote() {
        String t = titleField.getText().toString().trim();
        String c = contentField.getText().toString().trim();
        if (t.isEmpty() && c.isEmpty()) {
            ToastHelper.show(this, getString(R.string.toast_note_empty));
            return;
        }
        String text = (t.isEmpty() ? "" : t + "\n\n") + c;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, t);
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, getString(R.string.share_chooser)));
    }

    private void renderAttachments() {
        if (currentNote == null) return;
        attachmentsList.removeAllViews();
        if (currentNote.attachments.isEmpty()) {
            attachmentsList.setVisibility(View.GONE);
            return;
        }
        attachmentsList.setVisibility(View.VISIBLE);
        LayoutInflater inf = LayoutInflater.from(this);
        int index = 0;
        for (String name : new ArrayList<>(currentNote.attachments)) {
            View row = inf.inflate(R.layout.item_attachment, attachmentsList, false);
            TextView label = row.findViewById(R.id.att_name);
            ImageView thumb = row.findViewById(R.id.att_thumb);
            label.setText(name);

            if (isImage(name)) {
                thumb.setImageResource(R.drawable.ic_image);
            } else {
                thumb.setImageResource(R.drawable.ic_file);
            }

            row.setAlpha(0f);
            row.setTranslationY(20f);
            row.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(300)
                .setStartDelay(index * 60L)
                .setInterpolator(new DecelerateInterpolator())
                .start();
            index++;

            row.setOnClickListener(v -> openAttachment(name));
            row.findViewById(R.id.att_remove).setOnClickListener(v -> {
                row.animate()
                    .alpha(0f)
                    .scaleX(0.85f)
                    .scaleY(0.85f)
                    .setDuration(180)
                    .withEndAction(() -> {
                        final Note live = currentNote;
                        if (live == null) return;
                        live.attachments.remove(name);
                        final String noteId = live.id;
                        AppExecutors.get().diskIO().execute(() -> {
                            File f2 = AttachmentHelper.getAttachment(
                                getApplicationContext(), noteId, name);
                            if (f2 != null && f2.exists()) f2.delete();
                        });
                        renderAttachments();
                        saveNow();
                        ToastHelper.show(this, getString(R.string.toast_file_deleted));
                    })
                    .start();
            });
            attachmentsList.addView(row);
        }
    }

    private boolean isImage(String name) {
        if (name == null) return false;
        String n = name.toLowerCase();
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")
            || n.endsWith(".gif") || n.endsWith(".webp") || n.endsWith(".bmp");
    }

    private void openAttachment(String name) {
        if (currentNote == null) return;
        try {
            File f = AttachmentHelper.getAttachment(this, currentNote.id, name);
            if (f == null || !f.exists()) return;
            Uri uri = FileProvider.getUriForFile(this,
                "com.inkgame348.sealednotes.fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, null));
        } catch (Exception e) {
            ToastHelper.show(this, getString(R.string.toast_cannot_open));
        }
    }

    private void saveNow() {
        if (currentNote == null) return;
        if (NoteStorage.LOAD_FAILED) return;
        if (MasterKeyManager.isLocked(this)) return;

        final String t = titleField.getText().toString().trim();
        final String c = contentField.getText().toString().trim();

        if (t.isEmpty() && c.isEmpty() && currentNote.attachments.isEmpty()) {
            if (existingId != null) {
                final String idToRemove = existingId;
                storage.loadAsync(all -> {
                    if (all == null) return;
                    all.removeIf(n -> n != null && n.id.equals(idToRemove));
                    storage.saveAsync(all, null);
                });
            }
            return;
        }

        if (!saveInFlight.compareAndSet(false, true)) {
            pendingSave = true;
            return;
        }

        currentNote.title = t;
        currentNote.content = c;
        currentNote.timestamp = System.currentTimeMillis();
        currentNote.contentLoaded = true;

        final Note snapshot = NoteStorage.copyOf(currentNote);

        storage.saveOneAsync(snapshot, () -> {
            if (isFinishing() || isDestroyed()) {
                saveInFlight.set(false);
                return;
            }
            saveInFlight.set(false);
            originalTitle = t;
            originalContent = c;
            existingId = snapshot.id;
            if (pendingSave) {
                pendingSave = false;
                saveNow();
            }
        });
    }

    private void attemptExit() {
        flushAutoSave();
        finish();
    }

    @Override
    public void onBackPressed() { attemptExit(); }
}