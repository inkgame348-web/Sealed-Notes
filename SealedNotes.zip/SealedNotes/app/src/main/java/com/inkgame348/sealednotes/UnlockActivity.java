package com.inkgame348.sealednotes;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.concurrent.Executor;

public class UnlockActivity extends AppCompatActivity {

    private EditText passwordField;
    private Button unlockBtn;
    private Button biometricBtn;
    private TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        if (!MasterKeyManager.isLocked(this)) {
            goToMain();
            return;
        }

        setContentView(R.layout.activity_unlock);
        passwordField = findViewById(R.id.unlock_password);
        unlockBtn = findViewById(R.id.unlock_button);
        biometricBtn = findViewById(R.id.unlock_biometric);
        hint = findViewById(R.id.unlock_hint);

        boolean hasPwd = MasterKeyManager.hasPassword(this);
        boolean hasBio = MasterKeyManager.hasBiometric(this);

        if (hasPwd) {
            passwordField.setVisibility(View.VISIBLE);
            unlockBtn.setVisibility(View.VISIBLE);
            hint.setText(R.string.unlock_hint_password);
        } else {
            passwordField.setVisibility(View.GONE);
            unlockBtn.setVisibility(View.GONE);
            hint.setText(R.string.unlock_hint_biometric);
        }

        if (hasBio && isBiometricAvailable()) {
            biometricBtn.setVisibility(View.VISIBLE);
        } else {
            biometricBtn.setVisibility(View.GONE);
        }

        passwordField.setOnEditorActionListener((v, actionId, event) -> {
            doUnlockWithPassword();
            return true;
        });

        unlockBtn.setOnClickListener(v -> doUnlockWithPassword());
        biometricBtn.setOnClickListener(v -> promptBiometric());

        if (!hasPwd && hasBio) {
            promptBiometric();
        }
    }

    private void doUnlockWithPassword() {
        final String pwd = passwordField.getText().toString();
        if (pwd.isEmpty()) return;

        unlockBtn.setEnabled(false);
        passwordField.setEnabled(false);

        AppExecutors.get().crypto().execute(() -> {
            final boolean ok = MasterKeyManager.unlockWithPassword(
                UnlockActivity.this, pwd);
            AppExecutors.get().runOnMain(() -> {
                if (isFinishing() || isDestroyed()) return;
                unlockBtn.setEnabled(true);
                passwordField.setEnabled(true);
                if (ok) {
                    goToMain();
                } else {
                    ToastHelper.show(UnlockActivity.this,
                        getString(R.string.unlock_wrong_password));
                    passwordField.setText("");
                }
            });
        });
    }

    private boolean isBiometricAvailable() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            BiometricManager bm = BiometricManager.from(this);
            return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                == BiometricManager.BIOMETRIC_SUCCESS;
        }
        BiometricManager bm = BiometricManager.from(this);
        return bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
            | BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            == BiometricManager.BIOMETRIC_SUCCESS;
    }

    private void promptBiometric() {
        if (!isBiometricAvailable()) {
            ToastHelper.show(this, getString(R.string.error_biometric_unavailable));
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        byte[] wrapped = MasterKeyManager.getBiometricWrapped(UnlockActivity.this);
                        if (wrapped == null) {
                            ToastHelper.show(UnlockActivity.this,
                                getString(R.string.error_keystore));
                            return;
                        }
                        byte[] dk = KeyStoreHelper.decryptDevice(wrapped);
                        MasterKeyManager.setBiometricUnlocked(dk);
                        MasterKeyManager.markBiometricHealthy(UnlockActivity.this);
                        goToMain();
                    } catch (KeyPermanentlyInvalidatedException e) {
                        handleInvalidatedKey();
                    } catch (Exception e) {
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.toast_error, safeMsg(e)));
                    }
                }

                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    if (MasterKeyManager.hasPassword(UnlockActivity.this)) {
                        hint.setText(R.string.unlock_hint_password);
                    } else {
                        hint.setText(R.string.unlock_hint_biometric_tap);
                    }
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_biometric_title))
            .setSubtitle(getString(R.string.unlock_biometric_subtitle));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            b.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        } else {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG);
            b.setNegativeButtonText(getString(R.string.cancel));
        }

        prompt.authenticate(b.build());
    }

    /**
     * ★ ФИКС: метода disableProtection больше нет.
     * При инвалидации ключа сбрасываем всё: и биометрию, и пароль.
     * clearAll не бросает checked-исключений, поэтому try/catch не нужен.
     */
    private void handleInvalidatedKey() {
        MasterKeyManager.clearAll(this);

        new AnimDialog(this)
            .setTitle(R.string.biometric_invalidated_title)
            .setMessage(R.string.biometric_invalidated_full_reset)
            .setPositiveButton(android.R.string.ok, (d, w) -> {
                MasterKeyManager.lock();
                goToMain();
            })
            .setCancelable(false)
            .show();
    }

    private static String safeMsg(Throwable t) {
        if (t == null) return "unknown";
        String m = t.getMessage();
        if (m == null || m.isEmpty()) return t.getClass().getSimpleName();
        return m;
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}