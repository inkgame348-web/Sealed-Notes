package com.inkgame348.sealednotes;

import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;

import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class KeyStoreHelper {
    private static final String KEYSTORE = "AndroidKeyStore";
    private static final String FALLBACK_ALIAS = "SealedNotesFallbackKey";
    private static final String DEVICE_ALIAS = "SealedNotesDeviceKey_v3";
    private static final String OLD_BIOMETRIC_ALIAS = "SealedNotesBiometricKey_v2";
    private static final String OLDER_BIOMETRIC_ALIAS = "SealedNotesBiometricKey";
    private static final String OLD_ALIAS = "SealedNotesMasterKey";
    private static final int GCM_TAG_BITS = 128;
    private static final int AUTH_TIMEOUT_SECONDS = 30;

    // ============ FALLBACK ============

    private static SecretKey getOrCreateFallbackKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(FALLBACK_ALIAS)) {
            return (SecretKey) ks.getKey(FALLBACK_ALIAS, null);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
            FALLBACK_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build();
        kg.init(spec);
        return kg.generateKey();
    }

    public static byte[] encryptFallback(byte[] plaintext) throws Exception {
        SecretKey key = getOrCreateFallbackKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    public static byte[] decryptFallback(byte[] data) throws Exception {
        if (data == null || data.length < 2) {
            throw new Exception("Encrypted blob too short");
        }
        SecretKey key = getOrCreateFallbackKey();
        int ivLen = data[0] & 0xFF;
        if (ivLen < 1 || ivLen > data.length - 2) {
            throw new Exception("Bad IV length: " + ivLen);
        }
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    // ============ MIGRATION ============

    public static boolean hasOldKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        return ks.containsAlias(OLD_ALIAS);
    }

    public static byte[] decryptOld(byte[] data) throws Exception {
        if (data == null || data.length < 2) {
            throw new Exception("Old blob too short");
        }
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (!ks.containsAlias(OLD_ALIAS)) throw new Exception("Old key missing");
        SecretKey key = (SecretKey) ks.getKey(OLD_ALIAS, null);
        int ivLen = data[0] & 0xFF;
        if (ivLen < 1 || ivLen > data.length - 2) {
            throw new Exception("Bad IV length: " + ivLen);
        }
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    // ============ DEVICE ============

    public static void deleteBiometricKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(DEVICE_ALIAS)) ks.deleteEntry(DEVICE_ALIAS);
        if (ks.containsAlias(OLD_BIOMETRIC_ALIAS)) ks.deleteEntry(OLD_BIOMETRIC_ALIAS);
        if (ks.containsAlias(OLDER_BIOMETRIC_ALIAS)) ks.deleteEntry(OLDER_BIOMETRIC_ALIAS);
    }

    /**
     * ★ ФИКС: только чтение существующего ключа. Если ключа нет —
     * бросаем KeyPermanentlyInvalidatedException. Не создаём новый,
     * иначе decryptDevice получит свежий ключ и упадёт с AEADBadTag,
     * вместо того чтобы вызвать handleInvalidatedKey.
     */
    private static SecretKey getDeviceKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (!ks.containsAlias(DEVICE_ALIAS)) {
            throw new KeyPermanentlyInvalidatedException("Device key missing");
        }
        return (SecretKey) ks.getKey(DEVICE_ALIAS, null);
    }

    /**
     * ★ ФИКС: создаёт новый ключ, предварительно удаляя старый.
     * Вызывается только из encryptDevice — то есть при включении
     * биометрии или обновлении привязки. Побочного эффекта у
     * проверок больше нет.
     */
    private static SecretKey createDeviceKey() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(DEVICE_ALIAS)) ks.deleteEntry(DEVICE_ALIAS);
        if (ks.containsAlias(OLD_BIOMETRIC_ALIAS)) ks.deleteEntry(OLD_BIOMETRIC_ALIAS);
        if (ks.containsAlias(OLDER_BIOMETRIC_ALIAS)) ks.deleteEntry(OLDER_BIOMETRIC_ALIAS);

        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(
            DEVICE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            b.setUserAuthenticationParameters(
                AUTH_TIMEOUT_SECONDS,
                KeyProperties.AUTH_BIOMETRIC_STRONG | KeyProperties.AUTH_DEVICE_CREDENTIAL);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            b.setUserAuthenticationValidityDurationSeconds(AUTH_TIMEOUT_SECONDS);
        }

        kg.init(b.build());
        return kg.generateKey();
    }

    public static byte[] encryptDevice(byte[] plaintext) throws Exception {
        SecretKey key = createDeviceKey();
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(plaintext);
        byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    public static byte[] decryptDevice(byte[] data) throws Exception {
        if (data == null || data.length < 2) throw new Exception("Too short");
        SecretKey key = getDeviceKey();
        int ivLen = data[0] & 0xFF;
        if (ivLen < 1 || ivLen > data.length - 2) throw new Exception("Bad IV len");
        byte[] iv = new byte[ivLen];
        System.arraycopy(data, 1, iv, 0, ivLen);
        byte[] ct = new byte[data.length - 1 - ivLen];
        System.arraycopy(data, 1 + ivLen, ct, 0, ct.length);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    // ============ ПРОВЕРКИ ============

    /**
     * ★ ФИКС: больше не создаёт ключ как побочный эффект.
     * Возвращает true, если Keystore доступен и биометрия настроена.
     * Реальная проверка enrolled — через BiometricManager, не здесь.
     */
    public static boolean canUseBiometricOrDevice() {
        try {
            KeyStore ks = KeyStore.getInstance(KEYSTORE);
            ks.load(null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}