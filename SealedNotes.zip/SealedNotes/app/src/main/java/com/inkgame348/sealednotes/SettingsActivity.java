package com.inkgame348.sealednotes;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.os.LocaleListCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executor;

import javax.crypto.Cipher;

public class SettingsActivity extends AppCompatActivity {

    private static final int CREATE_FILE_REQUEST_CODE = 1001;
    private static final int PICK_IMPORT_FILE_REQUEST_CODE = 1003;

    private String exportJsonContent = "";
    private String pendingExportPassword = null;

    private TextView masterPasswordValue;
    private TextView biometricValue;
    private TextView autolockValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_settings);

        LinearLayout root = findViewById(R.id.settings_root);
        if (root != null) {
            LayoutAnimationController lac = AnimationUtils.loadLayoutAnimation(
                this, R.anim.layout_settings);
            root.setLayoutAnimation(lac);
            root.scheduleLayoutAnimation();
        }

        ImageButton backBtn = findViewById(R.id.btn_back);
        RadioGroup themeGroup = findViewById(R.id.theme_group);
        LinearLayout languageRow = findViewById(R.id.row_language);
        LinearLayout masterPasswordRow = findViewById(R.id.row_master_password);
        LinearLayout biometricRow = findViewById(R.id.row_biometric);
        LinearLayout autolockRow = findViewById(R.id.row_autolock);
        LinearLayout importRow = findViewById(R.id.row_import);
        LinearLayout backupCloudRow = findViewById(R.id.row_backup_cloud);
        LinearLayout exportRow = findViewById(R.id.row_export);
        TextView languageValue = findViewById(R.id.language_value);
        masterPasswordValue = findViewById(R.id.master_password_value);
        biometricValue = findViewById(R.id.biometric_value);
        autolockValue = findViewById(R.id.autolock_value);

        int theme = SettingsStorage.getTheme(this);
        themeGroup.check(theme == SettingsStorage.THEME_LIGHT ? R.id.theme_light
                     : theme == SettingsStorage.THEME_DARK ? R.id.theme_dark
                     : R.id.theme_system);

        themeGroup.setOnCheckedChangeListener((g, id) -> {
            int newTheme;
            if (id == R.id.theme_light) newTheme = SettingsStorage.THEME_LIGHT;
            else if (id == R.id.theme_dark) newTheme = SettingsStorage.THEME_DARK;
            else newTheme = SettingsStorage.THEME_SYSTEM;
            SettingsStorage.setTheme(this, newTheme);
            AppCompatDelegate.setDefaultNightMode(
                newTheme == SettingsStorage.THEME_LIGHT ? AppCompatDelegate.MODE_NIGHT_NO
                : newTheme == SettingsStorage.THEME_DARK ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        });

        updateLanguageLabel(languageValue);
        updateLockLabels();

        masterPasswordRow.setOnClickListener(v -> {
            animateRow(v);
            showMasterPasswordDialog();
        });
        biometricRow.setOnClickListener(v -> {
            animateRow(v);
            toggleBiometric();
        });
        autolockRow.setOnClickListener(v -> {
            animateRow(v);
            showAutolockDialog();
        });
        importRow.setOnClickListener(v -> {
            animateRow(v);
            pickImportFile();
        });
        languageRow.setOnClickListener(v -> {
            animateRow(v);
            showLanguageDialog();
        });
        backupCloudRow.setOnClickListener(v -> {
            animateRow(v);
            backupToCloud();
        });
        exportRow.setOnClickListener(v -> {
            animateRow(v);
            exportToFile();
        });
        backBtn.setOnClickListener(v -> {
            animateRow(v);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void animateRow(View v) {
        v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start())
            .start();
    }

    private void updateLockLabels() {
        masterPasswordValue.setText(MasterKeyManager.hasPassword(this)
            ? R.string.master_password_set : R.string.master_password_none);

        if (!MasterKeyManager.hasBiometric(this)) {
            biometricValue.setText(R.string.biometric_off);
        } else if (!MasterKeyManager.isBiometricHealthy(this)) {
            biometricValue.setText(R.string.biometric_broken);
        } else {
            biometricValue.setText(R.string.biometric_on);
        }

        updateAutolockLabel();
    }

    private void updateAutolockLabel() {
        long ms = MasterKeyManager.getAutoLockMs(this);
        if (ms <= 0) {
            autolockValue.setText(R.string.autolock_off);
        } else {
            long min = ms / 60_000;
            if (min == 1) autolockValue.setText(R.string.autolock_1min);
            else autolockValue.setText(getString(R.string.autolock_min, (int)min));
        }
    }

    private void showAutolockDialog() {
        final long[] values = {
            0, 60_000, 5 * 60_000, 15 * 60_000, 30 * 60_000, 60 * 60_000
        };
        final String[] items = {
            getString(R.string.autolock_off),
            getString(R.string.autolock_1min),
            getString(R.string.autolock_min, 5),
            getString(R.string.autolock_min, 15),
            getString(R.string.autolock_min, 30),
            getString(R.string.autolock_min, 60)
        };

        long current = MasterKeyManager.getAutoLockMs(this);
        int checked = 2;
        for (int i = 0; i < values.length; i++) {
            if (values[i] == current) { checked = i; break; }
        }

        new AnimDialog(this)
            .setTitle(R.string.autolock_title)
            .setSingleChoiceItems(items, checked, (d, which) -> {
                MasterKeyManager.setAutoLockMs(this, values[which]);
                updateAutolockLabel();
                d.dismiss();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void showMasterPasswordDialog() {
        boolean hasPwd = MasterKeyManager.hasPassword(this);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        container.setPadding(pad, pad / 2, pad, 0);

        EditText input1 = new EditText(this);
        input1.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input1.setHint(R.string.master_password_hint);
        container.addView(input1);

        EditText input2 = new EditText(this);
        input2.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input2.setHint(R.string.master_password_confirm_hint);
        container.addView(input2);

        AnimDialog builder = new AnimDialog(this);
        builder.setTitle(R.string.master_password_title);
        builder.setMessage(hasPwd
            ? R.string.master_password_change_hint
            : R.string.master_password_new_hint);
        builder.setView(container);
        builder.setPositiveButton(R.string.master_password_save, (d, w) -> {
            String pwd1 = input1.getText().toString();
            String pwd2 = input2.getText().toString();
            if (pwd1.length() < 4) {
                ToastHelper.show(this, getString(R.string.master_password_too_short));
                return;
            }
            if (!pwd1.equals(pwd2)) {
                ToastHelper.show(this, getString(R.string.master_password_mismatch));
                return;
            }
            try {
                MasterKeyManager.setPassword(this, pwd1);
                ToastHelper.show(this, getString(R.string.master_password_saved));
                updateLockLabels();
            } catch (Exception e) {
                ToastHelper.show(this, "Ошибка: " + e.getMessage());
            }
        });
        builder.setNegativeButton(R.string.cancel, null);

        if (hasPwd) {
            builder.setNeutralButton(R.string.master_password_remove, (d, w) -> {
                MasterKeyManager.removePassword(this);
                ToastHelper.show(this, getString(R.string.master_password_removed));
                updateLockLabels();
            });
        }
        builder.show();
    }

    private void toggleBiometric() {
        if (MasterKeyManager.hasBiometric(this)) {
            new AnimDialog(this)
                .setTitle(R.string.biometric_menu_title)
                .setItems(new CharSequence[]{
                    getString(R.string.biometric_refresh),
                    getString(R.string.biometric_disable)
                }, (d, which) -> {
                    if (which == 0) refreshBiometric();
                    else confirmDisableBiometric();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        } else {
            enableBiometric();
        }
    }

    private void refreshBiometric() {
        try {
            MasterKeyManager.removeBiometric(this);
        } catch (Exception e) {
            ToastHelper.show(this, "Ошибка: " + e.getMessage());
            return;
        }
        enableBiometric();
    }

    private void confirmDisableBiometric() {
        new AnimDialog(this)
            .setTitle(R.string.biometric_off_title)
            .setMessage(MasterKeyManager.hasPassword(this)
                ? R.string.biometric_off_msg
                : R.string.biometric_off_msg_no_password)
            .setPositiveButton(R.string.biometric_disable, (d, w) -> {
                try {
                    MasterKeyManager.removeBiometric(this);
                    ToastHelper.show(this, getString(R.string.biometric_disabled));
                    updateLockLabels();
                } catch (Exception e) {
                    ToastHelper.show(this, "Ошибка: " + e.getMessage());
                }
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void enableBiometric() {
        BiometricManager bm = BiometricManager.from(this);
        int can = bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK
            | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            ToastHelper.show(this, "Биометрия недоступна на этом устройстве");
            return;
        }

        if (!MasterKeyManager.hasPassword(this)) {
            new AnimDialog(this)
                .setTitle(R.string.biometric_no_password_warn_title)
                .setMessage(R.string.biometric_no_password_warn_msg)
                .setPositiveButton(R.string.biometric_continue, (d, w) -> doEnableBiometric())
                .setNegativeButton(R.string.cancel, null)
                .show();
        } else {
            doEnableBiometric();
        }
    }

    private void doEnableBiometric() {
        Cipher cipher;
        try {
            cipher = KeyStoreHelper.getBiometricEncryptCipher();
        } catch (Exception e) {
            new AnimDialog(this)
                .setTitle("Ошибка Keystore")
                .setMessage("Не удалось создать биометрический ключ.\n\n" +
                    e.getClass().getSimpleName() + ": " + e.getMessage() +
                    "\n\nПопробуйте удалить текущую привязку биометрии и включить заново.")
                .setPositiveButton(android.R.string.ok, null)
                .show();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        Cipher c = result.getCryptoObject().getCipher();
                        byte[] dk = MasterKeyManager.getDkForBiometricWrap(SettingsActivity.this);
                        byte[] ct = c.doFinal(dk);
                        byte[] iv = c.getIV();
                        byte[] out = new byte[1 + iv.length + ct.length];
                        out[0] = (byte) iv.length;
                        System.arraycopy(iv, 0, out, 1, iv.length);
                        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
                        MasterKeyManager.saveBiometricWrapped(SettingsActivity.this, out);
                        ToastHelper.show(SettingsActivity.this,
                            getString(R.string.biometric_enabled));
                        updateLockLabels();
                    } catch (Exception e) {
                        ToastHelper.show(SettingsActivity.this,
                            "Ошибка: " + e.getMessage());
                    }
                }

                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    ToastHelper.show(SettingsActivity.this, "Отменено: " + msg);
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.biometric_enable_title))
            .setSubtitle(getString(R.string.biometric_enable_subtitle))
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);

        prompt.authenticate(b.build(), new BiometricPrompt.CryptoObject(cipher));
    }

    private void updateLanguageLabel(TextView tv) {
        String tag = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        String display;
        if (tag == null || tag.isEmpty()) display = getString(R.string.lang_system);
        else if (tag.startsWith("ru")) display = getString(R.string.lang_russian);
        else if (tag.startsWith("en")) display = getString(R.string.lang_english);
        else display = getString(R.string.lang_system);
        tv.setText(display);
    }

    private void showLanguageDialog() {
        String[] items = {
            getString(R.string.lang_system),
            getString(R.string.lang_russian),
            getString(R.string.lang_english)
        };
        String currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        int checked = 0;
        if (currentTag != null && currentTag.startsWith("ru")) checked = 1;
        else if (currentTag != null && currentTag.startsWith("en")) checked = 2;

        new AnimDialog(this)
            .setTitle(R.string.choose_language)
            .setSingleChoiceItems(items, checked, (dialog, which) -> {
                LocaleListCompat locales;
                if (which == 1) locales = LocaleListCompat.forLanguageTags("ru");
                else if (which == 2) locales = LocaleListCompat.forLanguageTags("en");
                else locales = LocaleListCompat.getEmptyLocaleList();
                AppCompatDelegate.setApplicationLocales(locales);
                dialog.dismiss();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void pickImportFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_IMPORT_FILE_REQUEST_CODE);
    }

    private void handleImport(byte[] data) {
        if (BackupHelper.looksEncrypted(data)) {
            askPasswordAndImport(data);
        } else {
            doImport(data, null);
        }
    }

    private void askPasswordAndImport(byte[] data) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.backup_password_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        new AnimDialog(this)
            .setTitle(R.string.restore_enter_password)
            .setView(input)
            .setPositiveButton(R.string.ok, (d, w) -> {
                String pwd = input.getText().toString();
                doImport(data, pwd);
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void doImport(byte[] data, String password) {
        try {
            int count = BackupHelper.importFromBytes(this, data, password, true);
            ToastHelper.show(this, getString(R.string.import_success, count));
        } catch (Exception e) {
            showDialog(getString(R.string.import_error, e.getMessage()));
        }
    }

    private byte[] readAllBytes(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Cannot open file");
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }

    private void askExportPassword(Runnable onProceed) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.export_password_optional_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        new AnimDialog(this)
            .setTitle(R.string.export_password_title)
            .setMessage(R.string.export_password_msg)
            .setView(input)
            .setPositiveButton(R.string.export_password_encrypt, (d, w) -> {
                String pwd = input.getText().toString();
                if (pwd.length() < 4) {
                    ToastHelper.show(this, getString(R.string.export_password_too_short));
                    return;
                }
                pendingExportPassword = pwd;
                onProceed.run();
            })
            .setNeutralButton(R.string.export_password_plain, (d, w) -> {
                pendingExportPassword = null;
                new AnimDialog(this)
                    .setTitle(R.string.export_plain_warn_title)
                    .setMessage(R.string.export_plain_warn_msg)
                    .setPositiveButton(R.string.export_plain_confirm, (d2, w2) -> onProceed.run())
                    .setNegativeButton(R.string.cancel, null)
                    .show();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void backupToCloud() {
        askExportPassword(this::doBackupToCloud);
    }

    private void doBackupToCloud() {
        try {
            String json = BackupHelper.buildJson(this);
            if (json.equals("[]") || json.isEmpty()) {
                showDialog(getString(R.string.no_notes_export));
                return;
            }
            File cacheDir = new File(getCacheDir(), "backup");
            if (!cacheDir.exists()) cacheDir.mkdirs();

            File outFile;
            if (pendingExportPassword != null && !pendingExportPassword.isEmpty()) {
                byte[] enc = BackupHelper.encryptWithPassword(
                    json.getBytes(StandardCharsets.UTF_8), pendingExportPassword);
                outFile = new File(cacheDir, "sealednotes_backup.enc");
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(enc);
                }
            } else {
                outFile = new File(cacheDir, "sealednotes_backup.json");
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }

            Uri uri = FileProvider.getUriForFile(this,
                "com.inkgame348.sealednotes.fileprovider", outFile);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/octet-stream");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "Sealed Notes backup");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, getString(R.string.backup_cloud_chooser)));
            ToastHelper.show(this, getString(R.string.toast_backup_created));
        } catch (Exception e) {
            e.printStackTrace();
            showDialog(getString(R.string.toast_error, e.getMessage()));
        } finally {
            pendingExportPassword = null;
        }
    }

    private void exportToFile() {
        askExportPassword(this::doExportToFile);
    }

    private void doExportToFile() {
        try {
            exportJsonContent = BackupHelper.buildJson(this);
            if (exportJsonContent.equals("[]") || exportJsonContent.isEmpty()) {
                showDialog(getString(R.string.no_notes_export));
                return;
            }
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            if (pendingExportPassword != null && !pendingExportPassword.isEmpty()) {
                intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, "sealednotes_backup.enc");
            } else {
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "sealednotes_backup.json");
            }
            startActivityForResult(intent, CREATE_FILE_REQUEST_CODE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CREATE_FILE_REQUEST_CODE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (pendingExportPassword != null && !pendingExportPassword.isEmpty()) {
                    byte[] enc = BackupHelper.encryptWithPassword(
                        exportJsonContent.getBytes(StandardCharsets.UTF_8), pendingExportPassword);
                    os.write(enc);
                } else {
                    os.write(exportJsonContent.getBytes(StandardCharsets.UTF_8));
                }
                ToastHelper.show(this, getString(R.string.export_success));
            } catch (Exception e) {
                showDialog(getString(R.string.toast_error, e.getMessage()));
            } finally {
                pendingExportPassword = null;
            }
        }

        if (requestCode == PICK_IMPORT_FILE_REQUEST_CODE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                byte[] bytes = readAllBytes(uri);
                handleImport(bytes);
            } catch (Exception e) {
                showDialog(getString(R.string.import_error, e.getMessage()));
            }
        }
    }

    private void showDialog(String message) {
        new AnimDialog(this)
            .setMessage(message)
            .setPositiveButton(R.string.ok, null)
            .show();
    }
}