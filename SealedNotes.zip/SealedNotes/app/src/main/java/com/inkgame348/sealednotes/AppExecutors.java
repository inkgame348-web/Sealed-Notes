package com.inkgame348.sealednotes;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class AppExecutors {

    private static volatile AppExecutors INSTANCE;

    public static AppExecutors get() {
        if (INSTANCE == null) {
            synchronized (AppExecutors.class) {
                if (INSTANCE == null) INSTANCE = new AppExecutors();
            }
        }
        return INSTANCE;
    }

    private final ExecutorService crypto;
    private final ExecutorService diskIO;
    private final Handler mainHandler;

    private AppExecutors() {
        crypto = new ThreadPoolExecutor(
            2, 2, 0L, TimeUnit.MILLISECONDS,
            new LinkedBlockingQueue<>(64),
            new NamedThreadFactory("crypto")
        );
        diskIO = Executors.newSingleThreadExecutor(new NamedThreadFactory("diskIO"));
        mainHandler = new Handler(Looper.getMainLooper());
    }

    public ExecutorService crypto() { return crypto; }
    public ExecutorService diskIO() { return diskIO; }
    public Handler main() { return mainHandler; }

    public void runOnMain(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) r.run();
        else mainHandler.post(r);
    }

    private static class NamedThreadFactory implements ThreadFactory {
        private final String prefix;
        private final AtomicInteger counter = new AtomicInteger(1);
        NamedThreadFactory(String prefix) { this.prefix = prefix; }
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, prefix + "-" + counter.getAndIncrement());
            t.setDaemon(true);
            return t;
        }
    }
}