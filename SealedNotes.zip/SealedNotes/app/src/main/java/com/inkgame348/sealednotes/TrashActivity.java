package com.inkgame348.sealednotes;

import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TrashActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private TextView emptyText;
    private NoteAdapter adapter;
    private final List<Note> trash = new ArrayList<>();
    private NoteStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_trash);

        storage = new NoteStorage(this);
        recycler = findViewById(R.id.trash_recycler);
        emptyText = findViewById(R.id.trash_empty);
        ImageButton backBtn = findViewById(R.id.trash_back);
        ImageButton emptyBtn = findViewById(R.id.trash_empty_button);

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(trash, new NoteAdapter.Listener() {
            @Override public void onClick(Note note) { showActions(note); }
            @Override public void onLongClick(Note note) { showActions(note); }
            @Override public void onSelectionChanged() {}
        });
        recycler.setAdapter(adapter);

        backBtn.setOnClickListener(v -> finish());
        emptyBtn.setOnClickListener(v -> confirmEmptyTrash());

        loadTrash();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void loadTrash() {
        trash.clear();
        for (Note n : storage.load()) {
            if (n.deleted) trash.add(n);
        }
        adapter.notifyDataSetChanged();
        updateEmpty();
    }

    private void updateEmpty() {
        emptyText.setVisibility(trash.isEmpty() ? TextView.VISIBLE : TextView.GONE);
        recycler.setVisibility(trash.isEmpty() ? TextView.GONE : TextView.VISIBLE);
    }

    private void showActions(Note note) {
        String title = note.title.isEmpty() ? getString(R.string.untitled) : note.title;
        new AnimDialog(this)
            .setTitle(title)
            .setItems(new CharSequence[]{
                getString(R.string.trash_restore),
                getString(R.string.trash_delete_forever)
            }, (d, which) -> {
                if (which == 0) restore(note);
                else confirmDeleteForever(note);
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void restore(Note note) {
        try {
            List<Note> all = storage.load();
            for (Note n : all) {
                if (n.id.equals(note.id)) {
                    n.deleted = false;
                    n.deletedAt = 0;
                    break;
                }
            }
            storage.save(all);
            loadTrash();
            ToastHelper.show(this, getString(R.string.trash_restored));
        } catch (Exception e) {
            ToastHelper.show(this, getString(R.string.toast_error, e.getMessage()));
        }
    }

    private void confirmDeleteForever(Note note) {
        new AnimDialog(this)
            .setTitle(R.string.trash_delete_forever)
            .setMessage(R.string.trash_delete_forever_msg)
            .setPositiveButton(R.string.delete, (d, w) -> {
                AttachmentHelper.deleteAllForNote(this, note.id);
                List<Note> all = storage.load();
                all.removeIf(n -> n.id.equals(note.id));
                storage.save(all);
                loadTrash();
                ToastHelper.show(this, getString(R.string.trash_deleted));
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void confirmEmptyTrash() {
        if (trash.isEmpty()) {
            ToastHelper.show(this, getString(R.string.trash_already_empty));
            return;
        }
        new AnimDialog(this)
            .setTitle(R.string.trash_empty_title)
            .setMessage(getString(R.string.trash_empty_msg, trash.size()))
            .setPositiveButton(R.string.delete, (d, w) -> {
                for (Note n : trash) {
                    AttachmentHelper.deleteAllForNote(this, n.id);
                }
                List<Note> all = storage.load();
                all.removeIf(n -> n.deleted);
                storage.save(all);
                loadTrash();
                ToastHelper.show(this, getString(R.string.trash_emptied));
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}