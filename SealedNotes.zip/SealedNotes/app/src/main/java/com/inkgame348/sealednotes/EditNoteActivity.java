package com.inkgame348.sealednotes;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class EditNoteActivity extends AppCompatActivity {

    private EditText titleField, contentField;
    private LinearLayout attachmentsList;
    private String existingId = null;
    private Note currentNote = null;
    private String originalTitle = "";
    private String originalContent = "";

    private final ActivityResultLauncher<String> filePicker =
        registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null || currentNote == null) return;
            String name = AttachmentHelper.copyToPrivate(this, uri, currentNote.id);
            if (name != null) {
                currentNote.attachments.add(name);
                renderAttachments();
                saveNow();
                ToastHelper.show(this, getString(R.string.toast_file_attached));
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_edit_note);
        titleField = findViewById(R.id.edit_title);
        contentField = findViewById(R.id.edit_content);
        attachmentsList = findViewById(R.id.attachments_list);
        ImageButton attachBtn = findViewById(R.id.btn_attach);
        ImageButton shareBtn = findViewById(R.id.btn_share);
        ImageButton backBtn = findViewById(R.id.btn_back);
        ImageButton saveBtn = findViewById(R.id.btn_save);

        existingId = getIntent().getStringExtra("note_id");
        NoteStorage storage = new NoteStorage(this);
        List<Note> all = storage.load();

        if (existingId != null) {
            for (Note n : all) if (n.id.equals(existingId)) { currentNote = n; break; }
        }
        if (currentNote == null) {
            currentNote = new Note();
            currentNote.id = UUID.randomUUID().toString();
            currentNote.timestamp = System.currentTimeMillis();
            existingId = null;
        } else {
            titleField.setText(currentNote.title);
            contentField.setText(currentNote.content);
            originalTitle = currentNote.title;
            originalContent = currentNote.content;
        }

        renderAttachments();

        LinearLayout root = findViewById(R.id.edit_root);
        if (root != null) {
            LayoutAnimationController lac = AnimationUtils.loadLayoutAnimation(
                this, R.anim.layout_settings);
            root.setLayoutAnimation(lac);
            root.scheduleLayoutAnimation();
        }

        attachBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(() -> filePicker.launch("*/*"), 80);
        });
        shareBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::shareNote, 80);
        });
        backBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(this::attemptExit, 80);
        });
        saveBtn.setOnClickListener(v -> {
            animateBtn(v);
            v.postDelayed(() -> {
                saveNow();
                finish();
            }, 80);
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void animateBtn(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(70)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start())
            .start();
    }

    private void shareNote() {
        String t = titleField.getText().toString().trim();
        String c = contentField.getText().toString().trim();
        if (t.isEmpty() && c.isEmpty()) {
            ToastHelper.show(this, getString(R.string.toast_note_empty));
            return;
        }
        String text = (t.isEmpty() ? "" : t + "\n\n") + c;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, t);
        send.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(send, getString(R.string.share_chooser)));
    }

    private void renderAttachments() {
        attachmentsList.removeAllViews();
        if (currentNote.attachments.isEmpty()) {
            attachmentsList.setVisibility(View.GONE);
            return;
        }
        attachmentsList.setVisibility(View.VISIBLE);
        LayoutInflater inf = LayoutInflater.from(this);
        int index = 0;
        for (String name : new ArrayList<>(currentNote.attachments)) {
            View row = inf.inflate(R.layout.item_attachment, attachmentsList, false);
            TextView label = row.findViewById(R.id.att_name);
            ImageView thumb = row.findViewById(R.id.att_thumb);
            label.setText(name);
            File f = AttachmentHelper.getAttachment(this, currentNote.id, name);
            if (f.exists() && isImage(name)) {
                Bitmap bmp = BitmapFactory.decodeFile(f.getAbsolutePath());
                if (bmp != null) {
                    thumb.setImageBitmap(bmp);
                } else {
                    thumb.setImageResource(R.drawable.ic_image);
                }
            } else {
                thumb.setImageResource(R.drawable.ic_file);
            }

            row.setAlpha(0f);
            row.setTranslationY(20f);
            row.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(300)
                .setStartDelay(index * 60L)
                .setInterpolator(new DecelerateInterpolator())
                .start();
            index++;

            row.setOnClickListener(v -> openAttachment(name));
            row.findViewById(R.id.att_remove).setOnClickListener(v -> {
                row.animate()
                    .alpha(0f)
                    .scaleX(0.85f)
                    .scaleY(0.85f)
                    .setDuration(180)
                    .withEndAction(() -> {
                        currentNote.attachments.remove(name);
                        File f2 = AttachmentHelper.getAttachment(this, currentNote.id, name);
                        if (f2.exists()) f2.delete();
                        renderAttachments();
                        saveNow();
                        ToastHelper.show(this, getString(R.string.toast_file_deleted));
                    })
                    .start();
            });
            attachmentsList.addView(row);
        }
    }

    private boolean isImage(String name) {
        String n = name.toLowerCase();
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")
            || n.endsWith(".gif") || n.endsWith(".webp") || n.endsWith(".bmp");
    }

    private void openAttachment(String name) {
        try {
            File f = AttachmentHelper.getAttachment(this, currentNote.id, name);
            if (!f.exists()) return;
            Uri uri = FileProvider.getUriForFile(this,
                "com.inkgame348.sealednotes.fileprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, null));
        } catch (Exception e) {
            ToastHelper.show(this, getString(R.string.toast_cannot_open));
        }
    }

    private boolean isDirty() {
        return !titleField.getText().toString().equals(originalTitle)
            || !contentField.getText().toString().equals(originalContent);
    }

    private void saveNow() {
        String t = titleField.getText().toString().trim();
        String c = contentField.getText().toString().trim();

        if (t.isEmpty() && c.isEmpty() && currentNote.attachments.isEmpty()) {
            if (existingId != null) {
                NoteStorage st = new NoteStorage(this);
                List<Note> all = st.load();
                all.removeIf(n -> n.id.equals(existingId));
                st.save(all);
            }
            return;
        }

        currentNote.title = t;
        currentNote.content = c;
        currentNote.timestamp = System.currentTimeMillis();
        NoteStorage st = new NoteStorage(this);
        List<Note> all = st.load();
        boolean found = false;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(currentNote.id)) { all.set(i, currentNote); found = true; break; }
        }
        if (!found) all.add(0, currentNote);
        st.save(all);
        originalTitle = t;
        originalContent = c;
        existingId = currentNote.id;
    }

    private void attemptExit() {
        if (isDirty()) {
            new AnimDialog(this)
                .setTitle(R.string.unsaved_title)
                .setMessage(R.string.unsaved_msg)
                .setPositiveButton(R.string.save_and_exit, (d, w) -> { saveNow(); finish(); })
                .setNegativeButton(R.string.discard, (d, w) -> finish())
                .setNeutralButton(R.string.stay, null)
                .show();
        } else {
            saveNow();
            finish();
        }
    }

    @Override public void onBackPressed() { attemptExit(); }
}