package com.inkgame348.sealednotes;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.FileProvider;
import androidx.core.os.LocaleListCompat;
import androidx.documentfile.provider.DocumentFile;

import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class SettingsActivity extends AppCompatActivity {

    private static final int CREATE_FILE_REQUEST_CODE = 1001;
    private static final int PICK_FOLDER_REQUEST_CODE = 1002;
    private static final int PICK_IMPORT_FILE_REQUEST_CODE = 1003;

    private String exportJsonContent = "";
    private TextView backupFolderValue;
    private TextView backupPasswordValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_settings);

        LinearLayout root = findViewById(R.id.settings_root);
        if (root != null) {
            LayoutAnimationController lac = AnimationUtils.loadLayoutAnimation(
                this, R.anim.layout_settings);
            root.setLayoutAnimation(lac);
            root.scheduleLayoutAnimation();
        }

        ImageButton backBtn = findViewById(R.id.btn_back);
        RadioGroup themeGroup = findViewById(R.id.theme_group);
        LinearLayout languageRow = findViewById(R.id.row_language);
        LinearLayout autoBackupRow = findViewById(R.id.row_auto_backup);
        LinearLayout backupFolderRow = findViewById(R.id.row_backup_folder);
        LinearLayout backupPasswordRow = findViewById(R.id.row_backup_password);
        LinearLayout importRow = findViewById(R.id.row_import);
        LinearLayout backupCloudRow = findViewById(R.id.row_backup_cloud);
        LinearLayout exportRow = findViewById(R.id.row_export);
        LinearLayout aboutRow = findViewById(R.id.row_about);
        TextView languageValue = findViewById(R.id.language_value);
        SwitchMaterial autoBackupSwitch = findViewById(R.id.switch_auto_backup);
        backupFolderValue = findViewById(R.id.backup_folder_value);
        backupPasswordValue = findViewById(R.id.backup_password_value);

        int theme = SettingsStorage.getTheme(this);
        themeGroup.check(theme == SettingsStorage.THEME_LIGHT ? R.id.theme_light
                     : theme == SettingsStorage.THEME_DARK ? R.id.theme_dark
                     : R.id.theme_system);

        themeGroup.setOnCheckedChangeListener((g, id) -> {
            int newTheme;
            if (id == R.id.theme_light) newTheme = SettingsStorage.THEME_LIGHT;
            else if (id == R.id.theme_dark) newTheme = SettingsStorage.THEME_DARK;
            else newTheme = SettingsStorage.THEME_SYSTEM;
            SettingsStorage.setTheme(this, newTheme);
            AppCompatDelegate.setDefaultNightMode(
                newTheme == SettingsStorage.THEME_LIGHT ? AppCompatDelegate.MODE_NIGHT_NO
                : newTheme == SettingsStorage.THEME_DARK ? AppCompatDelegate.MODE_NIGHT_YES
                : AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        });

        updateLanguageLabel(languageValue);
        updateBackupFolderLabel();
        updateBackupPasswordLabel();

        autoBackupSwitch.setChecked(BackupHelper.isEnabled(this));
        autoBackupRow.setOnClickListener(v -> {
            boolean newState = !autoBackupSwitch.isChecked();
            autoBackupSwitch.setChecked(newState);
            BackupHelper.setEnabled(this, newState);
            if (newState && BackupHelper.getFolderUri(this) == null) {
                pickFolder();
            } else if (newState) {
                new Thread(() -> BackupHelper.autoBackup(getApplicationContext())).start();
            }
        });

        backupFolderRow.setOnClickListener(v -> pickFolder());
        backupPasswordRow.setOnClickListener(v -> showPasswordDialog());
        importRow.setOnClickListener(v -> {
            animateRow(v);
            v.postDelayed(this::pickImportFile, 80);
        });
        languageRow.setOnClickListener(v -> {
            animateRow(v);
            v.postDelayed(this::showLanguageDialog, 80);
        });
        backupCloudRow.setOnClickListener(v -> {
            animateRow(v);
            v.postDelayed(this::backupToCloud, 80);
        });
        exportRow.setOnClickListener(v -> {
            animateRow(v);
            v.postDelayed(this::exportToFile, 80);
        });
        aboutRow.setOnClickListener(v -> {
            animateRow(v);
            v.postDelayed(this::showAbout, 80);
        });
        backBtn.setOnClickListener(v -> {
            animateRow(v);
            v.postDelayed(this::finish, 80);
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void animateRow(View v) {
        v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start())
            .start();
    }

    private void updateBackupFolderLabel() {
        String uri = BackupHelper.getFolderUri(this);
        if (uri == null) {
            backupFolderValue.setText(R.string.auto_backup_folder_none);
        } else {
            DocumentFile dir = DocumentFile.fromTreeUri(this, Uri.parse(uri));
            if (dir != null && dir.getName() != null) {
                backupFolderValue.setText(dir.getName());
            } else {
                backupFolderValue.setText(R.string.auto_backup_folder_none);
            }
        }
    }

    private void updateBackupPasswordLabel() {
        if (BackupHelper.isPasswordSet(this)) {
            backupPasswordValue.setText(R.string.backup_password_set);
        } else {
            backupPasswordValue.setText(R.string.backup_password_none);
        }
    }

    private void showPasswordDialog() {
        boolean hasPassword = BackupHelper.isPasswordSet(this);

        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.backup_password_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        AnimDialog builder = new AnimDialog(this);
        builder.setTitle(R.string.backup_password_dialog_title);
        builder.setMessage(R.string.backup_password_hint_field);
        builder.setView(input);
        builder.setPositiveButton(R.string.backup_password_save, (d, w) -> {
            String pwd = input.getText().toString();
            if (pwd.length() < 4) {
                ToastHelper.show(this, getString(R.string.backup_password_too_short));
                return;
            }
            try {
                BackupHelper.setPassword(this, pwd);
                updateBackupPasswordLabel();
                ToastHelper.show(this, getString(R.string.backup_password_saved));
                if (BackupHelper.isEnabled(this)) {
                    new Thread(() -> BackupHelper.autoBackup(getApplicationContext())).start();
                }
            } catch (Exception e) {
                ToastHelper.show(this, getString(R.string.toast_error, e.getMessage()));
            }
        });
        builder.setNegativeButton(R.string.cancel, null);

        if (hasPassword) {
            builder.setNeutralButton(R.string.backup_password_remove, (d, w) -> {
                BackupHelper.clearPassword(this);
                updateBackupPasswordLabel();
                ToastHelper.show(this, getString(R.string.backup_password_removed));
                if (BackupHelper.isEnabled(this)) {
                    new Thread(() -> BackupHelper.autoBackup(getApplicationContext())).start();
                }
            });
        }

        builder.show();
    }

    private void pickFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_FOLDER_REQUEST_CODE);
    }

    private void pickImportFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_IMPORT_FILE_REQUEST_CODE);
    }

    private void handleImport(byte[] data) {
        if (BackupHelper.looksEncrypted(data)) {
            askPasswordAndImport(data);
        } else {
            confirmImport(data, null);
        }
    }

    private void askPasswordAndImport(byte[] data) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        input.setHint(R.string.backup_password_hint);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);

        new AnimDialog(this)
            .setTitle(R.string.restore_enter_password)
            .setView(input)
            .setPositiveButton(R.string.ok, (d, w) -> {
                String pwd = input.getText().toString();
                confirmImport(data, pwd);
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void confirmImport(byte[] data, String password) {
        new AnimDialog(this)
            .setTitle(R.string.import_confirm_title)
            .setMessage(R.string.import_confirm_msg)
            .setPositiveButton(R.string.import_replace, (d, w) -> {
                try {
                    int count = BackupHelper.importFromBytes(this, data, password);
                    ToastHelper.show(this, getString(R.string.import_success, count));
                } catch (Exception e) {
                    showDialog(getString(R.string.import_error, e.getMessage()));
                }
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private byte[] readAllBytes(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception(getString(R.string.toast_cannot_open_file));
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }

    private void updateLanguageLabel(TextView tv) {
        String tag = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        String display;
        if (tag == null || tag.isEmpty()) display = getString(R.string.lang_system);
        else if (tag.startsWith("ru")) display = getString(R.string.lang_russian);
        else if (tag.startsWith("en")) display = getString(R.string.lang_english);
        else display = getString(R.string.lang_system);
        tv.setText(display);
    }

    private void showLanguageDialog() {
        String[] items = {
            getString(R.string.lang_system),
            getString(R.string.lang_russian),
            getString(R.string.lang_english)
        };
        String currentTag = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        int checked = 0;
        if (currentTag != null && currentTag.startsWith("ru")) checked = 1;
        else if (currentTag != null && currentTag.startsWith("en")) checked = 2;

        new AnimDialog(this)
            .setTitle(R.string.choose_language)
            .setSingleChoiceItems(items, checked, (dialog, which) -> {
                LocaleListCompat locales;
                if (which == 1) locales = LocaleListCompat.forLanguageTags("ru");
                else if (which == 2) locales = LocaleListCompat.forLanguageTags("en");
                else locales = LocaleListCompat.getEmptyLocaleList();
                AppCompatDelegate.setApplicationLocales(locales);
                dialog.dismiss();
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void backupToCloud() {
        try {
            String json = BackupHelper.buildJson(this);
            if (json.equals("[]") || json.isEmpty()) {
                showDialog(getString(R.string.no_notes_export));
                return;
            }
            File cacheDir = new File(getCacheDir(), "backup");
            if (!cacheDir.exists()) cacheDir.mkdirs();

            String password = BackupHelper.getPassword(this);
            File outFile;
            if (password != null && !password.isEmpty()) {
                byte[] enc = BackupHelper.encryptWithPassword(json.getBytes(StandardCharsets.UTF_8), password);
                outFile = new File(cacheDir, "sealednotes_backup.enc");
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(enc);
                }
            } else {
                outFile = new File(cacheDir, "sealednotes_backup.json");
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(json.getBytes(StandardCharsets.UTF_8));
                }
            }

            Uri uri = FileProvider.getUriForFile(this,
                "com.inkgame348.sealednotes.fileprovider", outFile);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/octet-stream");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.putExtra(Intent.EXTRA_SUBJECT, "Sealed Notes backup");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, getString(R.string.backup_cloud_chooser)));
            ToastHelper.show(this, getString(R.string.toast_backup_created));
        } catch (Exception e) {
            e.printStackTrace();
            showDialog(getString(R.string.toast_error, e.getMessage()));
        }
    }

    private void exportToFile() {
        try {
            exportJsonContent = BackupHelper.buildJson(this);
            if (exportJsonContent.equals("[]") || exportJsonContent.isEmpty()) {
                showDialog(getString(R.string.no_notes_export));
                return;
            }
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_TITLE, "sealednotes_backup.json");
            startActivityForResult(intent, CREATE_FILE_REQUEST_CODE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CREATE_FILE_REQUEST_CODE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                os.write(exportJsonContent.getBytes(StandardCharsets.UTF_8));
                ToastHelper.show(this, getString(R.string.export_success));
            } catch (Exception e) {
                showDialog(getString(R.string.toast_error, e.getMessage()));
            }
        }

        if (requestCode == PICK_FOLDER_REQUEST_CODE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                BackupHelper.setFolderUri(this, uri.toString());
                updateBackupFolderLabel();
                new Thread(() -> BackupHelper.autoBackup(getApplicationContext())).start();
                ToastHelper.show(this, getString(R.string.toast_folder_selected));
            } catch (Exception e) {
                showDialog(getString(R.string.toast_error, e.getMessage()));
            }
        }

        if (requestCode == PICK_IMPORT_FILE_REQUEST_CODE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                byte[] bytes = readAllBytes(uri);
                handleImport(bytes);
            } catch (Exception e) {
                showDialog(getString(R.string.import_error, e.getMessage()));
            }
        }
    }

    private void showDialog(String message) {
        new AnimDialog(this)
            .setMessage(message)
            .setPositiveButton(R.string.ok, null)
            .show();
    }

    private void showAbout() {
        String ver = "?";
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception ignored) {}
        new AnimDialog(this)
            .setTitle("Sealed Notes v" + ver)
            .setMessage(R.string.about_message)
            .setPositiveButton(R.string.ok, null)
            .show();
    }
}