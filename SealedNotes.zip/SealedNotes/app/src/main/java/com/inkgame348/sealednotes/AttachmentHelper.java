package com.inkgame348.sealednotes;

import android.content.Context;
import android.net.Uri;
import java.io.*;

public class AttachmentHelper {

    public static String copyToPrivate(Context ctx, Uri source, String noteId) {
        try {
            String displayName = "file_" + System.currentTimeMillis();
            try (android.database.Cursor c = ctx.getContentResolver().query(
                    source, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) {
                        String n = c.getString(idx);
                        if (n != null && !n.isEmpty()) displayName = n;
                    }
                }
            }
            File dir = new File(ctx.getFilesDir(), "attachments/" + noteId);
            if (!dir.exists()) dir.mkdirs();
            File dest = new File(dir, displayName);
            int suffix = 1;
            String baseName = displayName, ext = "";
            int dot = displayName.lastIndexOf('.');
            if (dot > 0) {
                baseName = displayName.substring(0, dot);
                ext = displayName.substring(dot);
            }
            while (dest.exists()) dest = new File(dir, baseName + "_" + (suffix++) + ext);

            try (InputStream in = ctx.getContentResolver().openInputStream(source);
                 FileOutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[8192]; int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            }
            return dest.getName();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static File getAttachment(Context ctx, String noteId, String name) {
        return new File(ctx.getFilesDir(), "attachments/" + noteId + "/" + name);
    }

    public static void deleteAllForNote(Context ctx, String noteId) {
        File dir = new File(ctx.getFilesDir(), "attachments/" + noteId);
        if (dir.exists()) {
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) f.delete();
            dir.delete();
        }
    }
}