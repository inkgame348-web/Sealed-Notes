package com.inkgame348.sealednotes;

import android.content.Context;
import android.net.Uri;

import java.io.*;

public class AttachmentHelper {

    public interface CopyCallback {
        void onResult(String fileName);
    }

    public static void copyToPrivateAsync(Context ctx, Uri source, String noteId, CopyCallback cb) {
        if (ctx == null || source == null || noteId == null) {
            if (cb != null) cb.onResult(null);
            return;
        }
        final Context appCtx = ctx.getApplicationContext();
        AppExecutors.get().diskIO().execute(() -> {
            String result = copyToPrivateInternal(appCtx, source, noteId);
            if (cb != null) {
                AppExecutors.get().runOnMain(() -> cb.onResult(result));
            }
        });
    }

    private static String copyToPrivateInternal(Context ctx, Uri source, String noteId) {
        InputStream in = null;
        FileOutputStream out = null;
        File tempFile = null;
        try {
            String displayName = "file_" + System.currentTimeMillis();
            try (android.database.Cursor c = ctx.getContentResolver().query(
                    source, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if (idx >= 0) {
                        String n = c.getString(idx);
                        if (n != null && !n.isEmpty()) displayName = sanitizeFileName(n);
                    }
                }
            }

            File dir = new File(ctx.getFilesDir(), "attachments/" + noteId);
            // ★ ФИКС: если путь — файл (а не папка), возвращаем null ★
            if (dir.exists() && !dir.isDirectory()) return null;
            if (!dir.exists() && !dir.mkdirs()) return null;

            File dest = new File(dir, displayName);
            int suffix = 1;
            String baseName = displayName, ext = "";
            int dot = displayName.lastIndexOf('.');
            if (dot > 0) {
                baseName = displayName.substring(0, dot);
                ext = displayName.substring(dot);
            }
            while (dest.exists()) dest = new File(dir, baseName + "_" + (suffix++) + ext);

            tempFile = new File(dir, ".tmp_" + System.currentTimeMillis());
            in = ctx.getContentResolver().openInputStream(source);
            if (in == null) return null;

            out = new FileOutputStream(tempFile);
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            out.flush();
            out.getFD().sync();
            out.close();
            out = null;
            in.close();
            in = null;

            if (!tempFile.renameTo(dest)) {
                tempFile.delete();
                return null;
            }
            return dest.getName();
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            if (tempFile != null && tempFile.exists()) tempFile.delete();
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            try { if (out != null) out.close(); } catch (Exception ignored) {}
        }
    }

    /** Санитизация имени для сохранения на диск. */
    private static String sanitizeFileName(String name) {
        if (name == null) return "file";
        StringBuilder sb = new StringBuilder(name.length());
        for (char c : name.toCharArray()) {
            if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' ||
                c == '"' || c == '<' || c == '>' || c == '|' || c == 0) {
                sb.append('_');
            } else {
                sb.append(c);
            }
        }
        String s = sb.toString().trim();
        if (s.isEmpty()) return "file";
        if (s.length() <= 200) return s;

        int dot = s.lastIndexOf('.');
        if (dot > 0 && s.length() - dot <= 20) {
            String ext = s.substring(dot);
            int keep = 200 - ext.length();
            if (keep < 1) keep = 1;
            return s.substring(0, keep) + ext;
        }
        return s.substring(0, 200);
    }

    public static File getAttachment(Context ctx, String noteId, String name) {
        if (ctx == null || noteId == null || name == null) return null;
        return new File(ctx.getFilesDir(), "attachments/" + noteId + "/" + name);
    }

    /**
     * ★ ФИКС: удаляем папку и все .tmp/.tmp_ файлы в ней.
     * Плюс — если папки нет, ничего не делаем.
     */
    public static void deleteAllForNote(Context ctx, String noteId) {
        if (ctx == null || noteId == null) return;
        File dir = new File(ctx.getFilesDir(), "attachments/" + noteId);
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.isDirectory()) {
                        File[] inner = f.listFiles();
                        if (inner != null) for (File g : inner) g.delete();
                    }
                    f.delete();
                }
            }
            dir.delete();
        }
    }
}