package com.inkgame348.sealednotes;

import android.content.Context;
import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Журнал отмены. Хранит до 500 последних структурных действий.
 * Шифруется DK. Файл journal.enc во внутренней памяти.
 *
 * Hard-delete не удаляет notes/<id>.enc сразу, а переносит в journal/<id>.enc.
 * Если запись выпадает из стека — файл удаляется окончательно.
 */
public class UndoJournal {

    public static final int MAX_ENTRIES = 500;

    private final Context context;
    private final File journalFile;
    private final Object lock = new Object();

    public UndoJournal(Context ctx) {
        this.context = ctx.getApplicationContext();
        this.journalFile = new File(context.getFilesDir(), "journal.enc");
    }

    // ============ Load / Save ============

    public List<UndoEntry> load() {
        synchronized (lock) {
            List<UndoEntry> entries = new ArrayList<>();
            try {
                if (!journalFile.exists() || journalFile.length() == 0) {
                    return entries;
                }
                byte[] data = readAll(journalFile);
                byte[] dk = MasterKeyManager.getDataKey(context);
                byte[] plain;
                if (MasterKeyManager.hasMagicHeader(data)) {
                    plain = MasterKeyManager.unpackWithHeader(dk, data);
                } else {
                    plain = MasterKeyManager.aesDecryptStatic(dk, data);
                }
                JSONArray arr = new JSONArray(new String(plain, StandardCharsets.UTF_8));
                for (int i = 0; i < arr.length(); i++) {
                    entries.add(UndoEntry.fromJson(arr.getJSONObject(i)));
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
            return entries;
        }
    }

    public void save(List<UndoEntry> entries) {
        synchronized (lock) {
            try {
                JSONArray arr = new JSONArray();
                for (UndoEntry e : entries) arr.put(e.toJson());
                byte[] dk = MasterKeyManager.getDataKey(context);
                byte[] enc = MasterKeyManager.packWithHeader(dk,
                    arr.toString().getBytes(StandardCharsets.UTF_8));

                File parent = journalFile.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                File tmp = new File(parent, ".journal.tmp");

                try (FileOutputStream out = new FileOutputStream(tmp)) {
                    out.write(enc);
                    out.getFD().sync();
                }
                if (!tmp.renameTo(journalFile)) {
                    tmp.delete();
                    throw new IOException("journal rename failed");
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG) e.printStackTrace();
            }
        }
    }

    // ============ Stack API ============

    public void push(UndoEntry entry) {
        synchronized (lock) {
            List<UndoEntry> entries = load();
            entries.add(entry);
            while (entries.size() > MAX_ENTRIES) {
                UndoEntry removed = entries.remove(0);
                if (UndoEntry.TYPE_HARD_DELETE.equals(removed.type)
                    && removed.noteId != null) {
                    NoteStorage.deleteJournalFile(context, removed.noteId);
                }
            }
            save(entries);
        }
    }

    public UndoEntry peek() {
        synchronized (lock) {
            List<UndoEntry> entries = load();
            if (entries.isEmpty()) return null;
            return entries.get(entries.size() - 1);
        }
    }

    public UndoEntry pop() {
        synchronized (lock) {
            List<UndoEntry> entries = load();
            if (entries.isEmpty()) return null;
            UndoEntry last = entries.remove(entries.size() - 1);
            save(entries);
            return last;
        }
    }

    public boolean canUndo() {
        synchronized (lock) {
            List<UndoEntry> entries = load();
            return !entries.isEmpty();
        }
    }

    public void clear() {
        synchronized (lock) {
            journalFile.delete();
            NoteStorage.clearJournalDir(context);
        }
    }

    // ============ Helpers ============

    private static byte[] readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }
}