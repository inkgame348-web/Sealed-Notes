package com.inkgame348.sealednotes;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class SealedNotesApp extends Application implements Application.ActivityLifecycleCallbacks {

    private int startedCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        // ★ ФИКС: инициализировать DK при старте, иначе getDataKey() падает ★
        try {
            MasterKeyManager.initializeIfNeeded(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        registerActivityLifecycleCallbacks(this);
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        startedCount++;
        if (startedCount == 1) {
            if (MasterKeyManager.isUnlocked()
                && MasterKeyManager.isAutoLockExpired(this)) {
                MasterKeyManager.lock();
            }
            if (MasterKeyManager.isUnlocked()) {
                MasterKeyManager.markActive(this);
            }
        }
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        startedCount--;
        if (startedCount == 0) {
            if (MasterKeyManager.isUnlocked()) {
                MasterKeyManager.markActive(this);
            }
        }
    }

    @Override public void onActivityCreated(@NonNull Activity a, @Nullable Bundle b) {}
    @Override public void onActivityResumed(@NonNull Activity a) {}
    @Override public void onActivityPaused(@NonNull Activity a) {}
    @Override public void onActivitySaveInstanceState(@NonNull Activity a, @NonNull Bundle b) {}
    @Override public void onActivityDestroyed(@NonNull Activity a) {}
}