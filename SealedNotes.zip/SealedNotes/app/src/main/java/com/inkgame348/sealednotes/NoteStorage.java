package com.inkgame348.sealednotes;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class NoteStorage {
    private final File file;
    private final Context context;

    public NoteStorage(Context context) {
        this.context = context.getApplicationContext();
        file = new File(context.getFilesDir(), "notes.enc");
    }

    public List<Note> load() {
        List<Note> notes = new ArrayList<>();
        if (!file.exists()) return notes;
        try {
            byte[] data = readAll(file);
            if (data.length == 0) return notes;
            byte[] plain = KeyStoreHelper.decrypt(data);
            JSONArray arr = new JSONArray(new String(plain, StandardCharsets.UTF_8));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Note n = new Note();
                n.id = o.optString("id", "");
                n.title = o.optString("title", "");
                n.content = o.optString("content", "");
                n.timestamp = o.optLong("timestamp", 0);
                n.pinned = o.optBoolean("pinned", false);
                n.deleted = o.optBoolean("deleted", false);
                n.deletedAt = o.optLong("deletedAt", 0);
                JSONArray atts = o.optJSONArray("attachments");
                if (atts != null) for (int j = 0; j < atts.length(); j++)
                    n.attachments.add(atts.getString(j));
                notes.add(n);
            }
        } catch (Exception e) { e.printStackTrace(); }
        sortPinnedFirst(notes);
        return notes;
    }

    public void save(List<Note> notes) {
        try {
            sortPinnedFirst(notes);
            JSONArray arr = new JSONArray();
            for (Note n : notes) {
                JSONObject o = new JSONObject();
                o.put("id", n.id);
                o.put("title", n.title);
                o.put("content", n.content);
                o.put("timestamp", n.timestamp);
                o.put("pinned", n.pinned);
                o.put("deleted", n.deleted);
                o.put("deletedAt", n.deletedAt);
                JSONArray atts = new JSONArray();
                for (String s : n.attachments) atts.put(s);
                o.put("attachments", atts);
                arr.put(o);
            }
            byte[] enc = KeyStoreHelper.encrypt(arr.toString().getBytes(StandardCharsets.UTF_8));
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(enc); }

            new Thread(() -> BackupHelper.autoBackup(context)).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sortPinnedFirst(List<Note> notes) {
        notes.sort(new Comparator<Note>() {
            public int compare(Note a, Note b) {
                if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
                return Long.compare(b.timestamp, a.timestamp);
            }
        });
    }

    /** Удаляет заметки из корзины, которые лежат там больше 30 дней. */
    public static void cleanupOldTrash(Context ctx) {
        try {
            NoteStorage storage = new NoteStorage(ctx);
            List<Note> all = storage.load();
            long threshold = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000;
            List<Note> toRemove = new ArrayList<>();
            for (Note n : all) {
                if (n.deleted && n.deletedAt > 0 && n.deletedAt < threshold) {
                    toRemove.add(n);
                }
            }
            if (toRemove.isEmpty()) return;
            for (Note n : toRemove) {
                AttachmentHelper.deleteAllForNote(ctx, n.id);
            }
            all.removeAll(toRemove);
            storage.save(all);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static byte[] readAll(File f) throws Exception {
        try (InputStream in = new FileInputStream(f);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int r;
            while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
            return out.toByteArray();
        }
    }
}