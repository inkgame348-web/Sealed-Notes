# ============ Material Components ============
-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

# ============ AndroidX Biometric ============
-keep class androidx.biometric.** { *; }
-dontwarn androidx.biometric.**

# ============ AppCompat locales ============
-keep class androidx.appcompat.app.AppCompatDelegate { *; }
-keep class androidx.core.os.LocaleListCompat { *; }
-dontwarn androidx.appcompat.**

# ============ Убираем логи из release ============
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}