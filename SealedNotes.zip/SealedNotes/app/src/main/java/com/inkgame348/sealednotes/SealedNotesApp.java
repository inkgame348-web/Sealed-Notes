package com.inkgame348.sealednotes;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class SealedNotesApp extends Application implements Application.ActivityLifecycleCallbacks {

    private static final long AUTOLOCK_CHECK_INTERVAL_MS = 30_000;

    private int startedCount = 0;
    private final Handler autolockHandler = new Handler(Looper.getMainLooper());

    private final Runnable autolockCheck = new Runnable() {
        @Override
        public void run() {
            if (startedCount > 0
                && MasterKeyManager.isUnlocked()
                && MasterKeyManager.isAutoLockExpired(SealedNotesApp.this)) {

                MasterKeyManager.lock();

                Intent i = new Intent(SealedNotesApp.this, UnlockActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
            if (startedCount > 0) {
                autolockHandler.postDelayed(this, AUTOLOCK_CHECK_INTERVAL_MS);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            MasterKeyManager.initializeIfNeeded(this);
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }

        // ★ Планируем автобэкап, если он включён
        if (BackupConfig.isEnabled(this)) {
            BackupScheduler.schedule(this);
        }

        registerActivityLifecycleCallbacks(this);
    }

    @Override
    public void onActivityStarted(@NonNull Activity activity) {
        startedCount++;
        if (startedCount == 1) {
            autolockHandler.removeCallbacks(autolockCheck);
            autolockHandler.postDelayed(autolockCheck, AUTOLOCK_CHECK_INTERVAL_MS);

            if (MasterKeyManager.isUnlocked()
                && MasterKeyManager.isAutoLockExpired(this)) {
                MasterKeyManager.lock();
            }
        }
    }

    @Override
    public void onActivityStopped(@NonNull Activity activity) {
        startedCount--;
        if (startedCount == 0) {
            autolockHandler.removeCallbacks(autolockCheck);
            if (MasterKeyManager.isUnlocked()) {
                MasterKeyManager.markActive(this);
            }
        }
    }

    @Override public void onActivityCreated(@NonNull Activity a, @Nullable Bundle b) {}
    @Override public void onActivityResumed(@NonNull Activity a) {}
    @Override public void onActivityPaused(@NonNull Activity a) {}
    @Override public void onActivitySaveInstanceState(@NonNull Activity a, @NonNull Bundle b) {}
    @Override public void onActivityDestroyed(@NonNull Activity a) {}
}