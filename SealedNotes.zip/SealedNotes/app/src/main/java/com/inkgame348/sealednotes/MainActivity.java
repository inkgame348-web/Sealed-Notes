package com.inkgame348.sealednotes;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private TextView emptyText;
    private NoteAdapter adapter;
    private final List<Note> notes = new ArrayList<>();
    private NoteStorage storage;
    private FloatingActionButton fab;
    private ImageButton selectBtn;
    private boolean selectionMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        applySavedTheme();
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_main);
        storage = new NoteStorage(this);

        recycler = findViewById(R.id.recycler);
        emptyText = findViewById(R.id.empty_text);
        fab = findViewById(R.id.fab);
        selectBtn = findViewById(R.id.btn_select);
        ImageButton settingsBtn = findViewById(R.id.btn_settings);
        FrameLayout trashBtn = findViewById(R.id.btn_trash);
        ImageView trashLid = findViewById(R.id.trash_lid);

        new Thread(() -> NoteStorage.cleanupOldTrash(getApplicationContext())).start();

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(notes, new NoteAdapter.Listener() {
            @Override public void onClick(Note note) { openEditor(note); }
            @Override public void onLongClick(Note note) { showNoteDialog(note); }
            @Override public void onSelectionChanged() { updateFabIcon(); }
        });
        recycler.setAdapter(adapter);

        ItemTouchHelper.SimpleCallback swipe =
            new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override public boolean onMove(@NonNull RecyclerView rv,
                                            @NonNull RecyclerView.ViewHolder vh,
                                            @NonNull RecyclerView.ViewHolder t) { return false; }
            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int dir) {
                int pos = vh.getAdapterPosition();
                if (pos >= 0 && pos < notes.size() && !selectionMode) {
                    Note note = notes.get(pos);
                    adapter.notifyItemChanged(pos);
                    recycler.postDelayed(() -> showNoteDialog(note), 50);
                } else {
                    adapter.notifyItemChanged(pos);
                }
            }
        };
        new ItemTouchHelper(swipe).attachToRecyclerView(recycler);

        fab.setScaleX(0f);
        fab.setScaleY(0f);
        fab.animate().scaleX(1f).scaleY(1f)
            .setDuration(400)
            .setInterpolator(new OvershootInterpolator())
            .start();

        fab.setOnClickListener(v -> {
            animateFabClick(v);
            if (selectionMode) {
                v.postDelayed(this::confirmDeleteSelected, 80);
            } else {
                v.postDelayed(() -> openEditor(null), 80);
            }
        });

        // Двойная галочка — быстрый Slide + Fade (~140мс)
        selectBtn.setOnClickListener(v -> {
            v.animate()
                .alpha(0f)
                .translationX(-16f)
                .setDuration(60)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    toggleSelectionMode();
                    v.setTranslationX(16f);
                    v.animate()
                        .alpha(1f)
                        .translationX(0f)
                        .setDuration(80)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();
                })
                .start();
        });

        trashBtn.setOnClickListener(v -> {
            trashLid.setPivotX(4f);
            trashLid.setPivotY(6f);
            trashLid.animate()
                .rotation(-32f)
                .translationY(-3f)
                .setDuration(220)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> trashLid.animate()
                    .rotation(0f)
                    .translationY(0f)
                    .setDuration(340)
                    .setInterpolator(new OvershootInterpolator())
                    .withEndAction(() -> {
                        trashLid.setRotation(0f);
                        trashLid.setTranslationY(0f);
                        startActivity(new Intent(MainActivity.this, TrashActivity.class));
                        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
                    })
                    .start())
                .start();
        });

        settingsBtn.setOnClickListener(v -> {
            v.animate()
                .rotationBy(360f)
                .setDuration(400)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> {
                    v.setRotation(0f);
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
                })
                .start();
        });

        updateEmptyState();
    }

    private void animateFabClick(View v) {
        v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(80)
            .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                .setDuration(180)
                .setInterpolator(new OvershootInterpolator())
                .start())
            .start();
    }

    private void applySavedTheme() {
        int theme = SettingsStorage.getTheme(this);
        if (theme == SettingsStorage.THEME_LIGHT)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        else if (theme == SettingsStorage.THEME_DARK)
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        else
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
    }

    private void toggleSelectionMode() {
        selectionMode = !selectionMode;
        adapter.setSelectionMode(selectionMode);
        for (Note n : notes) n.selected = false;
        // FAB — быстрый Slide + Fade (~130мс)
        fab.animate()
            .alpha(0f)
            .translationY(-24f)
            .setDuration(60)
            .setInterpolator(new DecelerateInterpolator())
            .withEndAction(() -> {
                updateFabIcon();
                fab.setTranslationY(24f);
                fab.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(80)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
            })
            .start();
    }

    private void updateFabIcon() {
        if (selectionMode) fab.setImageResource(R.drawable.ic_delete);
        else fab.setImageResource(R.drawable.ic_plus);
    }

    private void confirmDeleteSelected() {
        int count = 0;
        for (Note n : notes) if (n.selected) count++;
        if (count == 0) {
            ToastHelper.show(this, getString(R.string.select));
            return;
        }
        final int finalCount = count;
        new AnimDialog(this)
            .setTitle(R.string.delete_confirm_title)
            .setMessage(getString(R.string.delete_confirm_msg, finalCount))
            .setPositiveButton(R.string.delete, (d, w) -> {
                long now = System.currentTimeMillis();
                for (Note n : notes) {
                    if (n.selected) {
                        n.deleted = true;
                        n.deletedAt = now;
                        n.pinned = false;
                        n.selected = false;
                    }
                }
                storage.save(notes);
                selectionMode = false;
                adapter.setSelectionMode(false);
                loadNotes();
                updateFabIcon();
                ToastHelper.show(MainActivity.this,
                    getString(R.string.toast_moved_to_trash_count, finalCount));
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void showNoteDialog(Note note) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_note_actions);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.85f),
                LinearLayout.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().getAttributes().windowAnimations = R.style.CustomDialogTheme;
        }

        TextView title = dialog.findViewById(R.id.dialog_title);
        title.setText(note.title.isEmpty() ? getString(R.string.untitled) : note.title);

        TextView pinLabel = dialog.findViewById(R.id.btn_pin_label);
        pinLabel.setText(note.pinned ? R.string.dialog_unpin : R.string.dialog_pin);

        LinearLayout pinBtn = dialog.findViewById(R.id.btn_pin);
        swapPinIcon(pinBtn, note.pinned);

        pinBtn.setOnClickListener(v -> {
            dialog.dismiss();
            togglePin(note);
        });
        dialog.findViewById(R.id.btn_delete).setOnClickListener(v -> {
            dialog.dismiss();
            confirmDelete(note);
        });

        dialog.show();
    }

    private void swapPinIcon(LinearLayout container, boolean pinned) {
        int resId = pinned ? R.drawable.ic_pin_off : R.drawable.ic_pin;
        for (int i = 0; i < container.getChildCount(); i++) {
            View child = container.getChildAt(i);
            if (child instanceof ImageView) {
                ((ImageView) child).setImageResource(resId);
                ((ImageView) child).setAlpha(pinned ? 0.85f : 1.0f);
            }
        }
    }

    private void confirmDelete(Note note) {
        new AnimDialog(this)
            .setTitle(R.string.delete_one_title)
            .setMessage(R.string.delete_one_msg)
            .setPositiveButton(R.string.delete, (d, w) -> {
                List<Note> all = storage.load();
                for (Note n : all) {
                    if (n.id.equals(note.id)) {
                        n.deleted = true;
                        n.deletedAt = System.currentTimeMillis();
                        n.pinned = false;
                        break;
                    }
                }
                storage.save(all);
                loadNotes();
                ToastHelper.show(MainActivity.this, getString(R.string.toast_moved_to_trash));
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void togglePin(Note note) {
        note.pinned = !note.pinned;
        storage.save(notes);
        loadNotes();
        ToastHelper.show(this, note.pinned
            ? getString(R.string.toast_pinned)
            : getString(R.string.toast_unpinned));
    }

    private void loadNotes() {
        notes.clear();
        for (Note n : storage.load()) {
            if (!n.deleted) notes.add(n);
        }
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
    }

    private void openEditor(Note note) {
        Intent i = new Intent(this, EditNoteActivity.class);
        if (note != null) i.putExtra("note_id", note.id);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_right, android.R.anim.fade_out);
    }

    private void updateEmptyState() {
        emptyText.setText("");
        emptyText.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onBackPressed() {
        if (selectionMode) toggleSelectionMode();
        else super.onBackPressed();
    }
}