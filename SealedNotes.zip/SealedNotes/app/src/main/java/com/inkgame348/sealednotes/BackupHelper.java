package com.inkgame348.sealednotes;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class BackupHelper {

    private static final int PBKDF2_ITERATIONS = 600_000;
    private static final int SALT_LEN = 16;
    private static final int IV_LEN = 12;
    private static final int GCM_TAG_BITS = 128;

    private static final byte[] BACKUP_MAGIC = {'S', 'N', 'B', 'B', '1'};
    private static final byte BACKUP_VERSION = 1;

    // ==================== Build JSON ====================

    public static String buildJson(Context ctx) throws Exception {
        NoteStorage storage = new NoteStorage(ctx);
        List<Note> index = storage.load();
        if (index == null) throw new Exception("Не удалось расшифровать заметки");

        JSONArray arr = new JSONArray();
        for (Note summary : index) {
            Note full = storage.loadFull(summary.id);
            if (full == null) continue;
            JSONObject o = new JSONObject();
            o.put("id", full.id);
            o.put("title", full.title);
            o.put("content", full.content);
            o.put("timestamp", full.timestamp);
            o.put("pinned", full.pinned);
            o.put("deleted", full.deleted);
            o.put("deletedAt", full.deletedAt);
            JSONArray atts = new JSONArray();
            for (String s : full.attachments) atts.put(s);
            o.put("attachments", atts);
            arr.put(o);
        }
        return arr.toString(2);
    }

    // ==================== Import ====================

    public static int importFromBytes(Context ctx, byte[] data, String password, boolean merge) throws Exception {
        String json;
        String asText = new String(data, StandardCharsets.UTF_8);

        if (startsWithBackupMagic(data)) {
            if (password == null || password.isEmpty())
                throw new Exception("Файл зашифрован. Введите пароль.");
            byte[] plain = decryptWithPassword(data, password);
            json = new String(plain, StandardCharsets.UTF_8);
        } else if (asText.trim().startsWith("[")) {
            json = asText;
        } else if (looksEncrypted(data)) {
            if (password == null || password.isEmpty())
                throw new Exception("Файл зашифрован. Введите пароль.");
            byte[] plain = decryptWithPassword(data, password);
            json = new String(plain, StandardCharsets.UTF_8);
        } else {
            throw new Exception("Неизвестный формат файла");
        }

        JSONArray arr = new JSONArray(json);
        // ★ ФИКС: дедупликация по id через Map — при merge два Note с одним id не перезапишут файл ★
        Map<String, Note> importedMap = new HashMap<>();
        List<Note> importedOrder = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            Note n = new Note();
            n.id = o.optString("id", "");
            if (n.id.isEmpty()) n.id = java.util.UUID.randomUUID().toString();
            n.title = o.optString("title", "");
            n.content = o.optString("content", "");
            n.timestamp = o.optLong("timestamp", 0);
            n.pinned = o.optBoolean("pinned", false);
            n.deleted = o.optBoolean("deleted", false);
            n.deletedAt = o.optLong("deletedAt", 0);
            JSONArray atts = o.optJSONArray("attachments");
            if (atts != null) for (int j = 0; j < atts.length(); j++)
                n.attachments.add(atts.getString(j));
            n.contentLoaded = true;
            if (!importedMap.containsKey(n.id)) importedOrder.add(n);
            importedMap.put(n.id, n);  // последний с этим id выигрывает
        }
        List<Note> imported = new ArrayList<>();
        for (Note n : importedOrder) imported.add(importedMap.get(n.id));

        NoteStorage storage = new NoteStorage(ctx);

        if (merge) {
            List<Note> existing = storage.load();
            if (existing == null) throw new Exception("Не удалось прочитать базу");
            Map<String, Note> byId = new HashMap<>();
            for (Note n : existing) byId.put(n.id, n);
            int merged = 0;
            for (Note imp : imported) {
                Note ex = byId.get(imp.id);
                if (ex == null) {
                    existing.add(imp);
                    merged++;
                } else if (imp.timestamp > ex.timestamp) {
                    ex.title = imp.title;
                    ex.content = imp.content;
                    ex.timestamp = imp.timestamp;
                    ex.pinned = imp.pinned;
                    ex.deleted = imp.deleted;
                    ex.deletedAt = imp.deletedAt;
                    ex.attachments = imp.attachments;
                    ex.contentLoaded = true;
                    merged++;
                }
            }
            storage.save(existing);
            return merged;
        } else {
            storage.save(imported);
            return imported.size();
        }
    }

    public static boolean looksEncrypted(byte[] data) {
        if (data == null || data.length < 4) return false;
        String head = new String(data, 0, Math.min(200, data.length), StandardCharsets.UTF_8);
        return !head.trim().startsWith("[");
    }

    private static boolean startsWithBackupMagic(byte[] data) {
        if (data == null || data.length < BACKUP_MAGIC.length + 1) return false;
        for (int i = 0; i < BACKUP_MAGIC.length; i++) {
            if (data[i] != BACKUP_MAGIC[i]) return false;
        }
        return true;
    }

    // ==================== Crypto ====================

    public static byte[] encryptWithPassword(byte[] plaintext, String password) throws Exception {
        byte[] salt = new byte[SALT_LEN];
        byte[] iv = new byte[IV_LEN];
        new SecureRandom().nextBytes(salt);
        new SecureRandom().nextBytes(iv);

        SecretKey key = deriveKey(password, salt);

        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        byte[] ct = c.doFinal(plaintext);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(BACKUP_MAGIC);
        out.write(BACKUP_VERSION);
        out.write(salt);
        out.write(iv);
        out.write(ct);
        return out.toByteArray();
    }

    public static byte[] decryptWithPassword(byte[] data, String password) throws Exception {
        int headerLen = BACKUP_MAGIC.length + 1;
        if (data.length < headerLen + SALT_LEN + IV_LEN + 16)
            throw new Exception("Файл слишком короткий");

        int offset = startsWithBackupMagic(data) ? headerLen : 0;

        byte[] salt = new byte[SALT_LEN];
        byte[] iv = new byte[IV_LEN];
        byte[] ct = new byte[data.length - offset - SALT_LEN - IV_LEN];

        System.arraycopy(data, offset, salt, 0, SALT_LEN);
        System.arraycopy(data, offset + SALT_LEN, iv, 0, IV_LEN);
        System.arraycopy(data, offset + SALT_LEN + IV_LEN, ct, 0, ct.length);

        SecretKey key = deriveKey(password, salt);

        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(GCM_TAG_BITS, iv));
        return c.doFinal(ct);
    }

    private static SecretKey deriveKey(String password, byte[] salt) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, PBKDF2_ITERATIONS, 256);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), "AES");
    }
}