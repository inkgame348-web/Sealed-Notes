package com.inkgame348.sealednotes;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import java.util.concurrent.Executor;

import javax.crypto.AEADBadTagException;

public class UnlockActivity extends AppCompatActivity {

    private EditText passwordField;
    private Button unlockBtn;
    private Button biometricBtn;
    private TextView hint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        if (!MasterKeyManager.isLocked(this)) {
            goToMain();
            return;
        }

        boolean hasPwd = MasterKeyManager.hasPassword(this);
        boolean hasBio = MasterKeyManager.hasBiometric(this);
        boolean bioHealthy = MasterKeyManager.isBiometricHealthy(this);

        // ★ enrolled проверяет ТОЛЬКО NONE_ENROLLED. HW_UNAVAILABLE и
        // LOCKOUT — временные состояния. Биометрия остаётся рабочей,
        // просто система просит подождать. Пускаем пользователя к
        // BiometricPrompt, он сам покажет "заблокировано, попробуйте позже".
        boolean enrolled = hasBio && hasEnrolledBiometric();

        // Биометрия заявлена, но отпечатки удалены из системы
        // (или флаг «сломана» уже стоит с прошлого раза).
        if (hasBio && (!enrolled || !bioHealthy)) {
            MasterKeyManager.markBiometricBroken(this);

            // Пароль есть — показываем экран пароля, биометрию прячем.
            if (hasPwd) {
                showPasswordOnlyScreen();
                return;
            }

            // Пароля нет — просто пускаем. Fallback DK откроет данные.
            goToMain();
            return;
        }

        // Обычный флоу — биометрия в порядке (или её нет вообще).
        setContentView(R.layout.activity_unlock);
        passwordField = findViewById(R.id.unlock_password);
        unlockBtn = findViewById(R.id.unlock_button);
        biometricBtn = findViewById(R.id.unlock_biometric);
        hint = findViewById(R.id.unlock_hint);

        if (hasPwd) {
            passwordField.setVisibility(View.VISIBLE);
            unlockBtn.setVisibility(View.VISIBLE);
            hint.setText(R.string.unlock_hint_password);
        } else {
            passwordField.setVisibility(View.GONE);
            unlockBtn.setVisibility(View.GONE);
            hint.setText(R.string.unlock_hint_biometric);
        }

        // ★ ФИКС LOCKOUT: показываем кнопку, если отпечатки физически
        // настроены. Временный LOCKOUT/HW_UNAVAILABLE не скрывает кнопку —
        // иначе пользователь без пароля оставался на пустом экране
        // без единой кнопки на 30 секунд.
        if (hasBio && hasEnrolledBiometric()) {
            biometricBtn.setVisibility(View.VISIBLE);
        } else {
            biometricBtn.setVisibility(View.GONE);
        }

        passwordField.setOnEditorActionListener((v, actionId, event) -> {
            doUnlockWithPassword();
            return true;
        });

        unlockBtn.setOnClickListener(v -> doUnlockWithPassword());
        biometricBtn.setOnClickListener(v -> promptBiometric());

        if (!hasPwd && hasBio) {
            promptBiometric();
        }
    }

    /**
     * Показывает экран с одним полем пароля. Используется, когда
     * биометрия сломана, но мастер-пароль сохранён как резерв.
     */
    private void showPasswordOnlyScreen() {
        setContentView(R.layout.activity_unlock);
        passwordField = findViewById(R.id.unlock_password);
        unlockBtn = findViewById(R.id.unlock_button);
        biometricBtn = findViewById(R.id.unlock_biometric);
        hint = findViewById(R.id.unlock_hint);

        passwordField.setVisibility(View.VISIBLE);
        unlockBtn.setVisibility(View.VISIBLE);
        biometricBtn.setVisibility(View.GONE);
        hint.setText(R.string.unlock_hint_password);

        passwordField.setOnEditorActionListener((v, actionId, event) -> {
            doUnlockWithPassword();
            return true;
        });
        unlockBtn.setOnClickListener(v -> doUnlockWithPassword());
    }

    private void doUnlockWithPassword() {
        final String pwd = passwordField.getText().toString();
        if (pwd.isEmpty()) return;

        unlockBtn.setEnabled(false);
        passwordField.setEnabled(false);

        AppExecutors.get().crypto().execute(() -> {
            final boolean ok = MasterKeyManager.unlockWithPassword(
                UnlockActivity.this, pwd);
            AppExecutors.get().runOnMain(() -> {
                if (isFinishing() || isDestroyed()) return;
                unlockBtn.setEnabled(true);
                passwordField.setEnabled(true);
                if (ok) {
                    goToMain();
                } else {
                    ToastHelper.show(UnlockActivity.this,
                        getString(R.string.unlock_wrong_password));
                    passwordField.setText("");
                }
            });
        });
    }

    /**
     * Возвращает true, если биометрия физически настроена в системе.
     *
     * Только BIOMETRIC_ERROR_NONE_ENROLLED означает, что пользователь
     * удалил все отпечатки. HW_UNAVAILABLE, LOCKOUT, LOCKOUT_PERMANENT —
     * временные состояния. Биометрия остаётся рабочей, просто система
     * просит подождать. Пускаем пользователя к BiometricPrompt.
     */
    private boolean hasEnrolledBiometric() {
        try {
            BiometricManager bm = BiometricManager.from(this);
            int can = bm.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
            return can != BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED;
        } catch (Exception e) {
            return false;
        }
    }

    private void promptBiometric() {
        // Не блокируем по canAuthenticate — если временный LOCKOUT,
        // пусть система сама покажет «заблокировано, попробуйте позже».
        // Прерываем только если отпечатки вообще не зарегистрированы.
        if (!hasEnrolledBiometric()) {
            ToastHelper.show(this, getString(R.string.error_biometric_unavailable));
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(
                    @NonNull BiometricPrompt.AuthenticationResult result) {
                    try {
                        byte[] wrapped = MasterKeyManager.getBiometricWrapped(UnlockActivity.this);
                        if (wrapped == null) {
                            ToastHelper.show(UnlockActivity.this,
                                getString(R.string.error_keystore));
                            return;
                        }
                        byte[] dk = KeyStoreHelper.decryptDevice(wrapped);
                        MasterKeyManager.setBiometricUnlocked(dk);
                        MasterKeyManager.markBiometricHealthy(UnlockActivity.this);
                        goToMain();
                    } catch (KeyPermanentlyInvalidatedException e) {
                        onBiometricBroken();
                    } catch (AEADBadTagException e) {
                        // Ключ был пересоздан (пользователь добавил новый
                        // отпечаток, не снимая старых), поэтому wrapped
                        // не расшифровывается. Трактуем как инвалидацию.
                        onBiometricBroken();
                    } catch (Exception e) {
                        ToastHelper.show(UnlockActivity.this,
                            getString(R.string.toast_error, safeMsg(e)));
                    }
                }

                @Override
                public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                    // LOCKOUT, HW_UNAVAILABLE и прочие временные ошибки
                    // попадают сюда — просто обновляем hint, флаг не трогаем.
                    if (MasterKeyManager.hasPassword(UnlockActivity.this)) {
                        hint.setText(R.string.unlock_hint_password);
                    } else {
                        hint.setText(R.string.unlock_hint_biometric_tap);
                    }
                }
            });

        BiometricPrompt.PromptInfo.Builder b = new BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.unlock_biometric_title))
            .setSubtitle(getString(R.string.unlock_biometric_subtitle));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            b.setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
                | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        } else {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG);
            b.setNegativeButtonText(getString(R.string.cancel));
        }

        prompt.authenticate(b.build());
    }

    /**
     * Биометрия сломана во время попытки входа — ключ инвалидирован,
     * wrapped не расшифровывается. Помечаем флаг и пересоздаём экран.
     *
     * onCreate увидит !bioHealthy и выберет правильную ветку:
     *   - пароль есть → экран пароля;
     *   - пароля нет → сразу MainActivity через fallback.
     */
    private void onBiometricBroken() {
        MasterKeyManager.markBiometricBroken(this);

        if (MasterKeyManager.hasPassword(this)) {
            recreate();
        } else {
            goToMain();
        }
    }

    private static String safeMsg(Throwable t) {
        if (t == null) return "unknown";
        String m = t.getMessage();
        if (m == null || m.isEmpty()) return t.getClass().getSimpleName();
        return m;
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}