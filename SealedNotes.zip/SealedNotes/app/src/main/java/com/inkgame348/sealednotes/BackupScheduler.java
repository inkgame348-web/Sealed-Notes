package com.inkgame348.sealednotes;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class BackupScheduler {

    private static final String WORK_NAME_PERIODIC = "sealednotes_autobackup";
    private static final String WORK_NAME_MANUAL = "sealednotes_autobackup_now";
    private static final long INTERVAL_HOURS = 12;

    public static void schedule(Context ctx) {
        Constraints constraints = new Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .build();

        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                BackupWorker.class, INTERVAL_HOURS, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build();

        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            WORK_NAME_PERIODIC,
            ExistingPeriodicWorkPolicy.UPDATE,
            request);
    }

    public static void cancel(Context ctx) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NAME_PERIODIC);
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NAME_MANUAL);
    }

    /**
     * ★ Ручной запуск использует уникальное имя с политикой KEEP.
     * Если ручной бэкап уже в очереди — второй запрос игнорируется.
     * Защита от двойного тапа и от накопления параллельных Worker'ов.
     */
    public static void runNow(Context ctx) {
        OneTimeWorkRequest request =
            new OneTimeWorkRequest.Builder(BackupWorker.class).build();

        WorkManager.getInstance(ctx).enqueueUniqueWork(
            WORK_NAME_MANUAL,
            ExistingWorkPolicy.KEEP,
            request);
    }
}