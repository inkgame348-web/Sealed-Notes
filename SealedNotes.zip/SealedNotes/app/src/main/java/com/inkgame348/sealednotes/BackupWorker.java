package com.inkgame348.sealednotes;

import android.content.Context;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.documentfile.provider.DocumentFile;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Периодический автобэкап. Раз в 12 часов.
 *
 * ★ Устанавливает эфемерный ключ через getDataKeyUnprotected + setEphemeralUnlocked,
 * чтобы NoteStorage мог читать заметки, когда приложение закрыто.
 * В finally освобождает ключ через releaseEphemeralKey (счётчик ссылок).
 */
public class BackupWorker extends Worker {

    private static final int MAX_BACKUPS = 14;
    private static final String FILE_PREFIX = "backup_";
    private static final String FILE_EXT = ".enc";

    public BackupWorker(@NonNull Context ctx, @NonNull WorkerParameters params) {
        super(ctx, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        final Context ctx = getApplicationContext();

        if (!BackupConfig.isEnabled(ctx)) {
            return Result.success();
        }

        // ★ Проверяем isUnlocked(), а не hasMemoryKey().
        //
        // hasMemoryKey() возвращает true и для эфемерного ключа — тогда
        // второй параллельный Worker не увеличит счётчик ссылок, и когда
        // первый Worker завершится, он занулит ключ под работающим вторым.
        //
        // isUnlocked() считает разблокировкой только пользовательский ключ.
        // Если ключ в памяти эфемерный (или его нет) — Worker честно
        // увеличивает счётчик. Если пользователь сам разблокирован —
        // Worker не трогает его ключ.
        boolean needsRelease = false;
        try {
            if (!MasterKeyManager.isUnlocked()) {
                byte[] dk = MasterKeyManager.getDataKeyUnprotected(ctx);
                MasterKeyManager.setEphemeralUnlocked(dk);
                needsRelease = true;
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            BackupConfig.setLastStatus(ctx, "dk_unavailable");
            return Result.failure();
        }

        try {
            return runBackup(ctx);
        } finally {
            // releaseEphemeralKey уменьшает счётчик и зануляет ключ
            // только когда счётчик дошёл до нуля. Если пользователь
            // разблокировался во время работы — счётчик уже сброшен
            // через setBiometricUnlocked, ключ не трогается.
            if (needsRelease) {
                MasterKeyManager.releaseEphemeralKey();
            }
        }
    }

    private Result runBackup(Context ctx) {
        String folderUri = BackupConfig.getFolderUri(ctx);
        if (folderUri == null) {
            BackupConfig.setLastStatus(ctx, "no_folder");
            return Result.failure();
        }

        try {
            String password = BackupConfig.getPasswordForWorker(ctx);

            String json = BackupHelper.buildJson(ctx);
            if (json == null || json.isEmpty()) {
                BackupConfig.setLastStatus(ctx, "json_failed");
                return Result.failure();
            }

            byte[] encrypted = BackupHelper.encryptWithPassword(
                json.getBytes(StandardCharsets.UTF_8), password);

            Uri treeUri = Uri.parse(folderUri);
            DocumentFile tree = DocumentFile.fromTreeUri(ctx, treeUri);
            if (tree == null || !tree.isDirectory() || !tree.canWrite()) {
                BackupConfig.setLastStatus(ctx, "folder_unavailable");
                return Result.failure();
            }

            String fileName = buildFileName();
            DocumentFile file = tree.createFile("application/octet-stream", fileName);
            if (file == null) {
                BackupConfig.setLastStatus(ctx, "create_failed");
                return Result.failure();
            }

            OutputStream os = ctx.getContentResolver().openOutputStream(file.getUri());
            if (os == null) {
                BackupConfig.setLastStatus(ctx, "open_failed");
                return Result.failure();
            }
            try {
                os.write(encrypted);
                os.flush();
            } finally {
                try { os.close(); } catch (Exception ignored) {}
            }

            if (!verifyBackup(ctx, file.getUri(), password)) {
                file.delete();
                BackupConfig.setLastStatus(ctx, "verify_failed");
                return Result.failure();
            }

            rotate(ctx, tree);

            BackupConfig.setLastTime(ctx, System.currentTimeMillis());
            BackupConfig.setLastStatus(ctx, "ok");
            return Result.success();

        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            BackupConfig.setLastStatus(ctx, "error:" + safeMsg(e));
            return Result.failure();
        }
    }

    private static String buildFileName() {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US);
        return FILE_PREFIX + fmt.format(new Date()) + FILE_EXT;
    }

    private static boolean verifyBackup(Context ctx, Uri fileUri, String password) {
        try {
            byte[] data;
            InputStream in = ctx.getContentResolver().openInputStream(fileUri);
            if (in == null) return false;
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                data = out.toByteArray();
            } finally {
                try { in.close(); } catch (Exception ignored) {}
            }

            byte[] plain = BackupHelper.decryptWithPassword(data, password);
            String json = new String(plain, StandardCharsets.UTF_8);

            String trimmed = json.trim();
            if (!trimmed.startsWith("[")) return false;
            new org.json.JSONArray(trimmed);
            return true;
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
            return false;
        }
    }

    private static void rotate(Context ctx, DocumentFile tree) {
        try {
            DocumentFile[] all = tree.listFiles();
            if (all == null || all.length == 0) return;

            List<DocumentFile> backups = new ArrayList<>();
            for (DocumentFile f : all) {
                if (f == null || !f.isFile()) continue;
                String name = f.getName();
                if (name == null) continue;
                if (name.startsWith(FILE_PREFIX) && name.endsWith(FILE_EXT)) {
                    backups.add(f);
                }
            }

            backups.sort((a, b) -> {
                String na = a.getName() != null ? a.getName() : "";
                String nb = b.getName() != null ? b.getName() : "";
                return na.compareTo(nb);
            });

            int toDelete = backups.size() - MAX_BACKUPS;
            for (int i = 0; i < toDelete; i++) {
                try { backups.get(i).delete(); } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
    }

    private static String safeMsg(Throwable t) {
        if (t == null) return "unknown";
        String m = t.getMessage();
        if (m == null || m.isEmpty()) return t.getClass().getSimpleName();
        if (m.length() > 60) m = m.substring(0, 60);
        return m;
    }
}