package com.inkgame348.sealednotes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class TrashActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private TextView emptyText;
    private ImageButton emptyBtn;
    private NoteAdapter adapter;
    private final List<Note> trash = new ArrayList<>();
    private NoteStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
            return;
        }
        super.onCreate(savedInstanceState);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE);

        setContentView(R.layout.activity_trash);

        storage = new NoteStorage(this);
        recycler = findViewById(R.id.trash_recycler);
        emptyText = findViewById(R.id.trash_empty);
        ImageButton backBtn = findViewById(R.id.trash_back);
        emptyBtn = findViewById(R.id.trash_empty_button);

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NoteAdapter(trash, new NoteAdapter.Listener() {
            @Override public void onClick(Note note) { showActions(note); }
            @Override public void onLongClick(Note note) { showActions(note); }
        });
        recycler.setAdapter(adapter);

        backBtn.setOnClickListener(v -> finish());
        emptyBtn.setOnClickListener(v -> confirmEmptyTrash());

        loadTrash();
    }

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        if (MasterKeyManager.isUnlocked()) MasterKeyManager.markActive(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (MasterKeyManager.isLocked(this)) {
            startActivity(new Intent(this, UnlockActivity.class));
            finish();
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, R.anim.slide_out_right);
    }

    private void loadTrash() {
        storage.loadAsync(loaded -> {
            if (isFinishing() || isDestroyed()) return;
            trash.clear();
            if (loaded == null) {
                ToastHelper.show(this, getString(R.string.error_decrypt_failed));
                finish();
                return;
            }
            for (Note n : loaded) {
                if (n != null && n.deleted) trash.add(n);
            }
            adapter.notifyDataSetChanged();
            updateEmpty();
        });
    }

    private void updateEmpty() {
        boolean empty = trash.isEmpty();
        emptyText.setVisibility(empty ? TextView.VISIBLE : TextView.GONE);
        recycler.setVisibility(empty ? TextView.GONE : TextView.VISIBLE);
        emptyBtn.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void showActions(Note note) {
        if (note == null || isFinishing() || isDestroyed()) return;
        String title = (note.title == null || note.title.isEmpty())
            ? getString(R.string.untitled) : note.title;
        new AnimDialog(this)
            .setTitle(title)
            .setItems(new CharSequence[]{
                getString(R.string.trash_restore),
                getString(R.string.trash_delete_forever)
            }, (d, which) -> {
                if (which == 0) restore(note);
                else confirmDeleteForever(note);
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void restore(Note note) {
        if (note == null || note.id == null) return;
        final String noteId = note.id;

        AppExecutors.get().crypto().execute(() -> {
            Note full = storage.loadFull(noteId);
            if (full == null) return;

            UndoEntry entry = new UndoEntry();
            entry.type = UndoEntry.TYPE_RESTORE_NOTE;
            entry.timestamp = System.currentTimeMillis();
            entry.noteId = full.id;
            entry.noteTitle = full.title;
            entry.previousDeletedAt = full.deletedAt;
            new UndoJournal(TrashActivity.this).push(entry);

            full.deleted = false;
            full.deletedAt = 0;
            full.contentLoaded = true;
            storage.saveOne(full);

            AppExecutors.get().runOnMain(() -> {
                if (isFinishing() || isDestroyed()) return;
                loadTrash();
                ToastHelper.show(this, getString(R.string.trash_restored));
            });
        });
    }

    private void confirmDeleteForever(Note note) {
        if (note == null || note.id == null) return;
        final String noteId = note.id;
        final String noteTitle = note.title;

        new AnimDialog(this)
            .setTitle(R.string.trash_delete_forever)
            .setMessage(R.string.trash_delete_forever_msg)
            .setPositiveButton(R.string.delete, (d, w) -> {
                AppExecutors.get().crypto().execute(() -> {
                    boolean moved = NoteStorage.moveToJournal(
                        getApplicationContext(), noteId);
                    if (!moved) {
                        // ★ ФИКС UX: сообщение "не удалось удалить",
                        // а не "не удалось отменить". Мы пытались удалить,
                        // а не отменить.
                        AppExecutors.get().runOnMain(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            ToastHelper.show(this, getString(R.string.undo_delete_failed));
                        });
                        return;
                    }

                    UndoEntry entry = new UndoEntry();
                    entry.type = UndoEntry.TYPE_HARD_DELETE;
                    entry.timestamp = System.currentTimeMillis();
                    entry.noteId = noteId;
                    entry.noteTitle = noteTitle;
                    new UndoJournal(TrashActivity.this).push(entry);

                    AttachmentHelper.deleteAllForNote(
                        getApplicationContext(), noteId);

                    List<Note> all = storage.load();
                    if (all != null) {
                        all.removeIf(n -> n != null && noteId.equals(n.id));
                        storage.save(all);
                    }

                    AppExecutors.get().runOnMain(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        loadTrash();
                        ToastHelper.show(this, getString(R.string.trash_deleted));
                    });
                });
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    private void confirmEmptyTrash() {
        if (trash.isEmpty()) {
            ToastHelper.show(this, getString(R.string.trash_already_empty));
            return;
        }
        new AnimDialog(this)
            .setTitle(R.string.trash_empty_title)
            .setMessage(getString(R.string.trash_empty_msg, trash.size()))
            .setPositiveButton(R.string.delete, (d, w) -> {
                final List<Note> snapshot = new ArrayList<>(trash);
                AppExecutors.get().crypto().execute(() -> {
                    UndoJournal journal = new UndoJournal(TrashActivity.this);
                    long now = System.currentTimeMillis();

                    for (Note n : snapshot) {
                        if (n == null || n.id == null) continue;

                        boolean moved = NoteStorage.moveToJournal(
                            getApplicationContext(), n.id);
                        if (!moved) continue;

                        UndoEntry entry = new UndoEntry();
                        entry.type = UndoEntry.TYPE_HARD_DELETE;
                        entry.timestamp = now;
                        entry.noteId = n.id;
                        entry.noteTitle = n.title;
                        journal.push(entry);

                        AttachmentHelper.deleteAllForNote(
                            getApplicationContext(), n.id);
                    }

                    List<Note> all = storage.load();
                    if (all != null) {
                        all.removeIf(n -> {
                            if (n == null || n.id == null) return false;
                            File jf = NoteStorage.getJournalFile(
                                getApplicationContext(), n.id);
                            return jf != null && jf.exists();
                        });
                        storage.save(all);
                    }

                    AppExecutors.get().runOnMain(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        loadTrash();
                        ToastHelper.show(this, getString(R.string.trash_emptied));
                    });
                });
            })
            .setNegativeButton(R.string.cancel, null)
            .show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}